/**
 * Created by Administrator on 2017/3/10.
 */
var gulp = require('gulp');
var htmlmin = require('gulp-htmlmin');
var changed = require('gulp-changed');
var uglify = require('gulp-uglify');
var connect = require('gulp-connect');
gulp.task('watch',function(){
    gulp.watch('views/**/*.html', ['live']);
});
gulp.task('connect',function(){
    connect.server({
        root:'../',
        livereload:true
    })
})

gulp.task('live',function(){
    return gulp.src('views/**/*.html')
    .pipe(connect.reload())
})
//压缩html
gulp.task('minify', function() {
    var options = {
        removeComments: true,  //清除HTML注释
        collapseWhitespace: true,  //压缩HTML
        collapseBooleanAttributes: true,  //省略布尔属性的值 <input checked="true"/> ==> <input checked />
        removeEmptyAttributes: true,  //删除所有空格作属性值 <input id="" /> ==> <input />
        removeScriptTypeAttributes: true,  //删除<script>的type="text/javascript"
        removeStyleLinkTypeAttributes: true,  //删除<style>和<link>的type="text/css"
        minifyJS: true,  //压缩页面JS
        minifyCSS: true  //压缩页面CSS
    };
    return gulp.src('views/**/*.html')
        .pipe(changed('vjidianAdmin/views/'))
        .pipe(htmlmin(options))
        .pipe(gulp.dest('vjidianAdmin/views/'));
});
//压缩js
gulp.task('jsmin', function() {
    gulp.src('vjdassets/js/**/*.js')
        .pipe(uglify())
        .pipe(gulp.dest('vjidianAdmin/vjdassets/js/'))
    gulp.src('vjdassets/plugins/**/*.js')
        .pipe(uglify())
        .pipe(gulp.dest('vjidianAdmin/vjdassets/plugins/'))
})
gulp.task('default',['watch','connect']);