(function () {
	if(top.location != self.location){
		top.location = self.location;
	}

	//移入收藏
	$('#site-nav .collect').hover(function () {
		$(this).addClass('hover');
	}, function () {
		$(this).removeClass('hover');
	});
	//快速导航移入
	$('#site-nav .quick-menu .menu').hover(function () {
		$(this).addClass('hover');
		$(this).find('.dd').show();
	}, function () {
		$(this).removeClass('hover');
		$(this).find('.dd').hide();
	});

	//语言cookie
	$('#site-nav').on('click', '.locale' ,function(e){
		e.preventDefault();
		var language = $.cookie('language');
		if(!language || language == 'zh_CN'){
			$.cookie('language','en',{expires:30,path:'/'});
		}else{
			$.cookie('language','zh_CN',{expires:30,path:'/'});
		}		
		location.reload(true);
	});

    //点击收藏
  	window.addFavorite=function(title, url) {
		try {
			window.external.addfavorite(url, title);
		} catch(e) {
			try {
				window.sidebar.addPanel(title, url, "");
			} catch(e) {
				alert($('#tip_notsupport').text());
			}
		}
	}
	//显示全部分类菜单
	function showCategoryMenu(){
		var $that = $(this);
		var oCategoryMenu = $('#category-menu');
		$that.append(oCategoryMenu);
		if(oCategoryMenu.length>0){
			oCategoryMenu.show();
			oCategoryMenu.css({left:0,top:$that.height()});
		}
		$('#hd-allCategory a span').addClass('Down').removeClass('up');
	}
	function hideCategoryMenu(){
		var $that = $(this);
		var oCategoryMenu = $('#category-menu');
		if(oCategoryMenu.length>0){
			oCategoryMenu.hide();
		}
		$('#hd-allCategory a span').addClass('up').removeClass('Down');
	}
	$('#hd-allCategory').hover(showCategoryMenu, hideCategoryMenu);
		
	//页头搜索
	function mallSearch(e){
		e.preventDefault();
		var numType = $('#btn_search').attr("data-value");
		var searchWord = $('#txt_search').val();
		if(searchWord){
			searchWord = encodeURIComponent(searchWord);
			var url = location.protocol + "//" + location.host+'/category?s='+searchWord+'&type='+numType;
			location.href = url;
		}
	}
	$('#btn_search').click(mallSearch);
	var defaultSearch = $('#txt_search').val();
	$('#txt_search').keyup(function(e){
		if(e.keyCode == 13){
			mallSearch(e);
		}
	});
	$('#txt_search').focus(function(){
		var $that = $(this);
		if($that.hasClass('greyColor')){
			$that.val('');
			$that.removeClass('greyColor');
		}
	});
	$('#txt_search').blur(function(){
		var $that = $(this);
		if(!$.trim($that.val())){
			$that.val(defaultSearch);
			$that.addClass('greyColor');
		}
	});
	$('#btn_login').click(function(e){
		e.preventDefault();
		var referer = encodeURIComponent(location.href);
		var url = location.protocol + "//" + location.host+'/login?returnUrl='+referer;
		location.href = url;
	});


	//显示三级菜单
	function showThirdCategory(){
		var $that = $(this);
		$that.siblings('dl').removeClass('hover');
		$that.addClass('hover');
		$that.siblings('.category-three').hide();
		$that.next('.category-three').show();
	}
	function hideThirdCategory(){
		var $that = $(this);
		$that.find('dl').removeClass('hover');
		$that.find('.category-three').hide();
	}
	$('#category-menu').on('mouseenter','dl',showThirdCategory);
	$('#category-menu').on('mouseleave',hideThirdCategory);
	$('#pnl_categoryMenu').on('mouseenter','dl',showThirdCategory);
	$('#pnl_categoryMenu').on('mouseleave',hideThirdCategory);
})();