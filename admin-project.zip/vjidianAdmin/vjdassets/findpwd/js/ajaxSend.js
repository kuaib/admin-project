/**************************************************
* 常用的ajax提交
* @author shenliang
**************************************************/

/**
 * jsonsend
 * @param {Object} url
 * @param {Object} param
 * @param {Object} callback
 */
function jsonSend( url , param , callback , async ){	
	if( async != false ){
		async = true;
	}
	$.ajax({
		url:url,
		data:param,
		type:'post',
		async:async,
	    dataType:'json',
	    success:callback
	});
}
/**
 * htmlsend
 * @param {Object} url
 * @param {Object} param
 * @param {Object} callback
 * @param {Object} container
 */
function htmlSend( url , param , container , async ){
	if( async != false ){
		async = true;
	}
	$.ajax({
		url:url,
		data:param,
		type:'post',
	   	async:async,
		success:function( data ){
			$( container ).html( data );
	    }
	});
}