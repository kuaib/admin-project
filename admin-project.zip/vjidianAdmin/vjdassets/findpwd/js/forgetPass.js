$(function(){
	$('.resetPassBody input').focus(function(){
		$(this).css({borderColor:"#00a0e8"});
	});
	$('.resetPassBody input').blur(function(){
		$(this).css({borderColor:"#d3d3d3"});
	});
});
var getVerifyCodeUrl = '/findPassword/getVerifyCode';
var validateMemberUrl = '/findPassword/validateMember';
var userAuthUrl = '/findPassword/userAuth';
var sendMobileVerifyCodeUrl = '/findPassword/sendMobileVerifyCode';
var validateMobileVerifyCodeUrl = '/findPassword/validateMobileVerifyCode';
var setNewPasswordUrl = '/findPassword/setNewPassword';
var updateLoginPasswordUrl = '/findPassword/updateLoginPassword';


function formSubmit(url,arr) {
var nextForm = document.createElement("form");   
	document.body.appendChild(nextForm);
	nextForm.method = 'post';
	nextForm.action = url;
	nextForm.target = '_self';
	if(arr){
		for(var i in arr){
			if (arr[i].name=='aa') {
				arr[i].name = 'securityUserId';
			}
			if (arr[i].name=='bb') {
				arr[i].name = 'mode';
			}
			var inputElement = document.createElement("input");
			inputElement.setAttribute("name",arr[i].name);
			inputElement.setAttribute("type","hidden");
			inputElement.setAttribute("value",arr[i].value);
			nextForm.appendChild(inputElement);
		}
	}
	nextForm.submit();
}