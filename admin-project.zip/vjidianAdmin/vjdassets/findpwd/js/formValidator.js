var formValidator={
	mobile: [/^(\+86[\s-])?(((13[0-9]{1})|(15[0-9]{1})|(18[0-9]{1}))\d{8})$/,$('#formEnterPhone').text()],
	ip:     [/^(((\d{1,2})|(1\d{2})|(2[0-4]\d)|(25[0-5]))\.){3}((\d{1,2})|(1\d{2})|(2[0-4]{2})|(25[0-5]))$/, $('#enterYanIp').text()],
	qq:		[/^[1-9]\d{3,14}$/, $('#enterQQ').text()],
	email:	[/^[\w\-\.]+@[0-9a-z\-]+(\.[a-z]{2,4}){1,2}$/i, $('#enterEmail').text()],
	tel:	[/^(?:(?:0\d{2,3}[\- ]?[1-9]\d{6,7}[\-]?(\d{1,6})?))$/, $('#enterCorrectPhone').text()],
	postcode:[/^\d{6}$/, $('#enterPostalCode').text()],
	ID_card:[/^((\d{15})|(\d{17}([0-9]|X)))$/, $('#enterNum').text()],
	url:    [/^((https?|ftp):\/\/)?([a-z0-9]+\.)+[a-z]{2,4}(\.[a-z]{2,4})?\/?$/, $('#enterYanZhengInt').text()],
	fax:    [/^(([0\+]\d{2,3}-)?(0\d{2,3})-)(\d{7,8})(-(\d{3,}))?$/, $('#enterYanZhengfaxNum').text()],
	pass:	[/^.{6,20}$/, $('#enterYanZhengPassWord').text()],
	confirm_pass:	[/^.{6,20}$/, $('#passWordDifferent').text()],
	note:   [/^.{0,120}$/,$('#formEnterPass0TO120').text()],
	floating:  [/^-?([1-9]\d{0,8}(\.\d{1,5})?|0(\.\d{1,5})?)$/,$('#formEnterRightNum').text()],
	quantity:  [/^-?(20\d{0,8}|(1\d{0,9})|[1-9]\d{0,8}|0)(\.0+)?$/,$('#formEnterRightAumount').text()],
	money:    [/^([1-9]\d{0,8}(\.\d{1,4})?|0(\.\d{1,4})?)$/, $('#enterRightMoney').text()],
	time: [/^(\d{4}-\d{1,2}-\d{1,2}\s)?([01]\d|2[0-3])(:[0-5]\d){1,2}$/,$('#formEnterRightTime').text()],
	passStrict: [/^((.*[0-9]+.*[a-z]+.*)|(.*[a-z]+.*[0-9]+.*))$/i,$('#enterYanZhengPassWord').text()],
	recipient: [/^.{1,25}$/, $('#enterConsignee').text()+$('#formEnterCharast1To25').text()],
	username:[/^.+$/, $('#formEnterUseName').text()]
};

function checkForm(id, fnCheck){
	var oForm=document.getElementById(id);
	var aInput=oForm.getElementsByTagName('input');
	for(var i=0;i<aInput.length;i++){
		var re = null;
		var tip = '';
		if(formValidator[aInput[i].name]){
			re=formValidator[aInput[i].name][0];
			tip=formValidator[aInput[i].name][1];
		}
		if(re){
			(function (re,tip){
				aInput[i].onblur=function(){
					check(re,this,tip);
				};
			})(re,tip);
		}
	}

	function check(re,oTxt,tip){
		if(re.test($.trim(oTxt.value))){
			//不需要二次校验
			if(!fnCheck){
				// oTxt.className='validated';
				$(oTxt).css({borderColor:"#d3d3d3"});
				$(oTxt).siblings('.validation').hide();
				return true;
			}else{
				if(fnCheck(oTxt)==false){
					// oTxt.className='err-validated';	
					$(oTxt).css({borderColor:'#d3d3d3'});
					$(oTxt).siblings('.validation').html(tip).show();
					return false;
				}else{
					// oTxt.className='validated';
					$(oTxt).css({borderColor:"#d3d3d3"});
					$(oTxt).siblings('.validation').hide();
					return true;
				}
			}
		}else{
			// oTxt.className='err-validated';
			if($(oTxt).val()=='' && $(oTxt).attr('unrequired')){
				$(oTxt).css({borderColor:"#d3d3d3"});
				$(oTxt).siblings('.validation').hide();
				return true;
			}
			$(oTxt).css({borderColor:'#d3d3d3'});
			$(oTxt).siblings('.validation').html(tip).show();
			return false;
		}
	}

	oForm.onsubmit=function (){
		var ok=true;

		for(var i=0;i<aInput.length;i++){
			var re=formValidator[aInput[i].name][0];
			//需要校验
			if(re)	{
				if(!check(re, aInput[i])){
					ok=false;
				}
			}
		}

		if(ok==false){
			return false;
		}
	};
}