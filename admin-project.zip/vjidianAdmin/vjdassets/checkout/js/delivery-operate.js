var deliveryOperate = (function() {

    var _global = {};

    /**
     * 保存配送方式
     */
    function _saveDelivery (argument) {
        var paymentModeType = $('#payAndDelivery').find('input[name=paymentModeType]:checked').data('text');
        var deliveryMode = $('#payAndDelivery').find('input[name=deliveryModeId]:checked').data('text');
        var regionId = $('input[name="addressId"]:checked').attr("regionId");
        var sendGoodsType = $('#pnl_sendGoodsType input[name=sendGoodsType]:checked').data('text');

        var data = {
            paymentModeType: paymentModeType,
            deliveryMode:deliveryMode,
            sendGoodsType:sendGoodsType
        };

        var $tmpl = $('#tmpl-delivery-mode-save');

        var templateCompile = Handlebars.compile($tmpl.val()),
            template = templateCompile(data);

        //设置不显示已选择的配送方式、支付方式 $('#j-delivery-mode-save').html(template).show();
        $('#j-delivery-mode-save').html(template);
        //运费
        _getFreight();
        //获取结算规则
        //_getCheckoutRule();
        //展示结算规则
    }

    /**
     * 获取结算规则
     */
    function _getCheckoutRule () {
        var paymentModeType = $('#payAndDelivery').find('input[name=paymentModeType]:checked').val();
        var deliveryMode = $('#payAndDelivery').find('input[name=deliveryModeId]:checked').val();
        var regionId = $('input[name=addressId]:checked').attr('regionId');

        var data = {
            regionId: regionId,
            deliveryId: deliveryMode,
            paymodeId: paymentModeType
        };

        checkoutController.getCheckouRule(data, function(result) {
            if( result ){
                var $tmpl = $('#tmpl-checkout-rule');

                var templateCompile = Handlebars.compile($tmpl.val()),
                    template = templateCompile(result);

                $('#j-checkout-rule').html(template).show();
            }
        });
    }

    /**
     * 获取并设置金额
     */
    function _getAmount(){
        checkoutController.getAmount({},function(data){
            $('#j-payable-amount').html(toCash(data.payableAmount)); //应付金额
            $('#hid_payable_mount').val(data.payableAmount);
     //       $('#j-real-freight-info').html(toCash(data.totalFreight)); //运费合计
            $('#j-total-freight-info').html(toCash(data.freight)); //快递费用
            $('#j-service-freight-info').html(toCash(data.freightServiceFee)); //准时达费用
            $('#j-discount-freight-info').html(toCash(data.pointFreight)); //积分冲抵运费
            $('#j-total-discount-amount').html("-"+toCash(data.totalDiscountAmount)); //总优惠
        });
    }

    /**
     * 获取运费
     */
    function _getSendGoodsType(callback, regionId) {
        if(regionId == undefined){
            regionId = $('input[name=addressId]:checked').attr('regionId');
        }
        if (regionId !== undefined) {
            var deliveryModeId = $('input[name=deliveryModeId]:checked').val();
            
            var data = {
                regionId:regionId,
                deliveryModeId:deliveryModeId
            };

            checkoutController.getSendGoodsType(data, function(result) {
                if (result.result) {
                    switch(result.id){
                        case 0:
                            $('#pnl_sendGoodsType').hide();
                            alert('抱歉，该地区不在物流服务范围内');
                            break;
                        case 1:
                            $('#rad_ifGet').hide();
                            $('#txt_ifGet').hide();
                            $('#rad_ifSend').attr('checked','checked');
                            break;
                        case 2:
                            $('#rad_ifGet').attr('checked','checked');
                            $('#rad_ifSend').hide();
                            $('#txt_ifSend').hide();
                        case 3:
                            $('#rad_ifSend').attr('checked','checked');
                            break;
                    }
                }else{
                    console.log(result.tip);
                }
                if(callback){
                    callback(result);
                }
            });
        }
    }

    /**
     * 获取运费
     */
   function _getFreight() {
        var regionId = $('input[name=addressId]:checked').attr('regionId');
        if (regionId !== undefined) {
            var deliveryModeId = $('input[name=deliveryModeId]:checked').val();
            var sendGoodsType = $('#pnl_sendGoodsType input[name=sendGoodsType]:checked').val();
            var data = {
                regionId:regionId,
                deliveryModeId:deliveryModeId,
                sendGoodsType:sendGoodsType
            };

            checkoutController.getFreight(data, function(response) {
                if (response.result == false) {
                    alert(response.tip);
                    return;
                }else{
        //            $('#j-real-freight-info').val(response.tip);
                    $('#j-total-freight').val(response.tip);
                }
            });
        }
    }

    /**
     * 返回可用方法
     */
    return {
        saveDelivery: _saveDelivery,
        getSendGoodsType:_getSendGoodsType,
        getAmount:_getAmount
    };
}());