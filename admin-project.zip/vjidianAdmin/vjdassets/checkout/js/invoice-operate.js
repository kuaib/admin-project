var invoiceOperate = (function() {

    var _global = {};

    /**
     * 返回可用方法
     */
    return {};

}());