function checkoutOperate(op){
	if(op === BIZ_OPER.SAVEADDRESSDIV){
		//获取配送方式并展开
		//getDeliveryMode();
	}else if(op==BIZ_OPER.EDITADDRESSDIV){
		//获取会员的可用地址
		//showMemberAddress();
		
	}else if(op==BIZ_OPER.SAVEDELIVERYMODEDIV){
		//获取结算规则
		//getCheckouRule();
		//获取运费
		//getFreight();
		//清空优惠券、积分
	}else if(op==BIZ_OPER.EDITDELIVERYMODEDIV){
		//获取配送方式并展开
		//getDeliveryMode();
	}else if(op==BIZ_OPER.SHOWCOUPONS){
		//获取优惠券列表
		//getCoupons();
	}else if(op==BIZ_OPER.SELECTCOUPON){
		//执行优惠券奖励，刷新券列表
		//selectCoupon();
		//calculateAmount();
	}else if(op==BIZ_OPER.SHOWPOINTRULE){
		//获取可用积分和积分规则
		//getPointRule();
	}else if(op==BIZ_OPER.POINTPAY){
		//输入积分，进行校验计算
		//calculateAmount();
	}else if(op==BIZ_OPER.SUBMITORDER){
		//验证必填项，验证支付密码，提交订单
	}
}

function getDeliveryMode(){
	var regionId = $('input[name=addressId]:checked').attr('regionId');
	var data={regionId:regionId};
	checkoutController.getDeliveryMode(data,function(result){
		console.log(result);
	});
}

/**已选中券id*/
var couponIds = {};

/**
*获取积分规则
*/
function getPointRule(){
	var availablePoint = 0;
	if(totalFeright>0){
		checkoutController.getPoint(null,function(result){
			if(result){
				availablePoint = result.availablePoint;
				$('#j-canusepoint-value').val(availablePoint);
				$('#pointValue').html(result.pointAccountBalance);
				$('#canUsePoint').html(availablePoint);
				$('#j-point-cash-scale').val(result.point2CurrencyConversion);
			}
			console.log(result);
		});
	}
}
/**
* 使用积分
*/
function usePoint(e){
	e.preventDefault();
	var point = $('#txt_point').val();
	var pointValue = parseFloat($('#j-canusepoint-value').val());
	var reg = /^[1-9]\d*(.0*)?$/;
	var data = {};
	if(reg.test(point)){
		if(point>pointValue){
			alert('您使用的积分超过了可使用的范围');
			$('#txt_point').val(pointValue);
			$('#sec-to-cash').html('0.00');
			return;
		}else{
			data.point = point;
			data.freight = $('#j-total-freight').val();
			checkoutController.usePoint(data,function(result){
				$('#sec-usingState').html(result.tip);
				deliveryOperate.getAmount();
			});
		}
	}else{
		$('#txt_point').val('');
	}
}
$('#btn_usePoint').click(usePoint);
$('#txt_point').on('focus',function(){
	$('#sec-usingState').html('');
});
$('#txt_point').on('keyup',function(){
	var scale = $('#j-point-cash-scale').val()*100;
	var $that = $(this);
	var point = parseFloat($that.val());
	if(!isNaN(point) && scale){
		$('#sec-to-cash').html((point/scale).toFixed(2));
	}
});

//去结算
function createOrder(){
	var $payAndDelivery=$('#payAndDelivery');
	var paymentModeType=$payAndDelivery.find('input[name=paymentModeType]:checked').val();
	var deliveryModeType=$payAndDelivery.find('input[name=deliveryModeId]:checked').val();
	//发票
	var $invoiceId=$('#invoiceId');
	var invoiceStatus=$invoiceId.find('input[name=invoiceStatus]:checked').val();
	var invoiceType = $('#sel_invoiceType').val();
	var title = $('#title').val();
	var noteNum = $('#hideNoteNum').val();
	var address = $('#hideAddress').val();
	var bank = $('#hideBank').val();
	var address2 = $('#hideAddress2').val();
	var bank2 = $('#hideBank2').val();
	
	var addressId=$('#pnl_recipient').find('input[name=addressId]:checked').val();
	
	var couponIds="";
	
	var idStr='';
	var $goodsList=$('#goodsListId');
	$goodsList.find('input[name=goodsId]').each(function(index, element){
		if(index==0){
			idStr=$(this).val();
		}else{
			idStr=idStr+','+$(this).val();
		}
	});
	var itemIds= $('#itemIds').val();
	var remark=[];
	$('#cartPanel input[name=remark]').each(function(index, input){
		remark.push($(input).val());
	});
	
	var payableFreight = $('#j-total-freight').val();
	var freightServiceFee = 0;
	
	var point = $('#txt_point').val();
	var payableAmount = $('#hid_payable_amount').val();
	var sendGoodsType = $('input[name=sendGoodsType]:checked').val();
	
	var data={
		deliveryModeId:deliveryModeType,
		freightRuleId:1,
		paymentModeType:paymentModeType,
		addressId:addressId,
		goodsId:idStr,
		itemIds:itemIds,
		payableFreight:payableFreight,
		freightServiceFee:freightServiceFee,
		invoiceStatus:invoiceStatus,
		invoiceType:invoiceType,
		title:title, 
		noteNum:noteNum,
		address:address,
		bank:bank,
		address2:address2,
		bank2:bank2,
		remark:remark, 
		couponIds:couponIds,
		point:point, 
		payableAmount:payableAmount,
		sendGoodsType:sendGoodsType
	};
			
	$('#j-submit-order-wait').show();
	lockSubmitOrder();
	checkoutController.createOrder(data,function(data){
		$('#j-submit-order-wait').hide();
		unLockSubmitOrder();
		if(data.result){
			//去结算请求地址
			var url='http://www.vjidian.net/vjidian-payment/orderFront/createOrder?paymentModeType='+data.paymentModeType+'&mergePaymentId='+data.mergePaymentId;
			window.location.href=url;
		}else{
			alert(data.resultMsg);
		}
	});
}

// 提交订单
function submitForm(){
	//判断是否可以提交
	//1.是否保存了收货人信息和支付配送方式
	var $that = $(this);
	var $saveInfo = $that.siblings('.save-info');
	if($('#pnl_recipient_biggest').hasClass('operation-focus')){
		$saveInfo.hide();
		$that.siblings('.save-address').show();
		return;
	};
	if($('#payAndDelivery').hasClass('operation-focus')){
		$saveInfo.hide();
		$that.siblings('.save-payment').show();
		return;
	};
	$saveInfo.hide();
	//2.判断发票抬头是否填写
	if($('#invoiceStatus-need').prop('checked')){
		var title = $.trim($('#title').val());
		var noteNum = $.trim($('#hideNoteNum').val());
		var address = $.trim($('#hideAddress').val());
		var bank = $.trim($('#hideBank').val());
		var address2 = $.trim($('#hideAddress2').val());
		var bank2 = $.trim($('#hideBank2').val());
		if(!title){
			$('#j-title-info').removeClass('right')
					.addClass('wrong').html('请填写发票抬头');
			alert("请填写发票抬头");
			$(window).scrollTop(300);
			return;
		}
		if(!noteNum){
			$('#j-noteNum-info').removeClass('right')
					.addClass('wrong').html('请填写税号');
			alert("请填写税号");
			$(window).scrollTop(300);
			return;
		}
		if(!address){
			$('#j-address-info').removeClass('right')
					.addClass('wrong').html('请填写地址');
			alert("请填写地址");
			$(window).scrollTop(300);
			return;
		}
		if(!bank){
			$('#j-bank-info').removeClass('right')
					.addClass('wrong').html('请填写开户行');
			alert("请填写开户行");
			$(window).scrollTop(300);
			return;
		}
		if(!address2){
			$('#j-address-info2').removeClass('right')
					.addClass('wrong').html('请填写电话');
			alert("请填写电话");
			$(window).scrollTop(300);
			return;
		}
		if(!bank2){
			$('#j-bank-info2').removeClass('right')
					.addClass('wrong').html('请填写账号');
			alert("请填写账号");
			$(window).scrollTop(300);
			return;
		}
	}
	
	if($('#invoiceStatus-need2').prop('checked')){
		var title = $.trim($('#title').val());
		if(!title){
			$('#j-title-info').removeClass('right')
					.addClass('wrong').html('请填写发票抬头');
			alert("请填写发票抬头");
			$(window).scrollTop(300);
			return;
		}
	}
	//3.判断是否配置运费
	var freight = $('#j-total-freight').val();
	if(freight == -1){
		return;
	}
	//4.是否存在收件人信息
	if($("#pnl_recipient").find("div.personalInfo").length>0){
		createOrder();
	}else{
		alert(peoleInfor);
		return false;
	}
}

// 锁定提交订单按钮
function lockSubmitOrder() {
	$('#j-submit-order').off('click').addClass('submit-order-disabled');
}

// 解锁提交订单按钮
function unLockSubmitOrder() {
	$('#j-submit-order').on('click', submitForm).removeClass('submit-order-disabled');
}

//###修改地址按钮
function changeAddress(e){
	e.preventDefault();
	var $pnlRecipient = $('#pnl_recipient_biggest');
	// 如果没有保存支付方式
	if($('#payAndDelivery').hasClass('operation-focus')){
		$pnlRecipient.find('.kind-info').show();
		return false;
	};
	$pnlRecipient.find('.kind-info').hide();
	$pnlRecipient.addClass('operation-focus');
	return false;
}
$('#btn_changeAddress').click(changeAddress);

//###保存收货人信息
function saveAddress(e){
	e.preventDefault();
	var $that = $(this);
	var $payAndDelivery = $('#payAndDelivery');
	$('#pnl_recipient_biggest').removeClass('operation-focus');
	//$payAndDelivery.addClass('operation-focus');
	$payAndDelivery.find('.kind-info').css('display','inline-block');
	$payAndDelivery.find('.kind-text').hide();
	$("#memberAddressId").val($("input[name='addressId']:checked").val());
	consigneeOperate.saveAddress();	
}
$('#btn_saveSelected').click(saveAddress);

//###修改支付方式按钮
function changePayment(e){
	e.preventDefault();
	var $that = $(this);
	// 如果还没有保存地址
	if($('#pnl_recipient_biggest').hasClass('operation-focus')){
		$that.siblings('.kind-text').css('display','inline-block');
		return;
	};
	$that.siblings('b').hide();
	$('#payAndDelivery').addClass('operation-focus');
}
$('#btn_changepayment').click(changePayment);

$(function(){
	//显示保存后的层内容
//	deliveryOperate.saveDelivery();
	//获取并设置金额
//	deliveryOperate.getAmount();
	
	clearCouponAndPoint()
})

//###保存支付和配送方式
var isFirstSaving = true; //是否为第一次保存
function savePayment(e){
	e.preventDefault();
	var $payAndDelivery = $('#payAndDelivery');
	var $pnlBalance = $('#pnl_balance');

	$payAndDelivery.removeClass('operation-focus');
	$payAndDelivery.find('.kind-info').hide();

	if(!isFirstSaving){
		$pnlBalance.find('.kind-info').css('display','inline-block');
	}
	//显示保存后的层内容
	deliveryOperate.saveDelivery();
	//获取并设置金额
	deliveryOperate.getAmount();
	
	clearCouponAndPoint()
	isFirstSaving = false;
}
$('#btn_savePayment').click(savePayment);

//清空已填积分和已选优惠券
function clearCouponAndPoint(){
	var $pnlBalance = $('#pnl_balance');
	$pnlBalance.find('.balance-detail').hide();
	$pnlBalance.find('.showDetail').css({backgroundPosition:'-110px 0px'});
	$pnlBalance.find('.j-coupon').prop('checked',false).css({visibility:'visible'});
	$pnlBalance.find('input[type=text]').val('');
	$('#sec_codeInput').hide();
//	var couponIds = couponOperate.getCouponIds();
//	couponIds.length = 0; //清空已选优惠券
}
//转换成人民币形式
function toCash(num){
    if(num<0){
        var numStr = num.toFixed(2);
        numStr = '-&yen;'+numStr.substring(1);
    }else{
        var numStr = num.toFixed(2);
        numStr = '&yen;'+numStr;
    }
    return numStr;
}

//显示激活码
function showActivateCode(){
	$('#sec_codeInput').show();
}
$('#btn_codeInput').click(showActivateCode);

// 初始化静态渲染效果
var _init = (function () {
	
	var hidePresentLastLine = function () {
		var $this = $(this),
			$line = $this.find('.j-present-line:last');
			
		if ($line.next().length === 0) {
			$line.hide();
		}
	};
	
	// 购物车列表最后的分割线渲染处理
	var $goods = $('.j-good');
	$('#j-other-promotions').each(hidePresentLastLine);
	$goods.each(hidePresentLastLine);
	$goods.filter(':last').removeClass('list');
}());

function validAdditionalInfo(){
	var id = $(this).attr('id');
	var index = id.replace('j-additional-info', '');
	var exceedErrorTip = '对不起，您的输入已超过最大限制！';
	checkoutValidate.valiCurrMsg('#j-additional-info'+index, '#j-additional-info-tip'+ index,
		24, null, exceedErrorTip);
}
$('#cartPanel').on('keyup','input[name=remark]',validAdditionalInfo);

function validInvoiceInfo(){
	var exceedErrorTip = '对不起，您的输入已超过最大限制！';
	checkoutValidate.valiCurrMsg('#title', '#j-title-info',
		20, null, exceedErrorTip);
}
$('#title').on('keyup',validInvoiceInfo);
$('#hideNoteNum').on('keyup',function(){
	$("#j-noteNum-info").html("");
});
$('#hideAddress').on('keyup',function(){
	$("#j-address-info").html("");
});
$('#hideBank').on('keyup',function(){
	$("#j-bank-info").html("");
});
$('#hideAddress2').on('keyup',function(){
	$("#j-address-info2").html("");
});
$('#hideBank2').on('keyup',function(){
	$("#j-bank-info2").html("");
});
history.forward(1);