var checkoutValidate = (function() {

    var _global = {};
    
    /**
     * @param {String} inpSelector      文本输入标签选择器
     * @param {String} tipSelector      提示语显示标签选择器
     * @param {Number} limitLen         限定字符数量
     * @param {String} emtpyTip         为空错误提示内容
     * @param {String} exceedErrorTip   超出限定字符数时提示内容
     */
    var _valiCurrMsg = function(inpSelector, tipSelector, limitLen, emtpyTip, exceedErrorTip) {
        var inpValue = $(inpSelector).val(),
            currLen = inpValue.length;
            tipInTime = '目前为{{currLen}}个字符，您还可以输入{{surplusLen}}个字符';
            tip = '';

        if (currLen === 0) {

            if (typeof emtpyTip !== 'undefined' && emtpyTip !== null) {
                $(tipSelector).html(emtpyTip).removeClass('right').addClass('wrong');
                return false;
            }
            $(tipSelector).html('');
            return true;
        }else if(currLen <= limitLen){

            tip = tipInTime.replace('{{currLen}}', Math.ceil(currLen));
            tip = tip.replace('{{surplusLen}}', Math.ceil(limitLen - currLen));

            $(tipSelector).html(tip).removeClass('wrong').addClass('right');
            return true;
        }else {
            $(tipSelector).html(exceedErrorTip).removeClass('right').addClass('wrong');
            return false;
        }
    };

    /**
     * 返回可用方法
     */
    return {
        valiCurrMsg: _valiCurrMsg
    };
}());