var consigneeOperate = (function() {
    
    var _global = {};
    
    /**
     * 页面加载后初始化收货人信息
     */
    function _init() {
        if ($('input[name=addressId]:checked').length > 0) {
            $('#btn_saveSelected').trigger('click');
//            deliveryOperate.getSendGoodsType();
        } else {
            $('#btn_changeAddress').trigger('click');
        }
    }

    /**
     * 保存地址
     */
    function _saveAddress() {

        var $checkedRadio = $('#pnl_recipient').find('input[name=addressId]:checked');
        var recipient=$checkedRadio.siblings("input[mark=recipient]").val();//收货人
        var regionProvince=$checkedRadio.siblings('input[type=hidden][mark=regionProvince]').val();
        var regionCity=$checkedRadio.siblings('input[type=hidden][mark=regionCity]').val();
        var regionCounty=$checkedRadio.siblings('input[type=hidden][mark=regionCounty]').val();
        var address=$checkedRadio.siblings('input[type=hidden][mark=address]').val();
        var mobile=$checkedRadio.siblings("input[type=hidden][mark=mobile]").val();//手机号

        var result = {
            'recipient': recipient,
            'regionProvince': regionProvince,
            'regionCity':regionCity,
            'regionCounty':regionCounty,
            'address': address,
            'mobile': mobile
        };

        var $tmpl = $('#tmpl-consignee-address');

        var templateCompile = Handlebars.compile($tmpl.val()),
            template = templateCompile(result);
            
        $('#j-consignee-address').html(template).show();

        var regionId = $checkedRadio.attr('regionId');
    }
    
    /**
     * 返回可用方法
     */
    return {
        init: _init,
        saveAddress: _saveAddress
    };

}());

// dom加载后执行
$(function() {
    consigneeOperate.init();
});