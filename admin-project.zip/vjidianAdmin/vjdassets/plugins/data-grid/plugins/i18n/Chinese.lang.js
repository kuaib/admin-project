/**
 * Chinese translation
 * 
 * @name Chinese
 * @anchor Chinese
 * @author <a href="http://docs.jquery.com/UI">Chi Cheng</a>
 */

var lang_zh = {
	"processing" : "<img src='/vjdassets/img/loading-spinner-grey.gif'/><span>&nbsp;&nbsp;处理中...</span>",
	"lengthMenu" : "显示 _MENU_ 项结果",
	"zeroRecords" : "没有匹配结果",
	"info" : "第<input type='text' value='_PAGE_' class='form-control input-mini input-sm text-center jumppage' style='margin: 0 5px;'>页，共_PAGES_页 | ",
	"infoEmpty" : "显示第 0 至 0 项结果，共 0 项",
	"infoFiltered" : "(由 _MAX_ 项结果过滤)",
	"infoPostFix" : "显示第 _START_ 至 _END_ 项结果，共 _TOTAL_ 项",
	"search" : "<span class='btn blue add-on input-sm'>搜索</span>",
	"url" : "",
	"emptyTable" : "表中数据为空",
	"loadingRecords" : "<img src='/vjdassets/img/loading-spinner-grey.gif'/><span>&nbsp;&nbsp;载入中...</span>",
	"infoThousands" : ",",
	"paginate" : {
		"first" : "首页",
		"previous" : "上页",
		"next" : "下页",
		"last" : "末页"
	},
	"aria" : {
		"sortAscending" : ": 以升序排列此列",
		"sortDescending" : ": 以降序排列此列"
	}
};
