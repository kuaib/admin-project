var TableAdvanced = function () {
    var initTable1 = function() {
        /* Formatting function for row details */
        function fnFormatDetails (id) {
        	var sOut = '<table width="100%"><tr><td><table>';
        	$.ajax({
     			dataType:"json",
     			url:"./detail?categoryId=" + id,
     			type:"post",
     			cache:false,
     			async:false,
     			success:function(data,status){
     				var list='<table>';
     				for(var i=1;i<=data.subCategorys.length;i++) {
     					if(i%2) {// 基数
     						list+='<tr><td>'+i+'&nbsp;'+data.subCategorys[i-1].categoryName+'</td>';
     					} else {
     						list+='<td>'+i+'&nbsp;'+data.subCategorys[i-1].categoryName+'</td></tr>';
     					}
     				}
     				list+='</table>';
     				sOut += '<tr valign="top"><td style="white-space:nowrap">商品分类描述:'+'</td><td>'+data.description+'</td></tr>';
     				sOut += '<tr valign="top"><td style="white-space:nowrap">子级分类内容:'+'</td><td>'+list+'</td></tr>';
     	            sOut += '<tr><td style="white-space:nowrap">商品分类编码:'+'</td><td>'+data.categoryId+'</td></tr>';
     	            sOut += '<tr><td style="white-space:nowrap">商品分类顺序:'+'</td><td>'+data.sequence+'</td></tr>';
     	            sOut += '<tr><td style="white-space:nowrap">父级分类编码:'+'</td><td>'+data.parentId+'</td></tr></table></td>';
     	            sOut += '<td width="50%" align="center"><table><tr><td><img src="../../vjdassets/img/photo2.jpg"/><td/><tr/><tr><td align="center">商品分类图片</td></tr><td/>';
     			},
     			error : function(xmlHttpRequest, data, status) {
					console.log(xmlHttpRequest);
					console.log(data);
					console.log(status);
					alert(status);
				}
     		});
        	sOut += '</tr></table>';
        	console.log(sOut);
        	return sOut;
        }
        
        // 对表格的处理要在加载table控件之前，否则分页失效
		// 表格排序
		$("#sample_1").tableDnD({
			onDragClass : "myDragClass",
			onDrop : function(table, row) {
				var prevId = $(row).prev().attr("id");
				var nextId = $(row).next().attr("id")
				var selfId = $(row).attr("id")
				console.log(prevId);
				console.log(nextId);
				console.log(selfId);

				if (prevId == undefined) {
					prevId = null;
				}

				if (nextId == undefined) {
					nextId = null;
				}

				$.ajax({
					type : "POST",
					dataType : "json",
					url : "/index/itemSort",
					cache : false,
					async : true,
					data : {
						selfId : selfId,
						prevId : prevId,
						nextId : nextId
					},
					success : function(data, status) {
						alert(data);
						location.reload();
					},
					error : function(xmlHttpRequest, data, status) {
						console.log(xmlHttpRequest);
						console.log(data);
						console.log(status);
						alert(status);
					}
				});
			},

			// 如果指定了dragHandle名称，则只有该样式的列可进行拖拽
			dragHandle : "dragHandle"
		});

		// 分类列表启用状态
		var handleToggleButtons = function(ctl,url,arg) {
			if (!jQuery().toggleButtons) {
				return;
			}
			ctl.toggleButtons({
				onChange : function($el, status, e) {
					// 取得id
					var id = $($el).children().attr("id");
					var changeValue;
					if ($($el).children().attr("checked") == "checked") {
						changeValue = 1;
					} else {
						changeValue = 0;
					}

					console.log(id);
					console.log(changeValue);
					var param = "categoryId=" + id + "&" + arg + "=" + changeValue;
					$.ajax({
						dataType : "json",
						url : url,
						type : "post",
						cache : false,
						async : true,
						data : param,
						success : function(data, status) {
							alert(data);
							location.reload();
						},
						error : function(xmlHttpRequest, data, status) {
							console.log(xmlHttpRequest);
							console.log(data);
							console.log(status);
							alert(status);
						}
					});
				},
				label : {
					enabled : '启用',
					disabled : '停用'
				},
				style : {
					// Accepted values ["primary", "danger", "info", "success",
					// "warning"] or nothing
					enabled : "primary",
					disabled : "danger"
				}
			});
		};
		handleToggleButtons($("#list_available "), "./updateAvailable", "available");
		handleToggleButtons($("#list_searchable "), "./updateSearchable", "searchable");
        
        // 新增或修改表单时，提供选择
        var formToggleButtons = function (ctl) {
        	if (!jQuery().toggleButtons) {
                return;
            }
        	
        	ctl.toggleButtons({
	           	label: {
	   				enabled: '启用',
	   				disabled: '停用'
	   			},
               style: {
                   // Accepted values ["primary", "danger", "info", "success", "warning"] or nothing
                   enabled: "primary",
                   disabled: "danger"
               }
           });
        }
        formToggleButtons($("#editForm .danger-toggle-button"));
        formToggleButtons($("#addForm .danger-toggle-button"));
        
        /*
         * Insert a 'details' column to the table
         */
        var nCloneTh = document.createElement( 'th' );
        $(nCloneTh).html("查看");
        var nCloneTd = document.createElement( 'td' );
        nCloneTd.innerHTML = '<span class="row-details row-details-close"></span>';
         
        $('#sample_1 thead tr').each( function () {
            this.insertBefore( nCloneTh, this.childNodes[$(this.childNodes).size()-1] );
        } );
         
        
        $('#sample_1 tbody tr').each( function () {
        	
            this.insertBefore(  nCloneTd.cloneNode( true ), this.childNodes[$(this.childNodes).size()-1] );
        } );
         
        /*
         * Initialize DataTables, with no sorting on the 'details' column
         */
        var oTable = $('#sample_1').dataTable( {
        	
        	
        	"oLanguage": {
    			"sSearch": "搜索:",
    			"sLengthMenu": "每页显示 _MENU_ 条记录",
    		    "sZeroRecords": "Nothing found - 没有记录",
    			"sInfo": "显示第  _START_ 条到第  _END_ 条记录,共  _TOTAL_ 条记录",
    			"sInfoEmpty": "显示0条记录",
    			"oPaginate": {
    				"sPrevious": " 上一页 ",
    				"sNext":     " 下一页 ",
    				}
    		},        	
    		//初始化datatable，但对序号为0列的列不进行排序，别的列均可进行排序
            "aoColumnDefs": [
                {"bSortable": false, "aTargets": [ 0,5,6 ] }
            ],
            //开关，是否显示一个每页长度的选择条（需要分页器支持）
            "bLengthChange":false,
    
            "bProcessing":true,
            
            "aaSorting": [[1, 'asc']],
             "aLengthMenu": [
                [5, 15, 20, -1],
                [5, 15, 20, "All"] // change per page values here
            ],
            // set the initial value
            "iDisplayLength": 10,
        });

        jQuery('#sample_1_wrapper .dataTables_filter input').addClass("form-control input-small input-inline"); // modify table search input
        jQuery('#sample_1_wrapper .dataTables_length select').addClass("form-control input-small"); // modify table per page dropdown
        jQuery('#sample_1_wrapper .dataTables_length select').select2(); // initialize select2 dropdown
         
        /* Add event listener for opening and closing details
         * Note that the indicator for showing which row is open is not controlled by DataTables,
         * rather it is done here
         */
        $('#sample_1').on('click', ' tbody td .row-details', function () {
            var nTr = $(this).parents('tr')[0];
           
        
            
            var id=$(nTr).attr("id")
            
            if ( oTable.fnIsOpen(nTr) )
            {
                /* This row is already open - close it */
                $(this).addClass("row-details-close").removeClass("row-details-open");
                oTable.fnClose( nTr );
            }
            else
            {
                /* Open this row */  
            	//console.log(fnFormatDetails(id));
            	
                $(this).addClass("row-details-open").removeClass("row-details-close");
                oTable.fnOpen( nTr, fnFormatDetails(id), 'details' );
            }
        });
        
        
        
      
       
        
    }

    var initTable2 = function() {
        var oTable = $('#sample_2').dataTable( {           
            "aoColumnDefs": [
                { "aTargets": [ 0 ] }
            ],
            "aaSorting": [[1, 'asc']],
             "aLengthMenu": [
                [5, 15, 20, -1],
                [5, 15, 20, "All"] // change per page values here
            ],
            // set the initial value
            "iDisplayLength": 10,
        });

        jQuery('#sample_2_wrapper .dataTables_filter input').addClass("form-control input-small input-inline"); // modify table search input
        jQuery('#sample_2_wrapper .dataTables_length select').addClass("form-control input-small"); // modify table per page dropdown
        jQuery('#sample_2_wrapper .dataTables_length select').select2(); // initialize select2 dropdown

        $('#sample_2_column_toggler input[type="checkbox"]').change(function(){
            /* Get the DataTables object again - this is not a recreation, just a get of the object */
            var iCol = parseInt($(this).attr("data-column"));
            var bVis = oTable.fnSettings().aoColumns[iCol].bVisible;
            oTable.fnSetColumnVis(iCol, (bVis ? false : true));
        });
    }

    return {

        //main function to initiate the module
        init: function () {
            
            if (!jQuery().dataTable) {
                return;
            }

            initTable1();
            initTable2();
        }

    };
}();
