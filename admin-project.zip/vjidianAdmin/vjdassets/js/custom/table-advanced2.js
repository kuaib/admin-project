var TableAdvanced = function () {

    var initTable1 = function() {
    	
        /* Formatting function for row details */
        function fnFormatDetails (id)
        {
        	
        	alert(id);
        	var sOut = '<table>';
        	$.ajax({
     			dataType:"json",
     			url:"/index/del/",
     			data:{categoryId:id},
     			type:"post",
     			cache:false,
     			async:true,
     			success:function(data,status){
     			 	
     				sOut += '<tr><td>商品分类编码:</td><td>'+data.xxxxxxx+'</td></tr>';
     	            sOut += '<tr><td>商品分类名称:</td><td>'+data.xxxxxxx+'</td></tr>';
     	            sOut += '<tr><td>分类描述:</td><td>'+data.xxxxxxx+'</td></tr>';
     	            sOut += '<tr><td>父分类编码:</td><td>'+data.xxxxxxx+'</td></tr>';
     	            sOut += '<tr><td>父分类名称:</td><td>'+data.xxxxxxx+'</td></tr>';
     	            sOut += '<tr><td>分类级别:</td><td>'+data.xxxxxxx+'</td></tr>';
     	            sOut += '<tr><td>分类状态:</td><td>'+data.xxxxxxx+'</td></tr>';
     	            sOut += '<tr><td>分类是否允许搜索:</td><td>'+data.xxxxxxx+'</td></tr>';
     	            sOut += '<tr><td>分类展示顺序:</td><td>'+data.xxxxxxx+'</td></tr>';
     	           
     			},
     			error:function(xmlHttpRequest,data,status){
     				console.log(status);
     				console.log(data);
     			}
     		});
        	sOut += '</table>';
        	return sOut;
        	/*var aData = oTable.fnGetData( nTr );
            var sOut = '<table>';
            sOut += '<tr><td>商品分类编码:</td><td>'+aData[1]+'</td></tr>';
            sOut += '<tr><td>商品分类名称:</td><td>'+aData[2]+'</td></tr>';
            sOut += '<tr><td>分类描述:</td><td>'+aData[3]+'</td></tr>';
            sOut += '<tr><td>父分类编码:</td><td>'+aData[4]+'</td></tr>';
            sOut += '<tr><td>父分类名称:</td><td>'+aData[5]+'</td></tr>';
            sOut += '<tr><td>分类级别:</td><td>'+aData[6]+'</td></tr>';
            sOut += '<tr><td>分类状态:</td><td>'+aData[7]+'</td></tr>';
            sOut += '<tr><td>分类是否允许搜索:</td><td>'+aData[8]+'</td></tr>';
            sOut += '<tr><td>分类展示顺序:</td><td>'+aData[9]+'</td></tr>';
            sOut += '</table>';
            return sOut;*/
        }
        
        //对表格的处理要在加载table控件之前，否则分页失效
        //表格排序
       
        
        
       
        //对表格的处理要在加载table控件之前，否则分页失效
        // 分类启用状态
       /* var handleToggleButtons = function (ctl) {
        	
        	
            if (!jQuery().toggleButtons) {
                return;
            }	
            ctl.toggleButtons({
	        	 onChange: function($el, status, e) {  
	                 //$("#log").text("status = " + status);
	        		 
	        		 //取得id
	        		 var id=$($el).children().attr("id");
	        		 
	        		 console.log(id);
	        		 
	        		 //写ajax
	        		 
	                 //console.log(status);
	                 //console.log($el, status, e); 
	             },  
            	label: {
    				enabled: '启用',
    				disabled: '停用'
    			},
                style: {
                    // Accepted values ["primary", "danger", "info", "success", "warning"] or nothing
                    enabled: "danger",
                    disabled: "info"
                }
            });
        }
        handleToggleButtons($("#list_available "));
        handleToggleButtons($("#list_searchable "));
        handleToggleButtons( $("#editForm .danger-toggle-button"));*/
       
        /*
         * Insert a 'details' column to the table
         */
        var nCloneTh = document.createElement( 'th' );
        $(nCloneTh).html("查看");
        var nCloneTd = document.createElement( 'td' );
        nCloneTd.innerHTML = '<span class="row-details row-details-close"></span>';
         
        $('#sample_1 thead tr').each( function () {
            this.insertBefore( nCloneTh, this.childNodes[$(this.childNodes).size()-1] );
        } );
         
        
        $('#sample_1 tbody tr').each( function () {
        	//alert("afsdf");
            this.insertBefore(  nCloneTd.cloneNode( true ), this.childNodes[$(this.childNodes).size()-1] );
        } );
         
        /*
         * Initialize DataTables, with no sorting on the 'details' column
         */
        
        $.fn.dataTableExt.oStdClasses.sWrapper = $.fn.dataTableExt.oStdClasses.sWrapper + " dataTables_extended_wrapper";
        
        var oTable = $('#sample_1').dataTable( {
        	
        	//"sDom" : "<'row'<'col-md-8 col-sm-12'pli><'col-md-4 col-sm-12'<'table-group-actions pull-left'>>r><'table-scrollable't><'row'<'col-md-8 col-sm-12'pli><'col-md-4 col-sm-12'>r>>", // datatable layout
        	"sDom": "<'table-scrollable't><'row'<'col-md-8 col-sm-12'pli><'col-md-4 col-sm-12'>r>>",
        	"oLanguage": {
        		"sProcessing": '<img src="/vjdassets/img/loading-spinner-grey.gif"/><span>&nbsp;&nbsp;Loading...</span>',
    			"sSearch": "搜索:",
    			"sLengthMenu": "<span class='seperator'>|</span>每页显示 _MENU_ 条记录",
    		    "sZeroRecords": "Nothing found - 没有记录",
    			"sInfo": "显示第  _START_ 条到第  _END_ 条记录,共  _TOTAL_ 条记录",
    			"sInfoEmpty": "显示0条记录",
    			"oPaginate": {
    				"sPrevious": " 上一页 ",
    				"sNext":     " 下一页 ",
    				
                       
                    "sPage": "当前",
                    "sPageOf": "共"
                   
    				}
    		},        	
    		//初始化datatable，但对序号为0列的列不进行排序，别的列均可进行排序
            "aoColumnDefs": [
                {"bSortable": false, "aTargets": [ 0,5,6 ] }
            ],
            //开关，是否显示一个每页长度的选择条（需要分页器支持）
            "bLengthChange":true,
    
            "bProcessing":true,
            "sPaginationType": "bootstrap_extended",
            "aaSorting": [[1, 'asc']],
             "aLengthMenu": [
                [5, 15, 20, -1],
                [5, 15, 20, "All"] // change per page values here
            ],
            // set the initial value
            "iDisplayLength": 10,
            
            "bProcessing": true,
    		"bServerSide": true,
    		
    		
         
            "fnServerData": function ( sSource, aoData, fnCallback, oSettings ) {
                oSettings.jqXHR = $.ajax( {
                  "dataType": 'json',
                  "type": "POST",
                  "url": sSource,
                  "data": aoData,
                  "success": function(res, textStatus, jqXHR) {
                	  console.log(res);
                      if (res.sMessage) {
                    	 
                         // App.alert({type: (res.sStatus == 'OK' ? 'success' : 'danger'), icon: (res.sStatus == 'OK' ? 'check' : 'warning'), message: res.sMessage, container: tableWrapper, place: 'prepend'});
                      } 
                      if (res.sStatus) {
                          /*if (tableOptions.resetGroupActionInputOnSuccess) {
                              $('.table-group-action-input', tableWrapper).val("");
                          }*/
                      }
                     
                      /*if (tableOptions.onSuccess) {
                          tableOptions.onSuccess.call(the);
                      }*/
                      
                      fnCallback(res, textStatus, jqXHR);
                  },
                  "error": function() {
                     /* if (tableOptions.onError) {
                          tableOptions.onError.call(the);
                      }
                      App.alert({type: 'danger', icon: 'warning', message: tableOptions.dataTable.oLanguage.sAjaxRequestGeneralError, container: tableWrapper, place: 'prepend'});
                      $('.dataTables_processing', tableWrapper).remove();*/
                  }
                } );
              },
            
            
    		"sAjaxSource": "/index/categoryListAjax/",
    		 // pass additional parameter
            "fnServerParams": function ( aoData ) {
            	// var ajaxParams =[];
            	// ajaxParams.push({"name": 1, "value": 1});
            	 //aoData.push({"parentId":"1"})
                //here can be added an external ajax request parameters.
            	 //aoData.push({parentId: 1});
            	 
            	 aoData.push( { "name": "parentId",  "value": 1 } );
            },
            
            
            "aoColumnDefs": [
                                        
                             { "mData": "categoryId", "aTargets": [0], 
                                 "mRender": function ( data, type, full ) {
                                     return '<input type="checkbox" class="checker" value='+data+'" />';
                                 }
                             },
                            
                         ],  
         "fnDrawCallback": function( oSettings ) { // run some code on table redraw
        	 //table = $('#sample_1');
        	 //渲染checkbox
             //$('input[type="checkbox"]', table)).uniform();  // reinitialize uniform checkboxes on each table reload
             //countSelectedRecords(); // reset selected records indicator
         },
            
            //mData数据项，sTitle表头
            "aoColumns": [   {"mData":"categoryId"},
                             {"mData":"categoryId"},
                             {"mData":"categoryName"},
                             {"mData":"available"},
                             {"mData":"searchable"},
                             {"mData":"categoryId","mRender": function ( data, type, full ) {
                            	 
                            	var edit='<a id="'+data+'" class="showEditForm" href="#" title="编辑"><i class="fa fa-pencil-square-o operationIcon"></i></a>'
             					var del='<a id="'+data+'" class="delete" href="#" title="删除"><i class="fa fa-trash-o operationIcon"></i></a>'
                            	 
                                 return edit+" "+del;
                             }},
                             {"mData":"categoryId","mRender": function ( data, type, full ) {
                            	 return '<span class="row-details row-details-close"></span>'
                              }},
                             ]
        });
       
        //$.fn.dataTableExt.oStdClasses.sWrapper = $.fn.dataTableExt.oStdClasses.sWrapper + " dataTables_extended_wrapper";
        
        table = $('#sample_1');
        tableContainer = table.parents(".table-container");
        //App.initUniform($('input[type="checkbox"]', table))
        //$.uniform.update($('.group-checkable', table));
        // apply the special class that used to restyle the default datatable
        

    

        tableWrapper = table.parents('.dataTables_wrapper');
        
        $('.dataTables_length select', tableWrapper).addClass("form-control input-xsmall input-sm");

        
        /*// modify table per page dropdown input by appliying some classes
        $('.dataTables_length select', tableWrapper).addClass("form-control input-xsmall input-sm");

        // build table group actions panel
        if ($('.table-actions-wrapper', tableContainer).size() === 1) {
            $('.table-group-actions', tableWrapper).html($('.table-actions-wrapper', tableContainer).html()); // place the panel inside the wrapper
            $('.table-actions-wrapper', tableContainer).remove(); // remove the template container
        }*/
        
        
        jQuery('#sample_1_wrapper .dataTables_filter input').addClass("form-control input-small input-inline"); // modify table search input
        //jQuery('#sample_1_wrapper .dataTables_length select').addClass("form-control input-small"); // modify table per page dropdown
        //jQuery('#sample_1_wrapper .dataTables_length select').select2(); // initialize select2 dropdown
         
        /* Add event listener for opening and closing details
         * Note that the indicator for showing which row is open is not controlled by DataTables,
         * rather it is done here
         */
        $('#sample_1').on('click', ' tbody td .row-details', function () {
            var nTr = $(this).parents('tr')[0];
           
        
            
            var id=$(nTr).attr("id")
            
            if ( oTable.fnIsOpen(nTr) )
            {
                /* This row is already open - close it */
                $(this).addClass("row-details-close").removeClass("row-details-open");
                oTable.fnClose( nTr );
            }
            else
            {
                /* Open this row */                
                $(this).addClass("row-details-open").removeClass("row-details-close");
                oTable.fnOpen( nTr, fnFormatDetails(id), 'details' );
            }
        });
    }

    var initTable2 = function() {
        var oTable = $('#sample_2').dataTable( {           
            "aoColumnDefs": [
                { "aTargets": [ 0 ] }
            ],
            "aaSorting": [[1, 'asc']],
             "aLengthMenu": [
                [5, 15, 20, -1],
                [5, 15, 20, "All"] // change per page values here
            ],
            // set the initial value
            "iDisplayLength": 10,
        });

        jQuery('#sample_2_wrapper .dataTables_filter input').addClass("form-control input-small input-inline"); // modify table search input
        jQuery('#sample_2_wrapper .dataTables_length select').addClass("form-control input-small"); // modify table per page dropdown
        jQuery('#sample_2_wrapper .dataTables_length select').select2(); // initialize select2 dropdown

        $('#sample_2_column_toggler input[type="checkbox"]').change(function(){
            /* Get the DataTables object again - this is not a recreation, just a get of the object */
            var iCol = parseInt($(this).attr("data-column"));
            var bVis = oTable.fnSettings().aoColumns[iCol].bVisible;
            oTable.fnSetColumnVis(iCol, (bVis ? false : true));
        });
    }

    return {

        //main function to initiate the module
        init: function () {
            
            if (!jQuery().dataTable) {
                return;
            }

            initTable1();
            initTable2();
        }

    };
}();
