requirejs.config({
	//��ֹ����
	urlArgs: "bust=" +  (new Date()).getTime(),
	// ������ʾ
	baseUrl : '/branch/vjidianAdmin/vjdassets/',
	// ���Ҳ�Ҫ����'.js'�ĺ�׺����Ϊһ��path �п����Ǹ�Ŀ¼
	paths : {
		// ���ݼ��أ���cdn����ʧ�ܺ󣬴ӱ��ؼ���
		'domready':'plugins/requirejs/domReady',
		'jquery' : 'plugins/jquery/1.11.0/jquery-1.11.0',
		'bootstrap' : 'plugins/bootstrap/bootstrap.min',
		'app' : 'js/core/app',
		'jquery-pack' : 'js/module/jquery-pack',
		'jquery.cookie' : 'js/module/jquery.cookie',
		'moment' : 'plugins/moment/moment.min',// ����ʱ�����http://momentjs.com/
		'moment-lang-zh-cn' : 'plugins/moment/zh-cn',// ����ʱ������������԰�
		//-------------------�����ؼ�--------------
		'jquery-slimscroll' : 'plugins/jquery-slimscroll/jquery.slimscroll.min',//������
		'alert':'js/module/bootstrap-alert',//Alert��ʾ��
		'dropdownlist' : 'plugins/select2/select2',//�����б�
		'bootstrap-select' : 'plugins/bootstrap-select/bootstrap-select',//�����б�
		'multi-select' : 'plugins/jquery-multi-select/jquery.multi-select',//�����б�
	
		'cascadeselect':'js/module/cascadeselect',//���޼���
		'bootstrap-cascadeselect':'js/module/bootstrap-cascadeselect',//bootstrap���޼���
		"viewcode":"js/module/highlight",//���������ʵ
		"jstree" : "plugins/jquery-jstree3/jstree",// ���������ͼhttp://www.jstree.com/
		"uniform" : 'plugins/uniform/jquery.uniform.min',//�����굥�ؼ�����
		"switch-button" : 'js/module/switch-button',//ѡ��ť
		"bootstrap-dialog" : 'plugins/bootstrap3-dialog/bootstrap-dialog',//�Ի���
	
		'viewcode':'js/module/highlight',//���������ʵ
		'jstree' : 'plugins/jquery-jstree3/jstree',// ���������ͼhttp://www.jstree.com/
		'ztree' : 'plugins/jquery-ztree/jquery.ztree.core-3.5',// ���������ͼhttp://www.ztree.me/v3/
		'ztree-excheck' : 'plugins/jquery-ztree/jquery.ztree.excheck-3.5',// ���������ͼ-ѡ�����http://www.ztree.me/v3/
		'uniform' : 'plugins/uniform/jquery.uniform.min',//�����굥�ؼ�����
		'switch-button' : 'js/module/switch-button',//ѡ��ť
		'bootstrap-dialog' : 'plugins/bootstrap3-dialog/bootstrap-dialog',//�Ի���
		'nice-validator' : 'plugins/nice-validator/jquery.validator',//������֤
		'nice-validator-zh_CN' : 'plugins/nice-validator/zh_CN',//������֤
		'bootstrapValidator':'plugins/bootstrapValidator/bootstrapValidator',//bootstrapValidator������֤
		'ueditor':'plugins/ueditor/ueditor.all',//���ı��༭
		'maxlength':'plugins/bootstrap-maxlength/bootstrap-maxlength.min',//�ı���󳤶���ʾ
		//----------------����ʱ��ѡ����ؿؼ�----------------
		'bootstrap-datepicker' : 'plugins/bootstrap-datepicker/bootstrap-datepicker',
		'daterangepicker' : 'plugins/daterangepicker/daterangepicker',// ���ڷ�Χѡ��
		'datetimepicker':'plugins/bootstrap-datetimepicker/js/bootstrap-datetimepicker.min',
		'datetimepicker-zh-CN':'plugins/bootstrap-datetimepicker/js/locales/bootstrap-datetimepicker.zh-CN',
		//-------------------����ؼ���-----------------
		'jquery.dataTable' : 'plugins/data-tables/jquery.dataTables',//���ݱ���ؼ�
		'tableDnD' : 'plugins/tableDnD/jquery.tablednd_0_5',//������ק�ؼ�
		'DT_bootstrap' : 'plugins/data-tables/DT_bootstrap',
		'data-grid-assemble':'js/module/dataGrid',
		'datatables':'plugins/data-grid/js/jquery.dataTables',
		'data-grid-bootstrap':'plugins/data-grid/bootstrap/dataTables.bootstrap',
		'data-grid-lang-zh':'plugins/data-grid/plugins/i18n/Chinese.lang',
		'datatables-colvis':'plugins/data-grid/plugins/ColVis-1.1.0/js/dataTables.colVis',
		'datatables-fixedcolumns':'plugins/data-grid/plugins/fixedcolumns/js/dataTables.fixedColumns',
		'datatables-colreorder':'plugins/data-grid/plugins/ColReorder-1.1.1/js/dataTables.colReorder',
		'datatables-scroller':'plugins/data-grid/plugins/Scroller-1.2.1/js/dataTables.scroller',
		//------------------ͼƬ�ϴ��ؼ���----------------
		'fileuploadinlistvie':'js/module/fileuploadinlistvie',
		'fileuploadingridview':'js/module/fileuploadingridview',
		'fileuploadingridviewexamine':'js/module/fileuploadingridviewexamine',
		'fileuploadingridviewexcel':'js/module/fileuploadingridviewexcel',
		'fileuploadingridviewmanufacturerexcel':'js/module/fileuploadingridviewmanufacturerexcel',
		'jquery.ui.widget':'plugins/jquery-ui/jquery.ui.widget',
		'load-image':'plugins/JavaScript-Load-Image/load-image',
		'load-image-meta':'plugins/JavaScript-Load-Image/load-image-meta',
		'load-image-ios':'plugins/JavaScript-Load-Image/load-image-ios',
		'load-image-exif':'plugins/JavaScript-Load-Image/load-image-exif',
		'canvas-to-blob':'plugins/JavaScript-Canvas-to-Blob/canvas-to-blob.min',
		'jquery.iframe-transport':'plugins/jquery-file-upload/jquery.iframe-transport',
		'jquery.fileupload-image':'plugins/jquery-file-upload/jquery.fileupload-image',
		'jquery.fileupload':'plugins/jquery-file-upload/jquery.fileupload',
		'jquery.filedownload':'plugins/jquery-file-download/jquery.fileDownload',
		'jquery.filedownload.shCore':'plugins/jquery-file-download/shCore',
		'jquery.filedownload.shBrushJScript':'plugins/jquery-file-download/shBrushJScript',
		'jquery.filedownload.shBrushXml':'plugins/jquery-file-download/shBrushXml',
		'jquery.fileupload-process':'plugins/jquery-file-upload/jquery.fileupload-process',
		'jquery.fileupload-validate':'plugins/jquery-file-upload/jquery.fileupload-validate',
		'jquery.fileupload-ui':'plugins/jquery-file-upload/jquery.fileupload-ui',
		'jquery.fileexcelupload-ui':'plugins/jquery-file-upload/jquery.fileexcelupload-ui',
		'tmpl':'plugins/JavaScript-Templates/tmpl.min',
		'blueimp-gallery':'plugins/blueimp-gallery/js/blueimp-gallery',
		'blueimp-helper':'plugins/blueimp-gallery/js/blueimp-helper',
		'blueimp-gallery-video':'plugins/blueimp-gallery/js/blueimp-gallery-video',
		'blueimp-gallery-fullscreen':'plugins/blueimp-gallery/js/blueimp-gallery-fullscreen',
		'blueimp-gallery-indicator':'plugins/blueimp-gallery/js/blueimp-gallery-indicator',
		'fileinput':'plugins/bootstrap-fileinput/bootstrap-fileinput',
		'fileinput-multiple':'plugins/bootstrap-fileinput-multiple/js/fileinput',
		
		
		//----------------ͼ���ؼ�------------------
		'flot':'plugins/jquery-flot/jquery.flot.min',
		'flot-pie':'plugins/jquery-flot/jquery.flot.pie.min',
		'flot-categorie':'plugins/jquery-flot/jquery.flot.categories.min',
		'flot-resize':'plugins/jquery-flot/jquery.flot.resize.min',
		//----------------ͼƬչʾ------------------
		'mixitup':'plugins/jquery-mixitup/jquery.mixitup.min',
		'fancybox':'plugins/fancybox/jquery.fancybox.pack',
		'blockui':'plugins/jquery.blockui.min',
		//----------------���Ƶ����а�---------------
		'zclip':'plugins/jquery-zclip/jquery.zclip',
		//----------------֪ͨ��ʾ------------------
		'notific8':'plugins/jquery-notific8/jquery.notific8.min',
		'toastr':'plugins/bootstrap-toastr/toastr.min',
		'layer':'plugins/layer/layer',
		//----------------��ҳ�ؼ�------------------
		'paging':'plugins/jquery-paging/jquery.paging',
		//-----------------��ɫѡ����---------------------
		'colorpicker':'plugins/spectrum/spectrum',
		//-----------------���ݿ��ӻ�---------------
		'd3':'plugins/d3/d3',
		//-----------------ģ��---------------
		'template':'plugins/template/template',
        'vue':'plugins/vue/vue',
		//-----------------��ҳ���---------------
		'pagination':'plugins/pagination/js/pagination.min',
		'jqueryPagination':'plugins/jqueryPagination/jqueryPagination',
	},
	
	// ��ʽ����amdģ��
	shim : {
		'bootstrap' : {
			deps : [ 'jquery' ]
		},
		'jquery-slimscroll':{
			deps : ['jquery']
		},
		'uniform' : {
			deps : [ 'jquery',
					'css!/vjidianAdmin/vjdassets/plugins/uniform/uniform.default' ]
		},
		'app' : {
			deps : ['bootstrap', 'jquery-slimscroll','uniform',
					'css!/vjidianAdmin/vjdassets/css/plugins' ]
		},
		'tmpl':{
			deps : ['jquery']
		},
		'blueimp-gallery':{
			deps : ['jquery',
			        'css!/vjidianAdmin/vjdassets/plugins/blueimp-gallery/css/blueimp-gallery.min',]
		}, 
		'jquery.fileupload-ui':{
			deps : ['jquery','tmpl',
		            'jquery.fileupload-image','jquery.fileupload-validate',
		    		'css!/vjidianAdmin/vjdassets/plugins/jquery-file-upload/css/jquery.fileupload',
		    		'css!/vjidianAdmin/vjdassets/plugins/jquery-file-upload/css/jquery.fileupload-ui']
		},
		'jquery.fileexcelupload-ui':{
			deps : ['jquery','tmpl',
		            'jquery.fileupload-image','jquery.fileupload-validate',
		    		'css!/vjidianAdmin/vjdassets/plugins/jquery-file-upload/css/jquery.fileupload',
		    		'css!/vjidianAdmin/vjdassets/plugins/jquery-file-upload/css/jquery.fileupload-ui']
		},
		'jquery.filedownload':{
			deps:['jquery']
		},
		'dropdownlist' : {
			deps : [ 'css!/vjidianAdmin/vjdassets/plugins/select2/select2',
					'css!/vjidianAdmin/vjdassets/plugins/select2/select2-metronic' ]
		},
		'daterangepicker' : {
			deps : [ 'jquery', 'moment', 'moment-lang-zh-cn',
					'css!/vjidianAdmin/vjdassets/plugins/daterangepicker/daterangepicker-bs3' ]
		},
		'datetimepicker':{
			deps:['bootstrap',
			      'css!/vjidianAdmin/vjdassets/plugins/bootstrap-datetimepicker/css/bootstrap-datetimepicker.min']
		},
		'datetimepicker-zh-CN':{deps:['datetimepicker']},
		'ztree' : {
			deps : [ 'jquery',
					'css!/vjidianAdmin/vjdassets/plugins/jquery-ztree/zTreeStyle/zTreeStyle' ]
		},
		'ztree-excheck' : {
			deps : [ 'jquery','ztree',
					'css!/vjidianAdmin/vjdassets/plugins/jquery-ztree/zTreeStyle/zTreeStyle' ]
		},
		'jstree' : {
			deps : [ 'jquery',
					'css!/vjidianAdmin/vjdassets/plugins/jquery-jstree3/themes/default/style.min' ]
		},
		'tableDnD' : {
			deps : [ 'jquery' ]
		},
		'DT_bootstrap' : {
			deps : [ 'jquery', 'jquery.dataTable',
					'css!/vjidianAdmin/vjdassets/plugins/data-tables/DT_bootstrap' ]
		},
		'bootstrap-dialog' : {
			deps : [ 'jquery', 'bootstrap',
					'css!/vjidianAdmin/vjdassets/plugins/bootstrap3-dialog/bootstrap-dialog' ]
		},
		'nice-validator' : {
			deps : [ 'jquery',
					'css!/vjidianAdmin/vjdassets/plugins/nice-validator/jquery.validator' ]
		},
		'nice-validator-zh_CN' : {
			deps : [ 'jquery','nice-validator']
		},
		'bootstrap-datepicker' : {
			deps : [ 'jquery',
					'css!/vjidianAdmin/vjdassets/plugins/bootstrap-datepicker/datepicker' ]
		},
		'bootstrap-select' : {
			deps : [ 'jquery',
					'css!/vjidianAdmin/vjdassets/plugins/bootstrap-select/bootstrap-select' ]
		},
		'multi-select' : {
			deps : [ 'jquery',
					'css!/vjidianAdmin/vjdassets/plugins/jquery-multi-select/multi-select' ]
		},
		
		'ueditor' : {
			deps : [ '/vjidianAdmin/vjdassets/plugins/ueditor/ueditor.config.js'	         
					  ]
		},
		'maxlength' : {
			deps : ['jquery']
		},
		'flot' : {
			deps : ['jquery']
		},
		'flot-categorie':{
			deps:['flot']
		},
		'flot-pie':{
			deps:['flot']
		},
		'flot-resize':{
			deps:['flot']
		},
		'fileinput':{
			deps:['jquery','bootstrap','jquery.fileupload-ui','css!/vjidianAdmin/vjdassets/plugins/bootstrap-fileinput/bootstrap-fileinput.css']
		},
		'data-grid-core':{
			deps:['bootstrap','css!/vjidianAdmin/vjdassets/plugins/data-grid/css/jquery.dataTables']
		},
		'data-grid-bootstrap':{
			deps:['datatables','data-grid-lang-zh','css!/vjidianAdmin/vjdassets/plugins/data-grid/bootstrap/dataTables.bootstrap']
		},
		'datatables-colvis':{
			deps:['datatables','css!/vjidianAdmin/vjdassets/plugins/data-grid/plugins/ColVis-1.1.0/css/dataTables.colVis']
		},
		'datatables-fixedcolumns':{
			deps:['datatables','css!/vjidianAdmin/vjdassets/plugins/data-grid/plugins/fixedcolumns/css/dataTables.fixedColumns']
		},
		'cascadeselect':{
			deps:['jquery']
		},
		'bootstrap-cascadeselect':{
			deps:['jquery']
		},
		'datatables-colreorder':{
			deps:['datatables','css!/vjidianAdmin/vjdassets/plugins/data-grid/plugins/ColReorder-1.1.1/css/dataTables.colReorder']
		},
		'datatables-scroller':{
			deps:['datatables','css!/vjidianAdmin/vjdassets/plugins/data-grid/plugins/Scroller-1.2.1/css/dataTables.scroller']
		},
		'mixitup':{
			deps:['jquery']
		},
		'fancybox':{
			deps:['jquery','css!/vjidianAdmin/vjdassets/plugins/fancybox/jquery.fancybox']
		},
		'blockui':{
			deps:['jquery']
		},
		'zclip':{
			deps:['jquery']
		},
		'notific8':{
			deps:['jquery','css!/vjidianAdmin/vjdassets/plugins/jquery-notific8/jquery.notific8.min']
		},
		'toastr':{
			deps:['jquery','css!/vjidianAdmin/vjdassets/plugins/bootstrap-toastr/toastr.min']
		},
		'paging':{
			deps:['jquery']
		},
		'colorpicker':{
			deps:['jquery','css!/vjidianAdmin/vjdassets/plugins/spectrum/spectrum']
		},
		'fileinput-multiple':{
			deps:['jquery','css!/vjidianAdmin/vjdassets/plugins/bootstrap-fileinput-multiple/css/fileinput.min']
		},
		'layer':{
			deps:['jquery','css!/vjidianAdmin/vjdassets/plugins/layer/skin/default/layer.css']
		},
		// ��ҳ���css
		'pagination': {
			deps: ['jquery', 'css!/branch/vjidianAdmin/vjdassets/plugins/pagination/css/pagination']
		},
		'jqueryPagination':{
			deps: ['jquery']
		}
	},
	// ����cssjs���
	map : {
		'*' : {'css' : 'plugins/requirejs/require-css/css'}
		
	}
});
