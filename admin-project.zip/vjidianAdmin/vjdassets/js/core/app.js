/**
Core script to handle the entire theme and core functions
**/
var website_address="http://cc.vjidian.com/";//正式

function getCookie(name){
    var arr,reg=new RegExp("(^| )"+name+"=([^;]*)(;|$)");
    if(arr=document.cookie.match(reg))
       return unescape(arr[2]);
    else
       return null;
}
var ticketc = getCookie("ticketc");
//登录判断
$.ajax({
    type: "POST",
    url: website_address+"vjidian-auth/valid",
    data: {
        ticketc:ticketc||"vjidian"
    },
    dataType: "json",
    success: function(data){
            if(data == false){
                location.href = website_address;
            }
    }
});
function Vjidian(){}
Vjidian.prototype.init = function (){
    console.log("欢迎访问V机电后台管理系统");
}
var App = new Vjidian();