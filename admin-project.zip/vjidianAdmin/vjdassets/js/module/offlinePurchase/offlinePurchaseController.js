define([ 'jquery' ], function($) {
	'use strict';
	var root='https://admin.vjidian.com/4005/offlinePurchase';
	//定义全部请求的Controller
	var controllers = {
		page:{url:root+'/page',data:{}},
		editView:{url:root+'/editView'},
		update:{url:root+'/update',data:{}},
	};

	function _ajax(controller,success,error) {
		var ajaxOptions=$.extend(true,controller,{
			type:'POST',
			dataType:'JSON',
			success:success,
			error:error
		});
		$.ajax(ajaxOptions);
	}

	function _editView(id){
		return controllers.editView.url + '/' + id;
	}

	function _update(data,success,error){
		controllers.update.data=data;
		_ajax(controllers.update,success,error);
	}

	return {
		editView:_editView,
		update:_update,
		controllers:controllers
	};
});
