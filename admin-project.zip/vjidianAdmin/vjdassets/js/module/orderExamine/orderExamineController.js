/**
 * 订单管理
 */
define(['jquery'], function($) {
	"use strict";

	var root = "https://admin.vjidian.com/816/orderExamine";

	var controllers = {
		show: {
			url: root + '/show'
		},
		orderExamine: {
			url: root + '/orderExamine',
			type:'POST',
			dataType:'JSON',
			data: {}
		},
		orderExamineshow :{
			url: root + '/orderExamineshow'
		},
	};

	function _ajax(controller, success, error) {
		var ajaxOptions = $.extend(true, controller, {
			type: 'POST',
			dataType: 'JSON',
			success: success,
			error: error
		});
		$.ajax(ajaxOptions);
	};
	function _orderExamine(data,success,error){
		controllers.orderExamine.data.orderExamineJSON=JSON.stringify(data);
		_ajax(controllers.orderExamine,success,error);
	};
	return {
		controllers: controllers,
		orderExamine:_orderExamine,
	};
});
