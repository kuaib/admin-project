
define(['jquery','bootstrap-dialog'], function( $,BootstrapDialog ) {
	var alert=function(message){
		
		var options = {};
        var defaultOptions = {
            type: BootstrapDialog.TYPE_PRIMARY,
            title: "提示消息",
            message: null,
            closable: true,
            buttonLabel: '确定',
            callback: null
        };

        if (typeof arguments[0] === 'object' && arguments[0].constructor === {}.constructor) {
            options = $.extend(true, defaultOptions, arguments[0]);
        } else {
            options = $.extend(true, defaultOptions, {
                message: arguments[0],
                closable: false,
                buttonLabel: '确定',
                callback: typeof arguments[1] !== 'undefined' ? arguments[1] : null
            });
        }		
		return  BootstrapDialog.alert(options);
	}
	
	var confirm=function(title,message, callback) {
        return new BootstrapDialog({
            title: title,
            message: message,
            closable: false,
            data: {
                'callback': callback
            },
            buttons: [{
                    label: '取消',
                    action: function(dialog) {
                        typeof dialog.getData('callback') === 'function' && dialog.getData('callback')(false,dialog);
                        dialog.close();
                    }
                }, {
                    label: '确定',
                    cssClass: 'btn-primary',
                    action: function(dialog) {
                        typeof dialog.getData('callback') === 'function' && dialog.getData('callback')(true,dialog);
                        dialog.close();
                    }
                }]
        }).open();
    }
	/** 
     *    onShown form表单加载完成后的回调函数
    */
	var form=function(title,form, callback,onShown) {
		
		require(['nice-validator'], function() { 
            if(onShown){
                BootstrapDialog.defaultOptions.onshown = onShown;
                //console.log(BootstrapDialog.defaultOptions);
            }

	        BootstrapDialog.show({
	            title: title,
	            message: form,
	            data: {
	                'callback': callback
	            },
                closable: false,
	            buttons: [{
		                label: '取消',
		                action: function(dialog) {
                            typeof dialog.getData('callback') === 'function' && dialog.getData('callback')(false,dialog);
		                    dialog.close();
		                }
	            	},
	            	{
	            		label: '保存',
	            		cssClass: 'btn-primary',
	            		action: function(dialog) {
	            			 typeof dialog.getData('callback') === 'function' && dialog.getData('callback')(true,dialog);
	            		}
	            }]
	        })
		})  
    }
	
	return {
		alert:alert,
		confirm:confirm,
		form:form
    };
});



