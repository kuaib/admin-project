define(['jquery'], function($) {
	'use strict';
	var root='https://admin.vjidian.com/8006/region';
	//定义全部请求的Controller
	var controllers = {
		//增加Controller
		add:{url:root+'/add',data:{}},
		addView:{url:root+'/operate/add/'},
		//更新Controller
		update:{url:root+'/update',data:{}},
		//editView
		editView:{url:root+'/operate/edit/'},
		//级联关系地址
		findRegionByPId:{url:root+'/findRegion'},
		//删除
		del:{url:root+'/delete',data:{}},
		show:{url:root+'/show'},
		getPage:{url:root+'/findPage',data:{}},
		//根据父亲Id查询子区域
		getChilden:{url:root+'/findChildren',data:{}},
		getAll:{url:root+'/findAll',data:{}},
		recoverData:{url:root+'/recoverData',data:{}},
		//批量删除
		batchDelete:{url:root+'/batchDelete',data:{}},
		//批量更新序列
		batchUpdateSequence:{url:root+'/batchUpdateSequence',data:{}},
		//更新状态
		updateStatus:{url:root+'/updateStatus',data:{}}
	};
	function _ajax(controller,success,error) {
		var ajaxOptions=$.extend(true,controller,{
			success:success,
			error:error,
			type: 'POST',
			dataType: 'JSON'
		});
		$.ajax(ajaxOptions);
	}
	function _add(data,success,error){
		controllers.add.data=data;
		_ajax(controllers.add,success,error);
	};
	function _update(data,success,error){
		controllers.update.data=data;
		_ajax(controllers.update,success,error);
	};
	function _del(id,success,error) {
		controllers.del.data.id=id;
		_ajax(controllers.del,success,error);
	}
	
	function _getPage(data,success,error) {
		controllers.getPage.data=data;
		_ajax(controllers.getPage,success,error);
	}
	function _getChilden(id,success,error) {
		controllers.getChilden.data.id=id;
		_ajax(controllers.getChilden,success,error);
	}
	function _getAll(data,success,error) {
		controllers.getAll.data=data;
		_ajax(controllers.getAll,success,error);
	}
	function _recoverData(data,success,error) {
		controllers.recoverData.data=data;
		_ajax(controllers.recoverData,success,error);
	}
	function _batchDelete(ids,success,error) {
		controllers.batchDelete.data.ids=ids;
		_ajax(controllers.batchDelete,success,error);
	}
	
	function _batchUpdateSequence(sequences,success,error) {
		controllers.batchUpdateSequence.data.sequences=sequences;
		_ajax(controllers.batchUpdateSequence,success,error);
	}
	function _updateStatus(data,success,error) {
		controllers.updateStatus.data=data;
		_ajax(controllers.updateStatus,success,error);
	}
	return {
		controllers:controllers,
		add:_add,
		update:_update,
		del:_del,
		getPage:_getPage,
		getChilden:_getChilden,
		getAll:_getAll,
		recoverData:_recoverData,
		batchDelete:_batchDelete,
		batchUpdateSequence:_batchUpdateSequence,
		updateStatus:_updateStatus
	};
});
