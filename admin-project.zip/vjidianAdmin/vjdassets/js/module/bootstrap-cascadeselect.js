/**
 * 级联下拉菜单
 * 修订人 刘仁峰
 */
define(['jquery'], function ($) {
	(function ($) {
		$.extend($.fn, {
			cascadeSelect: function (options) {

				/**
				 * @config 默认参数
				 */
				var settings = {
					/**
					 * @param 数据获取url
					 */
					url: '',
					/**
					 * @param 数据获取参数名称
					 */
					parameter: 'pid',
					otherParameter:{},
					/**
					 * @param 定义JSON数据格式：选择名称
					 */
					text: 'text',
					/**
					 * @param 定义JSON数据格式：选择值
					 */
					value: 'value',
					/**
					 * @param
					 */
					hasChildren: 'children',
					/**
					 * @param 选择提示,null表示无提示
					 */
					emptyOption: '请选择',
					/**
					 * @param 下拉框css名称
					 */
					emptyValue:-1,
					cssClass: 'cascadeSelect',
					/**
					 * 下拉框左右css样式
					 */
					cssStyle: {
						'margin-right': '10px'
					},
					/**
					 *
					 */
					selectGroupName: 'cascadeSelectGroup',
					/**
					 *
					 */
					rootId: 0,
					
					/**
					 * 最大级别  
					 * 0 为 无限
					 */
					maxLevel:0,
					/**
					 *
					 */
					onchange: null,
					/**
					 *
					 */
					selectedValue:[]
				};
				$.extend(settings, options);
				var $this = $(this);
				$this.data('sequence',-1);
				$this.hide();

				require(['js/module/select'], function (select) {
					var curMaxLevel =0;
					options.firstControl = addSelect($this);
					
					// 增加select
					function addSelect(element, selected) {
						var $nextSelect;
						var sequence = 1 + element.data('sequence');
						var defaultValue = null;
						if( curMaxLevel <= 0 && settings.maxLevel != 0 ) curMaxLevel = settings.maxLevel;//如果当前级别小于0 并且最大级别不等于0 则初始化当前级别
						if( curMaxLevel > 0 && settings.maxLevel != 0  ) curMaxLevel = curMaxLevel - sequence; //如果 序号大于0 并且最大级别不等于0 则代表不是第一级，所以设置当前级别；
						else curMaxLevel = settings.maxLevel; //否则 只有一个下拉
						
						if(settings.selectedValue){
							if(settings.selectedValue.length > 0){
								defaultValue = settings.selectedValue[sequence];								
							}
						}
						if (element.is('select')) {

							var hasChilds = element.find('option:selected').attr('hasChild');
							//销毁所有下级
							select.destroy(element.nextAll('select[name="' + settings.selectGroupName + '"]'));

							if (element.val() == "" || ( settings.maxLevel != 0 && curMaxLevel<=0 )) {
								return;
							}
							//console.log(hasChilds);
							if (hasChilds == 'true') {
								element.next('div.bootstrap-select')
									.after('<select class="' + settings.cssClass + '" name="' + settings.selectGroupName + '"></select>');
								$nextSelect = element.next('div.bootstrap-select').next('select[name="' + settings.selectGroupName + '"]');
								$nextSelect.data('sequence', sequence);
								element.next('div.bootstrap-select').css(settings.cssStyle);
								fillOption($nextSelect, element.val());
								select.onchange($nextSelect, bindSelect);
								select.initByCtl($nextSelect);
								if(defaultValue)select.setValue($nextSelect,defaultValue);				
							}
						} else {
							element.after('<select class="' + settings.cssClass + '" name="' + settings.selectGroupName + '" data-live-search="true"></select>');
							$nextSelect = element.next('select[name="' + settings.selectGroupName + '"]');
							fillOption($nextSelect, settings.rootId);
							select.onchange($nextSelect, bindSelect);
							select.initByCtl($nextSelect);		
							$nextSelect.data('sequence', sequence);
							if(defaultValue)select.setValue($nextSelect,defaultValue);
						}

						element.css(settings.cssStyle);
						
						return $nextSelect;
					}

					// 绑定Select元素
					function bindSelect(element) {
						
						var value = select.getValue(element);
						$this.val(value);
						addSelect(element);
						$this.attr('data-name', element.find('option:selected').text());
						
						if (typeof settings.onchange === 'function') {
							element.change=settings.onchange(element, value);
						}
					}
				});


				// 获取Json数据
				function fillOption(element, key) {
					var sendData = {};
					sendData[settings.parameter] = key;
					for(var name in settings.otherParameter){
						sendData[name] = settings.otherParameter[name];
					}
//					console.log(sendData);
					$.ajax({
						dataType: 'json',
						type: 'post',
						url: settings.url,
						async: false,
						data: sendData,
						success: function (data) {
							if (data && data.length >= 0){
								element.empty();
								if (settings.emptyOption != null) {
									var defaultOption = $('<option>',{val:settings.emptyValue,text:settings.emptyOption});
									element.append(defaultOption);
								}
								$.each(data, function (id, object) {
									var option = $('<option>',{val:object[settings.value],hasChild:object[settings.hasChildren],text:object[settings.text]});
									element.append(option);
								});
							  } else {
								element.remove();
							}
						},
						error: function (xmlHttpRequest, data, status) {
							 element.remove();
							 // console.log(xmlHttpRequest);
							// console.log(data);
							// console.log(status);
						}
					});
				}
			}
		});
	})($);
});