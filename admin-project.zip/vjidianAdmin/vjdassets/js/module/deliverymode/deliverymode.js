define(['js/module/deliverymode/deliverymodeController','nice-validator-zh_CN','ueditor'], function(deliverymodeController) {
	
	function getDeliverymodeObj(){
		var deliverymodeObj = $('#frm_deliverymode').serializeObject();
		deliverymodeObj.remark=UE.utils.unhtml(UE.getEditor('ue_remark').getContent());
		deliverymodeObj.remarkEN=UE.utils.unhtml(UE.getEditor('ue_remarkEN').getContent());
		return deliverymodeObj;
	}
	
	var _add=function(){
		var deliverymode=getDeliverymodeObj();
		var submitSuccess=function(data){
		    if(data.result){
				$.Success(data.tip);
				window.setInterval(function(){     
					location.href = deliverymodeController.controllers.show.url; 
			    },2000);
				
			}else{
				$.Warn(data.tip);
		 	}
		};
		//提交表单
		deliverymodeController.add(deliverymode,submitSuccess);
	}
	
	var _update=function(){
		var deliverymode=getDeliverymodeObj();
		//console.log(deliverymode);
		//return false;
		deliverymode.id=$("#txt_deliverymodeId").val();
		var submitSuccess=function(data){
		    if(data.result){
				$.Success(data.tip);
				window.setInterval(function(){     
					location.href = deliverymodeController.controllers.show.url; 
			    },2000);
				
			}else{
				$.Warn(data.tip);
		 	}
		};
		//提交表单
		deliverymodeController.update(deliverymode,submitSuccess);
	}
	
	return {
		add:_add,
		update:_update,
	}
})