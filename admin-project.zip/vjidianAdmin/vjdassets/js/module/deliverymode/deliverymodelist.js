define(['js/module/deliverymode/deliverymodeController','data-grid-assemble','js/module/pageControls'], function(deliverymodeController,dataGrid) {
	
	//datatable配置
	var options={
		table:$('#tbl_deliverymode'),
		deferRender: true,
		showChecked:false,
		dom:'t',
		//定义列
		columns:[ 
 			{title:"配送方式名称",data:"name",order: ["desc"],width:"40%",className:"text-left",orderable:false },
 			{title:"配送方式名称(英)",data:"nameEN",width:"40%",orderable : false,orderable:false},
			{title:"显示顺序",data:"sequence",width:"10%",className:"text-left" ,orderable:false},
		],
		ajax:{
		 	url:deliverymodeController.controllers.getPage.url,
		 	data:function(d){
				var data = $.extend({}, d, {
	    			searchContent: $.trim($('#txt_searchContent').val()),
	    			iDisplayLength: $('#hid_pageSize').val(),
	    			iDisplayStart: $('#hid_pageNum').val(),
	    			searchKey: $('#sel_searchType a.curr').data('search'),
				});
				return data;
			}
		},
		//定义操作列
		actions:{
			edit:{
				className:null,
				tip:'',
				fn:edit
			},
			delete:{
				className:null,
				tip:'删除',
				fn:deleteDeliverymode
			},
		},
	};

	//编辑
	function edit(){
		var url =deliverymodeController.controllers.edit.url;
		window.location.href=url+$(this).data('id');
	}
	
	//初始化table
	var jqTable=dataGrid.init(options);
	
	//$(function() {
		//刷新数据
		//$('#btn_refresh').on('click',refreshTable);
	//})
	
	require(['nice-validator'], function() { 
		$.validator.config({
	        messages: {
	            length: {
	                eq: '请输入{1}个字符',
	                rg: '请输入{1}到{2}个字符',
	                gt: '请至少输入{1}个字符',
	                lt: '请最多输入{1}个字符',
	                eq_2: "",
	                rg_2: "",
	                gt_2: "",
	                lt_2: ""
	            }
	        }
	    });
		//去掉icon
		$.validator.setTheme({
			'default': {
                showOk: false
            }
	    });
	})
	
    //删除
    function deleteDeliverymode(e){
    	e.preventDefault();
    	var id=$(this).data("id");
    	require(['js/module/bootstrap-dialog'], function(dialog) {
 			dialog.confirm('删除配送方式信息','<i class="fa fa-exclamation-triangle"></i><span>确定要删除吗?</span>', function(result){
 				if(result) {
	            	var deleteSuccess=function(data){
	            		if(data.result){
	     					$.Success(data.tip);
	     					refreshTable();
	     				}else{
	     					$.Warn(data.tip);
	     			 	}
    				};
    				deliverymodeController.del(id,deleteSuccess);	    			
	            };
		    });
		});
    }


    //回车搜索
    function searchEnter(e){
		if(e.keyCode==13){
			//重绘表格,会在fnServerData方法里传递参数
			refreshTable();
		}
	}

    function refreshTable(){
    	jqTable.fnDraw();
	}
    
    //搜索按钮
	function searchBtn(){
		refreshTable();
	}
	
})