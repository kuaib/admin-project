define([ 'jquery' ], function($) {
	'use strict';
	var root='https://admin.vjidian.com/5002/deliverymode';
	//定义全部请求的Controller
	var controllers = {
		getPage:{url:root+'/page',type:'POST',dataType:'JSON',data:{}},
		add:{url:root+'/add',type:'POST',dataType:'JSON',data:{}},
		update:{url:root+'/update',type:'POST',dataType:'JSON',data:{}},
		edit:{url:root+'/operate/edit/'},
		del:{url:root+'/delete',type:'POST',dataType:'JSON',data:{}},
		show:{url:root+'/show'},
		view:{url:root+'/view/'},
	};
	function _ajax(controller,success,error) {
		var ajaxOptions=$.extend(true,controller,{success:success,error:error});
		$.ajax(ajaxOptions);
	}
	function _add(data,success,error){
		controllers.add.data=data;
		_ajax(controllers.add,success,error);
	}
	function _update(data,success,error){
		controllers.update.data=data;
		_ajax(controllers.update,success,error);
	}
	function _getPage(data,success,error) {
		controllers.getPage.data=data;
		_ajax(controllers.getPage,success,error);
	}
	function _del(id,success,error) {
		controllers.del.data.id=id;
		_ajax(controllers.del,success,error);
	}
	return {
		add:_add,
		update:_update,
		getPage:_getPage,
		del:_del,
		controllers:controllers
	};
});