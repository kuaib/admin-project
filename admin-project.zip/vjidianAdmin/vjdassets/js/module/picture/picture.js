/**
 * 图片领域对象
 */
define(['jquery'], function($){
	'use strict';
	var root='https://admin.vjidian.com';
	//定义全部请求的Controller
	var controllers={
		deletePicture:{url:root+'/picture/delete',type:'POST',data:{pictureId:''}},
		deleteProductPicture:{url:root+'/304/product/deletePicture',type:'POST',data:{pictureId:''}}
	};
	/**
	 * private
	 */
	function _ajax(controller,success,error,param) {
		var ajaxOptions=$.extend(true,controller,{success:function(data){
			if(data){
				if(param){
					success(data,param);
				}else{
					success(data);
				}
			}
		},error:error});
		$.ajax(ajaxOptions);
	}
	/**
	 * private
	 */
	function _deletePicture(pictureId,success){
		controllers.deletePicture.data.pictureId = pictureId;
		_ajax(controllers.deletePicture,success);
	}
	/**
	 * private
	 */
	function _deleteProductPicture(pictureId,success,error,param){
		controllers.deleteProductPicture.data.pictureId=pictureId;
		_ajax(controllers.deleteProductPicture,success,error,param);
	}
	return {
		deletePicture:_deletePicture,
		deleteProductPicture:_deleteProductPicture
	};
});
