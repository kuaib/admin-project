
define(['jquery','nice-validator'], function($) {
	var submit=function(ctl,successFn,failureFn){
		// 验证成功
		ctl.on('valid.form', function(e, form){
				/*$.ajax({
				url: 'results.php',
				type: 'POST',
				data: $(this).serialize(),
				success: function(d){
				$('#result').fadeIn(300).delay(2000).fadeOut(500);
				}*/
				successFn(e, form);
			
		})
		// 验证失败
		.on('invalid.form', function(e, form, errors){
			//验证失败事件
			failureFn(e, form, errors);
		})
	}
	
	return {
		submit:submit
    };
});



