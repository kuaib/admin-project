define(['jquery'], function($) {
	'use strict';
	var root = 'https://admin.vjidian.com/4103/ratio/goods';
	var controllers = {
		show:{url:root+'/show'},
		find:{url:root+'/find'},
		calculateRatio:{url:root+'/calculateRatio',data:{}},
		calculateAll:{url:root+'/calculateAll',data:{}},
		bachCalculateRatio:{url:root+'/bachCalculateRatio',data:{}}
	};
	function _ajax(controller, success, error) {
		var ajaxOptions = $.extend(true, controller, {
			type:'POST',
			dataType:'JSON',
			success:success,
			error:error
		});
		$.ajax(ajaxOptions);
	}

	function _calculateRatio(data, success, error) {
		controllers.calculateRatio.data = data;
		_ajax(controllers.calculateRatio, success, error);
	}
	function _bachCalculateRatio(data, success, error) {
		controllers.bachCalculateRatio.data = data;
		_ajax(controllers.bachCalculateRatio, success, error);
	}
	function _calculateAll(data, success, error) {
		controllers.calculateAll.data = data;
		_ajax(controllers.calculateAll, success, error);
	}
	
	return {
		controllers: controllers,
		calculateRatio:_calculateRatio,
		calculateAll:_calculateAll,
		bachCalculateRatio:_bachCalculateRatio
	};
});