define(['jquery'], function($) {
	'use strict';
	var root = 'https://admin.vjidian.com/4102/ratio/category';
	var controllers = {
		show:{url:root+'/show'},
		find:{url:root+'/find'},
		saveRatio:{url:root+'/saveRatio',data:{}}
	};
	function _ajax(controller, success, error) {
		var ajaxOptions = $.extend(true, controller, {
			type:'POST',
			dataType:'JSON',
			success:success,
			error:error
		});
		$.ajax(ajaxOptions);
	}

	function _saveRatio(data, success, error) {
		controllers.saveRatio.data = data;
		_ajax(controllers.saveRatio, success, error);
	}
	
	return {
		controllers: controllers,
		saveRatio:_saveRatio
	};
});