/************************************************
会员管理--->会员管理--->会员详情
****/
require([ 'jquery', 'js/module/member/memberDetailController', 'js/module/member/memberController'],
	function($, memberDetailController,memberController) {
	// 选项卡点击事件
	$(".portlet-tabs li").click(function() {
		var $index = $(".portlet-tabs li").index(this);
		// 邮件
		if ($index == 0) {
			window.location.href=memberDetailController.controllers.getDetailEmailLog.url + $('#hid_memberId').val();
		}
		// 短信
		else if ($index == 1) {
			window.location.href=memberDetailController.controllers.getDetailSmsLog.url + $('#hid_memberId').val();
		}
		// 建议
		else if ($index == 2) {
			window.location.href=memberDetailController.controllers.getDetailFeedback.url + $('#hid_memberId').val();
		}
		// 等级历史
		else if ($index == 3) {
			window.location.href=memberDetailController.controllers.getDetailLevelLog.url + $('#hid_memberId').val();
		}
		// 评论
		else if ($index == 4) {
			window.location.href=memberDetailController.controllers.getDetailReview.url + $('#hid_memberId').val();
		}
		// 售后单
		else if ($index == 5) {
			window.location.href=memberDetailController.controllers.getDetailApplyList.url + $('#hid_memberId').val();
		}
		// 购买的商品
		else if ($index == 6) {
			window.location.href=memberDetailController.controllers.getDetailProductList.url + $('#hid_memberId').val();
		}
		// 经验值明细
		else if ($index == 7) {
			window.location.href=memberDetailController.controllers.getDetailExp.url + $('#hid_memberId').val();
		}
		// 积分明细
//		else if ($index == 8) {
//			window.location.href=memberDetailController.controllers.getDetailPoint.url + $('#hid_memberId').val();
//		}
		// 优惠券
//		else if ($index == 9) {
//			window.location.href=memberDetailController.controllers.getDetailCoupon.url + $('#hid_memberId').val();
//		}
		
		// 缺货信息
		else if ($index == 8) {
			window.location.href=memberDetailController.controllers.getInquirySheet.url + $('#hid_memberId').val();
		}
		// 批量进货信息
		else if ($index == 9) {
			window.location.href=memberDetailController.controllers.getBatchStock.url + $('#hid_memberId').val();
		}
		// 购物车
//		else if ($index == 10) {
//			window.location.href=memberDetailController.controllers.getDetailCart.url + $('#hid_memberId').val();
//		}
		// 订单
		else if ($index == 10) {
			window.location.href=memberDetailController.controllers.getDetailOrder.url + $('#hid_memberId').val();
		}
		// 基本信息
		else if ($index == 11) {
			window.location.href=memberController.controllers.viewDetail.url + $('#hid_memberId').val();
		}
	});
});