/**
 * 会员等级
 */
define(['jquery'], function($) {
	"use strict";
	var root = "https://admin.vjidian.com/402/memberLevel";
	//定义全部请求的Controller
	var controllers = {
		show: {
			url: root + '/show'
		},
		find: {
			url: root + '/find'
		},
		add: {
			url: root + '/add',
			data: {}
		},
		update: {
			url: root + '/update',
			data: {}
		},
		editView: {
			url: root + '/editView/'
		},
		del: {
			url: root + '/del',
			data: {
				id: ''
			}
		},
		changeDefault: {
			url: root + '/changeDefault',
			data: {
				id: ''
			}
		},
		batchUpdateSequence: {
			url: root + '/batchUpdateSequence',
			data: {
				ids: '',
				sequences: ''
			}
		},
		verifyNameUniqueness: {
			url: root + '/verifyNameUniqueness'
		},
		verifyNameENUniqueness: {
			url: root + '/verifyNameENUniqueness'
		},
		verifyLevelUniqueness: {
			url: root + '/verifyLevelUniqueness'
		},
	};

	function _ajax(controller, success, error) {
		var ajaxOptions = $.extend(true, controller, {
			type: 'POST',
			dataType: 'JSON',
			success: success,
			error: error
		});
		$.ajax(ajaxOptions);
	}

	function _find(data, success, error) {
		controllers.find.data = data;
		_ajax(controllers.find, success, error);
	}

	function _add(data, success, error) {
		controllers.add.data = data;
		_ajax(controllers.add, success, error);
	}

	function _update(data, success, error) {
		controllers.update.data = data;
		_ajax(controllers.update, success, error);
	}

	function _del(id, success, error) {
		controllers.del.data.id = id;
		_ajax(controllers.del, success, error);
	}

	function _changeDefault(id, success, error) {
		controllers.changeDefault.data.id = id;
		_ajax(controllers.changeDefault, success, error);
	}

	function _batchUpdateSequence(ids, sequences, success, error) {
		controllers.batchUpdateSequence.data.ids = ids;
		controllers.batchUpdateSequence.data.sequences = sequences;
		_ajax(controllers.batchUpdateSequence, success, error);
	}

	return {
		controllers: controllers,
		find: _find,
		add: _add,
		update: _update,
		del: _del,
		changeDefault: _changeDefault,
		batchUpdateSequence: _batchUpdateSequence,
	};
});
