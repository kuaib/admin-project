/**
 * 会员等级规则配置
 */
define(['jquery'], function($) {
	"use strict";
	var root = "https://admin.vjidian.com/405/memberLevelRule";
	var controllers = {
		update: {
			url: root + '/update',
			type: 'POST',
			dataType: 'JSON',
			data: {}
		},
	};

	function _ajax(controller, success, error) {
		var ajaxOptions = $.extend(true, controller, {
			success: success,
			error: error
		});
		$.ajax(ajaxOptions);
	};

	function _update(data, success, error) {
		controllers.update.data = data;
		_ajax(controllers.update, success, error);
	};

	return {
		controllers: controllers,
		update: _update
	};
});
