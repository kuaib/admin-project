/**
 *  会员管理--->会员管理--->会员详情具体url地址
 */
define(['jquery'], function($) {
	'use strict';
	var root = "https://admin.vjidian.com/2201/member";
	//定义全部请求的Controller
	var controllers = {
		getDetailLevelLog:{
			url:root+'/getLevelLog/'
		},
		getDetailLevelLogPage:{
			url:root+'/getLevelLogPage',
			type:'POST',
			dataType:'JSON',
			data:{}
		},
		getDetailPoint:{
			url:root+'/getPoint/'
		},
		getDetailPointPage:{
			url:root+'/getPointPage',
			type:'POST',
			dataType:'JSON',
			data:{}
		},
		getDetailExp:{
			url:root+'/getExp/'
		},
		getDetailExpPage:{
			url:root+'/getExpPage',
			type:'POST',
			dataType:'JSON',
			data:{}
		},
		getDetailCoupon:{
			url:root+'/getCoupon/'
		},
		getDetailCouponPage:{
			url:root+'/getCouponPage',
			type:'POST',
			dataType:'JSON',
			data:{}
		},
		getDetailReview:{
			url:root+'/getReview/'
		},
		getDetailReviewPage:{
			url:root+'/getReviewPage',
			type:'POST',
			dataType:'JSON',
			data:{}
		},
		getDetailEmailLog:{
			url:root+'/getEmailLog/'
		},
		getDetailEmailLogPage:{
			url:root+'/getEmailLogPage',
			type:'POST',
			dataType:'JSON',
			data:{}
		},
		getDetailSmsLog:{
			url:root+'/getSmsLog/'
		},
		getDetailSmsLogPage:{
			url:root+'/getSmsLogPage',
			type:'POST',
			dataType:'JSON',
			data:{}
		},
		getDetailProductList:{
			url:root+'/getProductList/'
		},
		getDetailProductListPage:{
			url:root+'/getProductListPage',
			type:'POST',
			dataType:'JSON',
			data:{}
		},
		getDetailCart:{
			url:root+'/getMemberCart/'
		},
		getDetailCartPage:{
			url:root+'/getMemberCartPage',
			type:'POST',
			dataType:'JSON',
			data:{}
		},
		getDetailFeedback:{
			url:root+'/getFeedback/'
		},
		getDetailFeedbackPage:{
			url:root+'/getFeedbackPage',
			type:'POST',
			dataType:'JSON',
			data:{}
		},
		getDetailApplyList:{
			url:root+'/getApplyList/'
		},
		getDetailApplyListPage:{
			url:root+'/getApplyListPage',
			type:'POST',
			dataType:'JSON',
			data:{}
		},
		getDetailOrder:{
			url:root+'/getOrder/'
		},
		getBatchStock:{
			url:root+'/getBatchStock/'
		},
		getInquirySheet:{
			url:root+'/getInquirySheet/'
		},
		changeTypeConstant:{lower:0,up:1,defer:-1},
		changeModeConstant:{systemAuto:1,artificial:2}
	};

	function _ajax(controller, success, error) {
		var ajaxOptions = $.extend(true, controller, {
			type: 'POST',
			dataType: 'JSON',
			success: success,
			error: error
		});
		$.ajax(ajaxOptions);
	}
	
	function _getDetailLevelLogPage(data,success,error) {
		controllers.getDetailLevelLogPage.data=data;
		_ajax(controllers.getDetailLevelLogPage,success,error);
	}

	function _getDetailPointPage(data,success,error) {
		controllers.getDetailPointPage.data=data;
		_ajax(controllers.getDetailPointPage,success,error);
	}

	function _getDetailCouponPage(data,success,error) {
		controllers.getDetailCouponPage.data=data;
		_ajax(controllers.getDetailCouponPage,success,error);
	}

	function _getDetailExpPage(data,success,error) {
		controllers.getDetailExpPage.data=data;
		_ajax(controllers.getDetailExpPage,success,error);
	}

	function _getDetailReviewPage(data,success,error) {
		controllers.getDetailReviewPage.data=data;
		_ajax(controllers.getDetailReviewPage,success,error);
	}
	
	function _getDetailEmailLogPage(data,success,error) {
		controllers.getDetailEmailLogPage.data=data;
		_ajax(controllers.getDetailEmailLogPage,success,error);
	}
	
	function _getDetailSmsLogPage(data,success,error) {
		controllers.getDetailSmsLogPage.data=data;
		_ajax(controllers.getDetailSmsLogPage,success,error);
	}

	function _getDetailProductListPage(data,success,error) {
		controllers.getDetailProductListPage.data=data;
		_ajax(controllers.getDetailProductListPage,success,error);
	}

	function _getDetailCartPage(data,success,error) {
		controllers.getDetailCartPage.data=data;
		_ajax(controllers.getDetailCartPage,success,error);
	}

	function _getDetailFeedbackPage(data,success,error) {
		controllers.getDetailFeedbackPage.data=data;
		_ajax(controllers.getDetailFeedbackPage,success,error);
	}
	function _getDetailApplyListPage(data,success,error) {
		controllers.getDetailApplyListPage.data=data;
		_ajax(controllers.getDetailApplyListPage,success,error);
	}

	return {
		controllers: controllers,
		getDetailLevelLogPage: _getDetailLevelLogPage,
		getDetailPointPage:_getDetailPointPage,
		getDetailCouponPage: _getDetailCouponPage,
		getDetailExpPage: _getDetailExpPage,
		getDetailReviewPage: _getDetailReviewPage,
		getDetailEmailLogPage:_getDetailEmailLogPage,
		getDetailSmsLogPage:_getDetailSmsLogPage,
		getDetailProductListPage:_getDetailProductListPage,
		getDetailCartPage:_getDetailCartPage,
		getDetailApplyListPage:_getDetailApplyListPage,
		getDetailFeedbackPage:_getDetailFeedbackPage
	};
});
