/**
 * 标记: jinzhesheng
 * 会员管->会员管理
 * 2016/11/3
 */
define(['jquery'], function ($) {
    'use strict';
    var root = 'https://admin.vjidian.com/2202/member';
    var controllers = {
        show: {url: root + '/show'},  //列表页
        find: {url: root + '/find'},  //分页多条数据
        viewDetail: {url: root + '/viewDetail/'},  //详细页没有实现
        add: {url: root + '/add', data: {}},
        verifyLoginNameUniqueness: {url: root + '/verifyLoginNameUniqueness'},
        verifyEmailUniqueness: {url: root + '/verifyEmailUniqueness'},
        verifyMobileUniqueness: {url: root + '/verifyMobileUniqueness'},
        audit: {url: root + '/audit', data: {}},
        freeze: {url: root + '/freeze', data: {id: 0}},
        enable: {url: root + '/enable', data: {id: 0}},
        batchFreeze: {url: root + '/batchFreeze', data: {ids: []}},
        batchEnable: {url: root + '/batchEnable', data: {ids: []}},
        batchSendSms: {url: root + '/batchSendSms', data: {}},
        getSummary: {url: root + '/getSummary', data: {id: 0}},
		getMember: {
            url: '',
            type: 'POST',
            dataType: 'JSON',
            data: {}
        },
        editLoginName: {
            url: root + '/editLoginName',
            data: {
                id: 0,
                loginName: ''
            }
        },
        editEmail: {
            url: root + '/editEmail',
            data: {
                id: 0,
                email: ''
            }
        },
        editMobile: {
            url: root + '/editMobile',
            data: {
                id: 0,
                mobile: ''
            }
        },
        editC4MemberCardNo: {
            url: root + '/editC4MemberCardNo',
            data: {
                id: 0,
                c4MemberCardNo: ''
            }
        },
        editMemberLevel: {
            url: root + '/editMemberLevel',
            data: {
                id: 0,
                newLevelId: 0,
                oriLevelId: 0
            }
        },
        editRegLanguageType: {
            url: root + '/editRegLanguageType',
            data: {
                id: 0,
                regLanguageType: 0
            }
        },
        editLoginPassword: {
            url: root + '/editLoginPassword',
            data: {
                id: 0,
                loginPassword: ''
            }
        },
        editPayPassword: {
            url: root + '/editPayPassword',
            data: {
                id: 0,
                payPassword: ''
            }
        },
        getRegions: {
            url: '',
            type: 'POST',
            dataType: 'JSON',
            data: {}
        },
        editPersonalInfo: {
            url: root + '/editPersonalInfo',
            data: {}
        },
        uploadAvater: {
            url: root + '/uploadAvater',
            data: {}
        },
        editPoint: {
            url: root + '/editPoint',
            data: {}
        },
        editEXP: {
            url: root + '/editEXP',
            data: {}
        },
        editBranchAndCrew: {
            url: root + '/editBranchAndCrew',
            data: {
                id: 0,
                branchId: 0,
                branchCrewId: 0
            }
        },

    };

    function _ajax(controller, success, error) {
        var ajaxOptions = $.extend(true, controller, {
            type: 'POST',
            dataType: 'JSON',
            success: success,
            error: error
        });
        $.ajax(ajaxOptions);
    }

    function _find(data, success, error) {
        controllers.find.data = data;
        _ajax(controllers.find, success, error);
    }

    function _add(data, success, error) {
        controllers.add.data = data;
        _ajax(controllers.add, success, error);
    }

    function _audit(data, success, error) {
        controllers.audit.data = data;
        _ajax(controllers.audit, success, error);
    }

    function _freeze(id, success, error) {
        controllers.freeze.data.id = id;
        _ajax(controllers.freeze, success, error);
    }

    function _enable(id, success, error) {
        controllers.enable.data.id = id;
        _ajax(controllers.enable, success, error);
    }

    function _batchEnable(ids, success, error) {
        controllers.batchEnable.data.ids = ids;
        _ajax(controllers.batchEnable, success, error);
    }

    function _batchFreeze(ids, success, error) {
        controllers.batchFreeze.data.ids = ids;
        _ajax(controllers.batchFreeze, success, error);
    }

    function _batchSendSms(ids, customerServiceName, customerServiceMobile, smsContent, success, error) {
        controllers.batchSendSms.data.ids = ids;
        controllers.batchSendSms.data.customerServiceName = customerServiceName;
        controllers.batchSendSms.data.customerServiceMobile = customerServiceMobile;
        controllers.batchSendSms.data.smsContent = smsContent;
        _ajax(controllers.batchSendSms, success, error);
    }

    function _getSummary(id, success, error) {
        controllers.getSummary.data.id = id;
        _ajax(controllers.getSummary, success, error);
    }

    function _getMember(id, success, error) {
        controllers.getMember.url = root + id;
        _ajax(controllers.getMember, success, error);
    };

    function _editLoginName(id, loginName, success, error) {
        controllers.editLoginName.data.id = id;
        controllers.editLoginName.data.loginName = loginName;
        _ajax(controllers.editLoginName, success, error);
    };

    function _editEmail(id, email, success, error) {
        controllers.editEmail.data.id = id;
        controllers.editEmail.data.email = email;
        _ajax(controllers.editEmail, success, error);
    };

    function _editMobile(id, mobile, success, error) {
        controllers.editMobile.data.id = id;
        controllers.editMobile.data.mobile = mobile;
        _ajax(controllers.editMobile, success, error);
    };

    function _editC4MemberCardNo(id, c4MemberCardNo, success, error) {
        controllers.editC4MemberCardNo.data.id = id;
        controllers.editC4MemberCardNo.data.c4MemberCardNo = c4MemberCardNo;
        _ajax(controllers.editC4MemberCardNo, success, error);
    };

    function _editMemberLevel(id, newLevelId, oriLevelId, success, error) {
        controllers.editMemberLevel.data.id = id;
        controllers.editMemberLevel.data.newLevelId = newLevelId;
        controllers.editMemberLevel.data.oriLevelId = oriLevelId;
        _ajax(controllers.editMemberLevel, success, error);
    };

    function _editRegLanguageType(id, regLanguageType, success, error) {
        controllers.editRegLanguageType.data.id = id;
        controllers.editRegLanguageType.data.regLanguageType = regLanguageType;
        _ajax(controllers.editRegLanguageType, success, error);
    };

    function _editLoginPassword(id, loginPassword, success, error) {
        controllers.editLoginPassword.data.id = id;
        controllers.editLoginPassword.data.loginPassword = loginPassword;
        _ajax(controllers.editLoginPassword, success, error);
    };

    function _editPayPassword(id, payPassword, success, error) {
        controllers.editPayPassword.data.id = id;
        controllers.editPayPassword.data.payPassword = payPassword;
        _ajax(controllers.editPayPassword, success, error);
    };

    function _getRegions(url, parentId, success, error) {
        controllers.getRegions.url = url;
        controllers.getRegions.data.parentId = parentId;
        _ajax(controllers.getRegions, success, error);
    };

    function _editPersonalInfo(data, success, error) {
        controllers.editPersonalInfo.data = data;
        _ajax(controllers.editPersonalInfo, success, error);
    };

    function _editPoint(data, success, error) {
        controllers.editPoint.data = data;
        _ajax(controllers.editPoint, success, error);
    };

    function _editEXP(data, success, error) {
        controllers.editEXP.data = data;
        _ajax(controllers.editEXP, success, error);
    };

    function _editBranchAndCrew(id, branchId, branchCrewId, success, error) {
        controllers.editBranchAndCrew.data.id = id;
        controllers.editBranchAndCrew.data.branchId = branchId;
        controllers.editBranchAndCrew.data.branchCrewId = branchCrewId;
        _ajax(controllers.editBranchAndCrew, success, error);
    };

    return {
        controllers: controllers,
        find: _find,
        add: _add,
        audit: _audit,
        freeze: _freeze,
        enable: _enable,
        batchFreeze: _batchFreeze,
        batchEnable: _batchEnable,
        batchSendSms: _batchSendSms,
        getSummary: _getSummary,
        getMember: _getMember,
        editLoginName: _editLoginName,
        editEmail: _editEmail,
        editMobile: _editMobile,
        editC4MemberCardNo: _editC4MemberCardNo,
        editMemberLevel: _editMemberLevel,
        editRegLanguageType: _editRegLanguageType,
        editLoginPassword: _editLoginPassword,
        editPayPassword: _editPayPassword,
        getRegions: _getRegions,
        editPersonalInfo: _editPersonalInfo,
        editPoint: _editPoint,
        editEXP: _editEXP,
        editBranchAndCrew: _editBranchAndCrew,
    };
});
