/**
   会员批量采购信息
   create:jinzhesheng
   createtime:2016/11/2
 */
define(['jquery'], function ($) {
    'use strict';
    var root = 'https://admin.vjidian.com/2202/member';
    var controllers = {
        url: {url: root + '/findStockInfo'},
    };
    return {
        controllers: controllers,
    };
});
