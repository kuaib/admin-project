define([ 'jquery', 'jquery.iframe-transport', 'jquery.fileupload-image',
		'jquery.fileupload-validate', 'jquery.fileexcelupload-ui' ],
	function($) {
		'use strict';
		/**
		 * @method _init
		 * @param ctl jquery对象的fileupload容器
		 * @param root 上传目录的根地址
		 * @param url 上传的请求地址
		 * @param deleteFn 删除功能的函数
		 * @param files	已经上传的文件
		 */
		function _init(ctl,root,url,deleteFn,files){
			ctl.fileupload({
				/**
				 * @cfg url
				 */
				url:url,
				/**
				 * @cfg dataType
				 */
				dataType:'json',
				/**
				 * @cfg autoUpload 选择文件后是否自动上传
				 */
				autoUpload:false,
				/**
				 * @cfg acceptFileTypes 文件类型限定
				 */
				acceptFileTypes:/(\.|\/)(xlsx|xls|xlt)$/i,
				/**
				 * @cfg maxFileSize 最大文件限定 5 MB
				 */
				maxFileSize:5000000,
				/**
				 * @cfg disableImageResize
				 */
				disableImageResize:/Android(?!.*Chrome)|Opera/
					.test(window.navigator.userAgent),
				/**
				 * @cfg filesContainer
				 */
				filesContainer:$('table .files'),
				/**
				 * @cfg uploadTemplateId
				 */
				uploadTemplateId:null,
				/**
				 * @cfg downloadTemplateId
				 */
				downloadTemplateId:null,
				/**
				 * @cfg added function
				 */
				added:function(e,data){
					_refreshGlobalButton();
				},
				/**
				 * @cfg finished function
				 */
				finished:function(e,data){
					_refreshGlobalButton();
				},
				/**
				 * @cfg destroyed function
				 */
				destroyed:function(e,data){
					deleteFn(data);
					_refreshGlobalButton();
				},
				/**
				 * @cfg failed function
				 */
				failed:function(e,data){
					_refreshGlobalButton();
				},
				/**
				 * @cfg uploadTemplate function
				 */
				uploadTemplate:_uploadTemplate,
				/**
				 * @cfg downloadTemplate function
				 */
				downloadTemplate:function(o){
					return _setDownLoadRows(o.files);
				},
				/**
				 * @cfg messages object
				 * @param maxNumberOfFiles,default to '图片过多，超过最大上传数量限制'
				 * @param acceptFiles,default to '请选择gif/jpg/jpeg/png格式的图片上传'
				 * @param maxFileSize,default to '请选择小于5M的图片'
				 * @param minFileSize,default to '请选择图片'
				 */
				messages: {
	                maxNumberOfFiles: '图片过多，超过最大上传数量限制',
	                acceptFileTypes: '请选择xlsx/xls/xlt格式的图片上传',
	                maxFileSize: '请选择小于5M的图片',
	                minFileSize: '请选择图片'
		         }
			});
			
			var nameStyle = 'width:200px;word-wrap:break-word;word-break:break-all;overflow:hidden;';
			function _assembleButton(name,buttonClass,iconClass,text){
				var button = $('<button>',{name:name,class:buttonClass});
				button.append($('<i>',{class:iconClass}));
				button.append($('<span>',{text:text}));
				return button;
			}
			/**
			 * private
			 */
			function _uploadTemplate(o){
				var rows=$();
				$.each(o.files,function(index,file){
					var row = $('<tr>',{class:'template-upload fade'});
					var previewCell = $('<td>');
					var previewSpan = $('<span>',{class:'preview'});
					previewCell.append(previewSpan);
					row.append(previewCell);
					var nameCell = $('<td>');					
					var nameParagraph = $('<p>',{class:'name',style:nameStyle,text:file.name});
					var errorTip = $('<div>',{class:'error'});
					if (file.error) {
						errorTip.text(file.error);
					}
					nameCell.append(nameParagraph);
					nameCell.append(errorTip);
					row.append(nameCell);
					var sizeCell = $('<td>');
					sizeCell.append($('<p>',{class:'size',text:o.formatFileSize(file.size)}));
					sizeCell.append($('<div>',{class:'progress'}));
					row.append(sizeCell);
					var buttonCell = $('<td>');
					if(!index){
						if(!o.options.autoUpload){
							var uploadButton = _assembleButton('btnSingleUpload','btn btn-primary start','glyphicon glyphicon-upload','上传');
							uploadButton.attr('disabled',true);
							buttonCell.append(uploadButton);
						}
						var cancelButton = _assembleButton('btnSingleCancel','btn btn-warning cancel','glyphicon glyphicon-ban-circle','取消');
						buttonCell.append(cancelButton);
					}
					row.append(buttonCell);
					rows = rows.add(row);
				});
				return rows;
			}
			/**
			 * private
			 */
			function _setDownLoadRows(files){
				//价目表导入结果信息
				$('#tab_confirm2').empty();
				
				var rows = $();
				$.each(files, function (index, file) {
					var row = $('<tr>',{class:'template-download'});
					var previewCell = $('<td>');
					var previewSpan = $('<span>',{class:'preview img-responsive'});
					if (file.digest) {
						var defaultThumbPath = root + file.location + '/' + file.digest + file.extension;
						//previewSpan.append($('<a>').append($('<img>',{src:defaultThumbPath,style:'width:150px;'})));
	                }
					
					//价目表导入结果信息
					var fieldList = file.result; 
	            	var str = "";
	            	if(fieldList != null && fieldList.length > 0){ 
	            		for(var i = 0; i< fieldList.length; i++){
	            			str += fieldList[i]+"<br>";
	            		}
	            		$('#tab_confirm2').append(str);
	            	}
					
					previewCell.append(previewSpan);
					row.append(previewCell);
					var nameCell = $('<td>');
					var nameParagraph = $('<p>',{class:'name',style:nameStyle});
					var errorTip = $('<div>',{class:'error'});
					if (file.error) {
						//nameParagraph.text(file.name);
						//errorTip.text(file.error);
						//alert("商品数据导入失败！");
					}else{
						var originImagePath = root + file.location + '/' + file.digest + file.extension;
		                var originImageLink = $('<a>',{
		                	text:file.name,
		                	href:originImagePath,
		                	title:file.name,
		                	target:'_blank',
		                	'data-id':file.id,
		                	'data-name':file.name,
		                	'data-size':file.size,
		                	'data-digest':file.digest,
		                	'data-extension':file.extension,
		                	'data-gallery':''
		                });
		                nameParagraph.append(originImageLink);
		                //alert("商品数据导入成功！");
					}
					nameCell.append(nameParagraph);
					nameCell.append(errorTip);
					row.append(nameCell);
					var sizeCell = $('<td>');
					sizeCell.append($('<p>',{class:'size',text:_formatFileSize(file.size)}));
					sizeCell.append($('<div>',{class:'progress'}));
					row.append(sizeCell);
					var buttonCell = $('<td>');
					var deleteButton =  _assembleButton('btnSingleDelete','btn btn-danger delete','glyphicon glyphicon-trash','删除');
					if(!file.error){
						deleteButton.data('pictureid',file.id);
					}
					buttonCell.append(deleteButton);
					row.append(buttonCell);
					rows = rows.add(row);
		        });
				return rows;
			}
			/**
			 * private
			 */
			function _formatFileSize(bytes) {
	            if (typeof bytes !== 'number') {
	                return '';
	            }
	            if (bytes >= 1000000000) {
	                return (bytes / 1000000000).toFixed(2) + ' GB';
	            }
	            if (bytes >= 1000000) {
	                return (bytes / 1000000).toFixed(2) + ' MB';
	            }
	            return (bytes / 1000).toFixed(2) + ' KB';
	        }
	        /**
	         * private
	         */		
			function _refreshGlobalButton(){
				var gStartBtn=$('.start',$('.fileupload-buttonbar'));
				var gCancelBtn=$('.cancel',$('.fileupload-buttonbar'));
				var gDeleteBtn=$('.delete',$('.fileupload-buttonbar'));
				var uploadRows=$(ctl).find('.template-upload');
				var downloadRows=$(ctl).find('.template-download');
				
				gStartBtn.toggle(uploadRows.length>0);
				gCancelBtn.toggle(uploadRows.length>0);
				gDeleteBtn.toggle(downloadRows.length>0);
			}
			
			if(files==undefined || files.length<=0){
				_refreshGlobalButton();
			}else{
				$('table .files').append(_setDownLoadRows(files));
			};
			
			_refreshGlobalButton();
			//ctl.downloadTemplate();
			// Upload server status check for browsers with CORS support:
			// if ($.support.cors) {
			// 	$.ajax({
			// 		url:'/picture/connect',
			// 		type:'GET'
			// 	}).fail(function() {
			// 		$.Error('文件上传服务不可访问 - '+ new Date());
			// 	});
			// }
		}
		return {init:_init};
});