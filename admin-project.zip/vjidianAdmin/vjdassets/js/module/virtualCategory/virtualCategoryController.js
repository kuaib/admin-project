/**
 * 商品分类领域对象
 */
define([ 'jquery' ], function($) {
	"use strict";
	var root="https://admin.vjidian.com/307/virtualCategory";
	//定义全部请求的Controller
	var controllers = {
		addCategory:{url:root+'/add',type:'POST',dataType:'JSON',data:{}},
		updateCategory:{url:root+'/update',type:'POST',dataType:'JSON',data:{}},
		getPage:{url:root+'/page',type:'POST',dataType:'JSON',data:{}},
		deleteCategory:{url:root+'/delete',type:'POST',dataType:'JSON',data:{id:''}},
		getCategorySeo:{url:root+'/getCategorySeo',type:'POST',dataType:'JSON',data:{id:''}},
		updateCategorySeo:{ url:root+'/updateCategorySeo',type:'POST',dataType:'JSON',data:{}},
		exportCategory:{url:root+'/export',type:'POST',dataType:'JSON',data:{}},
		deleteExportFile:{url:root+'/deleteExportFile',type:"POST",dataType:'JSON',data:{}},
		//树状展示
		getChilden:{url:root+'/getChildren',type:"POST",dataType:'JSON',data:{}},
		
		editView:{url:root+'/operate/edit/',type:'POST',dataType:'JSON',data:{}},
		addView:{url:root+'/operate/add/',type:'POST',dataType:'JSON',data:{}},
		del:{url:root+'/delete',type:'POST',dataType:'JSON',data:{}},
		disable:{url:root+'/disable',type:'POST',dataType:'JSON',data:{}},
		enable:{url:root+'/enable',type:'POST',dataType:'JSON',data:{}},
		batchUpdateSequence:{url:root+'/batchUpdateSequence',type:"POST",dataType:'JSON',data:{}},
		show:{url:root+'/show',type:'POST',dataType:'JSON',data:{}},
		//商品操作
		productShow:{url:root+'/product/show/',type:'POST',dataType:'JSON',data:{}},
		productPage:{url:root+'/product/page',type:'POST',dataType:'JSON',data:{}},
		addProduct:{url:root+'/product/addProduct',type:'POST',dataType:'JSON',data:{}},
		deleteProduct:{url:root+'/product/delete',type:'POST',dataType:'JSON',data:{}},
		batchDeleteProduct:{url:root+'/product/batchDelete',type:'POST',dataType:'JSON',data:{}},
		batchDeleteAll:{url:root+'/product/batchDeleteAll',type:'POST',dataType:'JSON',data:{}},
		adjustTime:{url:root+'/product/adjustTime',type:'POST',dataType:'JSON',data:{}},
		batchAdjustTime:{url:root+'/product/batchAdjustTime',type:'POST',dataType:'JSON',data:{}},
		batchAdjustAllTime:{url:root+'/product/batchAdjustAllTime',type:'POST',dataType:'JSON',data:{}},
	};
	function _ajax(controller,success,error) {
		var ajaxOptions=$.extend(true,controller,{success:success,error:error});
		$.ajax(ajaxOptions);
	}
	function _addCategory(data,success,error){
		controllers.addCategory.data=data;
		_ajax(controllers.addCategory,success,error);
	}
	function _updateCategory(data,success,error){
		controllers.updateCategory.data=data;
		_ajax(controllers.updateCategory,success,error);
	}
	function _getPage(data,success,error) {
		controllers.getPage.data=data;
		_ajax(controllers.getPage,success,error);
	}
	function _deleteCategory(id,success,error) {
		controllers.deleteCategory.data.id=id;
		_ajax(controllers.deleteCategory,success,error);
	}
	function _updateCategorySearchable(id,searchable,success,error){
		controllers.updateCategorySearchable.data.id=id;
		controllers.updateCategorySearchable.data.searchable=searchable;
		_ajax(controllers.updateCategorySearchable,success,error);
	}
	function _updateCategoryShowable(id,showable,success,error){
		controllers.updateCategoryShowable.data.id=id;
		controllers.updateCategoryShowable.data.showable=showable;
		_ajax(controllers.updateCategoryShowable,success,error);
	}
	function _updateCategorySeo( data,success,error ){
		controllers.updateCategorySeo.data = 'data='+JSON.stringify(data);
		_ajax(controllers.updateCategorySeo,success,error);
	}
	function _getCategorySeo(id,success,error) {
		controllers.getCategorySeo.data.id=id;
		_ajax(controllers.getCategorySeo,success,error);
	}
	function _exportCategory( data,success,error ){
		controllers.exportCategory.data = data;
		_ajax(controllers.exportCategory,success,error);
	}
	
	function _deleteExportFile(data,success,error){
		controllers.deleteExportFile.data = data;
		_ajax(controllers.deleteExportFile,success,error);
	}
	
	function _del(data,success,error){
		controllers.del.data.id = data;
		_ajax(controllers.del,success,error);
	}
	function _disable(data,success,error){
		controllers.disable.data.id = data;
		_ajax(controllers.disable,success,error);
	}
	function _enable(data,success,error){
		controllers.enable.data.id = data;
		_ajax(controllers.enable,success,error);
	}
	
	function _batchUpdateSequence(data,success,error){
		controllers.batchUpdateSequence.data.sequences = data;
		_ajax(controllers.batchUpdateSequence,success,error);
	}
	//addProduct
	function _addProduct(data,success,error){
		controllers.addProduct.data = data;
		_ajax(controllers.addProduct,success,error);
	}
	//删除
	function _deleteProduct(data,success,error){
		controllers.deleteProduct.data.id = data;
		_ajax(controllers.deleteProduct,success,error);
	}
	//批量删除
	function _batchDeleteProduct(data,success,error){
		controllers.batchDeleteProduct.data.ids = data;
		_ajax(controllers.batchDeleteProduct,success,error);
	}
	function _batchDeleteProduct(data,success,error){
		controllers.batchDeleteProduct.data.ids = data;
		_ajax(controllers.batchDeleteProduct,success,error);
	}
	function _adjustTime(data,success,error){
		controllers.adjustTime.data = data;
		_ajax(controllers.adjustTime,success,error);
	}
	function _batchAdjustTime(data,success,error){
		controllers.batchAdjustTime.data = data;
		_ajax(controllers.batchAdjustTime,success,error);
	}
	function _batchAdjustAllTime(data,success,error){
		controllers.batchAdjustAllTime.data = data;
		_ajax(controllers.batchAdjustAllTime,success,error);
	}
	function _batchDeleteAll(data,success,error){
		controllers.batchDeleteAll.data = data;
		_ajax(controllers.batchDeleteAll,success,error);
	}
	return {
		controllers:controllers,
		addCategory:_addCategory,
		updateCategory:_updateCategory,
		getPage:_getPage,
		deleteCategory:_deleteCategory,
		updateCategorySearchable:_updateCategorySearchable,
		updateCategoryShowable:_updateCategoryShowable,
		getCategorySeo:_getCategorySeo,
		updateCategorySeo:_updateCategorySeo,
		exportCategory:_exportCategory,
		deleteExportFile:_deleteExportFile,
		del:_del,
		enable:_enable,
		disable:_disable,
		batchUpdateSequence:_batchUpdateSequence,
		addProduct:_addProduct,
		deleteProduct:_deleteProduct,
		batchDeleteProduct:_batchDeleteProduct,
		adjustTime:_adjustTime,
		batchAdjustTime:_batchAdjustTime,
		batchAdjustAllTime:_batchAdjustAllTime,
		batchDeleteAll:_batchDeleteAll,
	};
});