/**
 * 
 */
define(['js/module/virtualCategory/virtualCategoryController','nice-validator-zh_CN','ueditor','maxlength'], function(categoryController) {
	var _initCatagorySelect=function(changeFn){
		//分类级联初始化
		require(['bootstrap-cascadeselect'], function() {
			$('#txt_category').cascadeSelect({
				url: categoryController.controllers.getChilden.url, // 数据获取url
				parameter: "id", // 数据获取参数名称
		        text: "name", // 定义JSON数据格式：选择名称
		        value: "id", // 定义JSON数据格式：选择值
	            emptyOption: "请选择", // 选择提示,null表示无提示
	            cssClass: "selectpicker", // 下拉框css名称
	            cssStyle: { "margin-right": "10px" }, // 下拉框左右css样式
	            rootId:1,
	            hasChildren:"isParent",
	            selectGroupName:"cascadeSelectGroup",
	            onchange:changeFn
			})
			$('.cascadeSelect').hide()
		});
	};
	
	var _initBaseForm=function(){
		/*var editor = UE.getEditor('ue_container',{
	    	initialFrameWidth:800,//初始化宽度
			initialFrameHeight:200,//初始化高度
			maximumWords:5000//最大字数
		});
		UE.getEditor('ue_container_en',{
	    	initialFrameWidth:800,//初始化宽度
			initialFrameHeight:200,//初始化高度
			maximumWords:10000//最大字数
		});*/
		$('input[maxlength]').maxlength({
		    threshold:5,
		    warningClass:'label label-info',
		    alwaysShow:true,
		    placement:'top',
		});
		
		//单选按钮切换效果
		function searchItem(){
			
			if (!$(this).hasClass('btn-primary')){
				$(this).addClass('btn-primary');
				$(this).siblings().removeClass('btn-primary');
				$('#hid_status').val($(this).val());
			}
		}
		
		$('#div_status button').on('click',searchItem);
	}
	
	function getCategoryObj(){
		var categoryObj = $('#frm_category').serializeObject();
		categoryObj.searchable=$("#chk_searchable").parent().hasClass("checked")==true?1:0;
		categoryObj.status=$("#chk_status").parent().hasClass("checked")==true?2:1;
		return categoryObj;
	}
	
	
	var _add=function(){
		var category=getCategoryObj();
		var submitSuccess=function(data){
		    if(data.result){
				$.Success(data.tip);
				window.setInterval(function(){     
					location.href = categoryController.controllers.show.url; 
			    },2000);
				
			}else{
				$.Warn(data.tip);
		 	}
		};
		//提交表单
		categoryController.addCategory(category,submitSuccess);
	}
	
	var _update=function(){
		var category=getCategoryObj();
		category.id=$("#txt_categoryid").val();
		var submitSuccess=function(data){
			if(data.result){
		    	$.Success(data.tip);
				window.setInterval(function(){     
					location.href = categoryController.controllers.show.url; 
			    },2000);
				
			}else{
				$.Warn(data.tip);
		 	}
		};
		//提交表单
		categoryController.updateCategory(category,submitSuccess);
	}
	
	
	return {
		initCatagorySelect:_initCatagorySelect,
		add:_add,
		update:_update,
		initBaseForm:_initBaseForm,
	}
})