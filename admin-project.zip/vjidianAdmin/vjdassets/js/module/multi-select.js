
//http://loudev.com/

define(['jquery','multi-select'], function( $ ) {
	var init=function(ctl,afterSelectFn,afterDeselectFn){
		if (!$().multiSelect) {
            return;
        }
		op={
				keepOrder:(ctl.attr("data-keepOrder")=="true"?true:false),
				dblClick:(ctl.attr("data-dblClick")=="true"?true:false),
				selectableOptgroup:(ctl.attr("data-selectableOptgroup")=="true"?true:false),
				afterSelect: afterSelectFn,
			 	afterDeselect: afterDeselectFn
		}
		ctl.multiSelect(op);
    }

	//选择项
	//value:String|Array['elem_1', 'elem_42']
	var setSelect=function(ctl,value){
		ctl.multiSelect('select', value);
	}
	
	//取消选项
	//value:String|Array['elem_1', 'elem_42']
	var setDeselect=function(ctl,value){
		ctl.multiSelect('deselect', String|Array);
	}
	
	//全选
	var selectAll=function(ctl){
		ctl.multiSelect('select_all');
	}
	
	//全取消
	var deselectAll=function(ctl){
		ctl.multiSelect('deselect_all');
	}
	//刷新
	var refresh=function(ctl){
		ctl.multiSelect('refresh');
	}
	
	//新增项
	//op={value: 'test', text: 'test', index:0, nested:'optgroup_label'}
	//nested：组名
	var addOption=function(ctl,op){
		ctl.multiSelect('addOption',op);
	}

	return {
		init:init,
		setSelect:setSelect,
		setDeselect: setDeselect,
		selectAll:selectAll,
		deselectAll:deselectAll,
        refresh:refresh,
        addOption:addOption
    };
});



