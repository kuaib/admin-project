define(['jquery','paging'], function($){
	'use strict';
	/** 
		@method _init 初始化分页控件
	    @param dom dom元素
	    @param dataCount 总记录数
	    @param _perpage 每页记录数
	    @param _page 当前页码
	    @param success 
	    @param error
	  */
	var _init = function(dom,totalCount,_perpage,_page,pageSize,success,error){
		$(dom).paging(totalCount, {
	        format: "[ < (q -) nncnn (- p) > ]",
	        perpage: _perpage,
	        lapping: 0,
	        page: _page,
	        onSelect: function(page) {
		        if(page != _page && _page != 0){
		        	success(page)
		        }
	        },
	        onFormat: function(type) {
                switch (type) {
                case 'first':
                    if(_perpage==pageSize[0])
                        return '<span class="totalRecorder">每页显示<select id="sel_pageSize"><option value="'+pageSize[0]+'"  selected>'+pageSize[0]+'</option><option value="'+pageSize[1]+'">'+pageSize[1]+'</option><option value="'+pageSize[2]+'">'+pageSize[2]+'</option></select>条，共<span>'+totalCount+'</span>条</span>';
                    else if(_perpage==pageSize[1])
                        return '<span class="totalRecorder">每页显示<select id="sel_pageSize"><option value="'+pageSize[0]+'">'+pageSize[0]+'</option><option value="'+pageSize[1]+'" selected>'+pageSize[1]+'</option><option value="'+pageSize[2]+'">'+pageSize[2]+'</option></select>条，共<span>'+totalCount+'</span>条</span>';
                    else
                        return '<span class="totalRecorder">每页显示<select id="sel_pageSize"><option value="'+pageSize[0]+'">'+pageSize[0]+'</option><option value="'+pageSize[1]+'">'+pageSize[1]+'</option><option value="'+pageSize[2]+'" selected>'+pageSize[2]+'</option></select>条，共<span>'+totalCount+'</span>条</span>';
                case 'block':
                    if (!this.active)
                            return '<a class="disabled">' + this.value + '</a>';
                    else if (this.value != this.page)
                            return '<a href="#' + this.value + '" class="active">' + this.value + '</a>';
                    return '<a class="disabled">' + this.value + '</a>';
                case 'next':
                    if (this.active){
                        return '&nbsp;<a href="#' + this.value + '" class="next"><i class="fa fa-caret-right"></i></a>';
                    }else{
                        return '&nbsp;<a class="next"><i class="fa fa-caret-right"></i></a>';
                    }
                case 'prev':
                    if (this.active){
                        return '<a href="#' + this.value + '" class="previous"><i class="fa fa-caret-left"></i></a>&nbsp;';
                    }else{
                        return '<a class="previous"><i class="fa fa-caret-left"></i></a>&nbsp;';   
                    }
                case 'right':
                case 'left':
                    if (this.active) {
                        return '<a href="#' + this.value + '" class="number">' + this.value + '</a>';
                    }else{
                        return "";                        
                    }
                case "leap":
                    return "&nbsp;&nbsp;";
                case 'fill':
                    if (this.active){
                        return '<span class="icon">...</span>';
                    }else{
                        return "";
                    }
                case 'last':
            		return '<span>共<span id="totalPage">'+this.value+'</span>页，到第<input name="" type="text">页</span> <button class="btn btn-sm blue" id="btn_skipPage">确定</button>';
                }
	        }
		});
	};	
	return {
		getPaging : _init
	};
});