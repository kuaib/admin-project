define([ 'jquery' ], function($) {
	'use strict';
	var root='https://admin.vjidian.com/9001/navigation';
	//定义全部请求的Controller
	var controllers = {
		getPage:{url:root+'/page',type:'POST',dataType:'JSON',data:{}},
		showAdd:{url:root+'/showAdd',type:'POST',dataType:'JSON',data:{}},
		addNavigation:{url:root+'/addNavigation',type:'POST',dataType:'JSON',data:{}},
		showEdit:{url:root+"/showEdit/",type:'POST',dataType:'JSON',data:{}},
		updateNavigation:{url:root+'/updateNavigation',type:'POST',dataType:'JSON',data:{}},
		deleteNavigation:{url:root+'/deleteNavigation',type:'POST',dataType:'JSON',data:{id:''}},
		changeNavigationShowable:{url:root+'/changeNavigationShowable',type:'POST',dataType:'JSON',data:{id:'',isEnabled:''}},
		validataName:{url:root+'/validataName',type:'POST',dataType:'JSON',data:{}},
	};
	function _ajax(controller,success,error) {
		var ajaxOptions=$.extend(true,controller,{success:success,error:error});
		$.ajax(ajaxOptions);
	};
	function _getPage(data,success,error) {
		controllers.getPage.data=data;
		_ajax(controllers.getPage,success,error);
	};
	function _showAdd(data,success,error) {
		controllers.showAdd.data=data;
		_ajax(controllers.showAdd,success,error);
	};
	function _addNavigation(data,success,error) {
		controllers.addNavigation.data=data;
		_ajax(controllers.addNavigation,success,error);
	};
	function _showEdit(data,success,error) {
		controllers.showEdit.data=data;
		_ajax(controllers.showEdit,success,error);
	};
	function _updateNavigation(data,success,error) {
		controllers.updateNavigation.data=data;
		_ajax(controllers.updateNavigation,success,error);
	};
	function _deleteNavigation(id,success,error) {
		controllers.deleteNavigation.data.id=id;
		_ajax(controllers.deleteNavigation,success,error);
	}
	function _changeNavigationShowable(id,isEnabled,success,error){
		controllers.changeNavigationShowable.data.id=id;
		controllers.changeNavigationShowable.data.isEnabled=isEnabled;
		_ajax(controllers.changeNavigationShowable,success,error);
	}
	return {
		controller:controllers,
		getPage:_getPage,
		showAdd:_showAdd,
		addNavigation:_addNavigation,
		showEdit:_showEdit,
		updateNavigation:_updateNavigation,
		deleteNavigation:_deleteNavigation,
		changeNavigationShowable:_changeNavigationShowable
	};
});