/**
  * 扩展jQuery增加4个方法(Alert,Success,Info,Warn,Error)用于统一提示展示
  * @author LiuRenFeng
  * @create 2014-8-16
  */
define(['jquery', 'toastr', 'app'], function($, toastr) {
	(function($) {
		'use strict';
		toastr.options = {
			closeButton: true,
			debug: false,
			positionClass: 'toast-top-right',
			onclick: null,
			showDuration: '2500',
			hideDuration: '1000',
			timeOut: '5000',
			extendedTimeOut: '1000',
			showEasing: 'swing',
			hideEasing: 'linear',
			showMethod: 'fadeIn',
			hideMethod: 'fadeOut'
		};
		$.extend({
			/**
			  * @method Alert 警告 可以通过扩展
			  * @param message 消息
			  * @param options toastr配置项，请参考toastr源码
			  */
			Alert: function(message, options) {
				$.extend(toastr.options, options);
				toastr.info(message);
			},
			/**
			  * @method Success 成功提示,展示时间2500ms,其它默认。
			  * @param message 消息
			  */
			Success: function(message) {
				toastr.options.showDuration = '2500';
				toastr.success(message);
			},
			/**
			  * @method Info 信息提示,展示时间5000ms,其它默认。
			  * @param message 消息
			  */
			Info: function(message) {
				toastr.options.showDuration = '5000';
				toastr.info(message);
			},
			/**
			  * @method Warn 警告提示,展示时间7000ms,其它默认。
			  * @param message 消息
			  */
			Warn: function(message) {
				toastr.options.showDuration = '7000';
				toastr.warning(message);
			},
			/**
			  * @method Success 错误提示,展示时间8000ms,其它默认。
			  * @param message 消息
			  */
			Error: function(message) {
				toastr.options.showDuration = '8000';
				toastr.error(message);
			},
		});
	})($);
});