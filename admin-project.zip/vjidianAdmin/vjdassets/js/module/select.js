define(['bootstrap-select'], function () {
	var _init = function (callback) {
		if (!$().selectpicker) {
			return;
		}
		$('.selectpicker').selectpicker({
			iconBase: 'fa',
			tickIcon: 'fa-check',
			noneSelectedText: '请选择',
			noneResultsText: '没找到',
		});
	}

	var _initByCtl = function (ctl) {
		var select = ctl.selectpicker({
			iconBase: 'fa',
			tickIcon: 'fa-check',
			noneSelectedText: '请选择',
			noneResultsText: '没找到',
		});
		return select;
	}

	var _getValue = function (ctl) {
		return ctl.selectpicker().val();
	}

	var _setValue = function (ctl, value) {
		ctl.selectpicker('val', value);
	}

	var _removeValue = function (ctl, value) {
		ctl.find('[value=' + value + ']').remove();
		refresh(ctl);
	}

	var _onchange = function (ctl, fn) {
		ctl.bind('change', function () {
			fn($(this))
		});
	}

	var _refresh = function (ctl) {
		ctl.selectpicker('refresh');
	}

	var _destroy = function (ctl) {
		ctl.selectpicker('destroy');
	}

	return {
		init: _init,
		initByCtl: _initByCtl,
		getValue: _getValue,
		setValue: _setValue,
		removeValue: _removeValue,
		onchange: _onchange,
		refresh: _refresh,
		destroy: _destroy
	};
});