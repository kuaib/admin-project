define(['jquery','bootstrap-datepicker'], function($){

	var init=function(){
		var $body=$('<div  data-date-format="yyyy-mm-dd" class="input-group date date-picker"></div>');
		$('input:text.date-picker').each(function(){
			var $btn=$('<span class="input-group-btn"><button type="button" class="btn default input-sm"><i class="fa fa-calendar"></i></button></span>');
			$(this).wrap($body).after($btn);
			$(this).removeClass('date-picker').addClass('form-control');
			$(this).parent().datepicker({autoclose: true});			
		});
	};
	return {
		init:init
    };
});