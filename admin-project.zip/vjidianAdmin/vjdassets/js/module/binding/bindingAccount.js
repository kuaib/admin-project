/**
 * 商品核心模块
 */
define(['js/module/binding/bindingAccountController',
	'nice-validator-zh_CN',
	'ueditor',
	'js/module/pageControls'], function(productController) {
			
	var _updateProduct=function(e){
		e.preventDefault();	
		
		//验证商品分类
		var categoryId=$('#txt_category').val();
		if(!categoryId){
			$.Warn('请选择分类');
			return false;
		}
		var productObj={};
		
		//商品id
		productObj.id=$('#hid_productId').val();
		//商品分类
		productObj.categoryId=categoryId;
		//商品对象赋值
		setProduct(productObj);
		
		var submitSuccess=function(data){
			if(data.result){
				$.Success(data.tip);
				window.setInterval(function(){     
					location.href=productController.controllers.show.url;
			    },2000);
			}else{
				$.Warn(data.tip);
		 	}
		};
		//提交表单
		productController.updateProduct(productObj,submitSuccess);		
	}	
		
	  //绑定账户 
	   function _bindingAccount(){
	   		var strSelectNameValue = $('#makeupCo').val();   		
	   		if(strSelectNameValue == '请选择或输入'){
	   			alert("请选择要绑定见证宝账户！");
	   			return;
	   		}
	   		   		
	   		var majzbpoId = $("#majzbpoId").val();
	   		var selectmajzbpoIdvalue = $("#selectmajzbpoId").val();
	   		var manufacturerId = $("#manufacturerId").val();
	        $.ajax({  
	            type:"POST",  
	            url:"/4004/bindingAccount/updatebindingAccount",  
	            data:"lSelectmajzbpoId="+selectmajzbpoIdvalue+"&lmajzbpoId="+majzbpoId+"&lmanufacturerId="+manufacturerId,  
	            dataType:"json",  
	            success:function(dataMap){
	                /*$("#strCustName").val(dataMap.custName);
	                $("#strBankName").val(dataMap.bankName);
	                var strcusaccid = dataMap.custAcctId;
	                var strcusaccid2 = strcusaccid.substring(0, strcusaccid.length-4);
	                strcusaccid2 = strcusaccid2 + "****";
	                $("#strCustAcctId").val(strcusaccid2);*/
	                alert(dataMap.tip);
	                location.href=productController.controllers.show.url;
	            },  
	        });                
	   }
	   
	//解绑账户 
	function _unbindingAccount(){
		var majzbpoId = $("#majzbpoId").val();
		if(parseInt(majzbpoId) <= 0){
			alert("请先绑定账户后，再解绑！");
			return;
		}	
		$.ajax({  
            type:"POST",  
            url:"/4004/bindingAccount/updateunbindingAccount",  
            data:"lmajzbpoId="+majzbpoId,  
            dataType:"json",  
            success:function(dataMap){
                alert(dataMap.tip);
                location.href=productController.controllers.show.url;
            },  
        });  
	}
	
	return {
		updateProduct:_updateProduct,
		bindingAccount:_bindingAccount,
		unbindingAccount:_unbindingAccount,
    };
});