/**
 * 网站基本信息
 */
define([ 'jquery' ], function($) {
	"use strict";
	var root="https://admin.vjidian.com/527/siteinfo";
	//定义全部请求的Controller
	var controllers = {
		save:{url:root+'/saveSiteinfo',type:'POST',dataType:'JSON',data:{}},
		uploadLogo:{url:root+'/uploadLogo',type:'POST',dataType:'JSON',data:{}},
		uploadFavicon:{url:root+'/uploadFavicon',type:'POST',dataType:'JSON',data:{}},
		detail:{url:root+'/detail',type:'POST',dataType:'JSON',data:{}}
	};
	function _ajax(controller,success,error) {
		var ajaxOptions=$.extend(true,controller,{success:success,error:error});
		$.ajax(ajaxOptions);
	};
	function _save(data,success,error){
		controllers.save.data=data;
		_ajax(controllers.save,success,error);
	};
	
	return {
		controllers:controllers,
		save:_save
	};
});