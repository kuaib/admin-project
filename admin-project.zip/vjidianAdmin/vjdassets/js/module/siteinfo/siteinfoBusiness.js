
define(['jquery','js/module/siteinfo/siteinfoController','ueditor','fileinput','nice-validator-zh_CN','js/module/ajaxfileupload'],function($,siteinfoController){
	
		var editor_footInfo = UE.getEditor('ue_footinfo',{
				       initialFrameWidth:800,//初始化宽度
				       initialFrameHeight:200,//初始化高度
				       maximumWords:2000//最大字数
		});
		var editor_footInfoEn = UE.getEditor('ue_footInfoEN',{
			 initialFrameWidth:800,//初始化宽度
			 initialFrameHeight:200,//初始化高度
			 maximumWords:2000//最大字数
		});
	
	function ui_validateFailure(){
		$.Warn('验证失败');
		return false;
	};

	function ui_submit(){
		//标签信息
		var siteinfo = {}; 
		siteinfo.siteFullName=$('#txt_sitefullname').val();
		siteinfo.siteFullNameEN=$("#txt_sitefullnameen").val();
		siteinfo.siteShortName = $('#txt_siteshortname').val();
		siteinfo.siteDomainName = $('#txt_sitedomainname').val();
		siteinfo.siteShortNameEN = $('#txt_siteshortnameen').val();
		siteinfo.companyName = $('#txt_companyname').val();
		siteinfo.companyNameEN = $('#txt_companynameen').val();
		siteinfo.serviceCall = $('#txt_servicecall').val();
		siteinfo.serviceMail = $('#txt_servicemail').val();
		siteinfo.weixin = $('#txt_weixin').val();
		siteinfo.weibo = $('#txt_weibo').val();
		siteinfo.address = $('#txt_address').val();
		siteinfo.addressEN = $('#txt_addressen').val();
		siteinfo.postcode = $('#txt_postcode').val();
		siteinfo.icpnumber = $('#txt_icpnumber').val();
		siteinfo.siteLogo = $('#hid_sitelogo_id').val();
		siteinfo.favicon = $('#hid_favicon_id').val();
		siteinfo.footInfo =  UE.getEditor('ue_footinfo').getContent();
		siteinfo.footInfoEN = UE.getEditor('ue_footInfoEN').getContent();
		siteinfo.id = $('#hid_id').val();
		
		$.ajaxFileUpload({
		    url: siteinfoController.controllers.save.url,
		    secureuri: false,
		    //fileElementId: 'file_pic',
		    fileElementNames:['sitelogoFile','faviconFile'],
		    data: siteinfo,
		    dataType: 'json',
		    type:'POST',
		    success: function (data, status){
		    	if(data){
				    if(data.result){
				    	$.Success(data.tip);
						window.setInterval(function(){
							location.href = siteinfoController.controllers.detail.url;
					    },2000);
					}else{
						$.Warn(data.tip);
				 	}
				}
			},
		 	error: function (data, status, e) {
		 		$.Warn(status);
		 	}
		});
	}

	$('#form_siteinfo').validator().on('valid.form', ui_submit).on('invalid.form', ui_validateFailure);
})

