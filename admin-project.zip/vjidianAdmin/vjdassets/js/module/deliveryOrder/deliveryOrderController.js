define([ 'jquery' ], function($) {
	'use strict';
	var root='https://admin.vjidian.com/4003/deliveryOrder';
	//定义全部请求的Controller
	var controllers = {
		show:{url:root+'/show'},
		find:{url:root+'/find',data:{}},
		confirm:{url:root+'/confirm',data:{}},
		cancel:{url:root+'/cancel',data:{}}
	};
	function _ajax(controller,success,error) {
		var ajaxOptions=$.extend(true,controller,{
			type:'POST',
			dataType:'JSON',
			success:success,
			error:error
		});
		$.ajax(ajaxOptions);
	}
	function _confirm(id,success,error){
		controllers.confirm.data.id=id;
		_ajax(controllers.confirm,success,error);
	}
	function _cancel(id,success,error){
		controllers.cancel.data.id=id;
		_ajax(controllers.cancel,success,error);
	}
	return {
		cancel:_cancel,
		confirm:_confirm,
		controllers:controllers
	};
});