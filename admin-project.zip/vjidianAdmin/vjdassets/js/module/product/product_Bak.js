/**
 * 商品信息
 */
define([ 'jquery' ], function($) {
	"use strict";
	var root="https://admin.vjidian.com/304/productinfo";
	//定义全部请求的Controller
	var controllers = {
		add:{url:root+'/add',type:'POST',dataType:'JSON',data:{}},
		update:{url:root+'/update',type:'POST',dataType:'JSON',data:{id:'',categoryId:'',categoryName:'',brandId:'',brandName:'',name:'',code:'',alias:'',description:'',details:'',mobileDetails:'',seoSettingDTO:''}},
		del:{url:'',type:'POST',dataType:'JSON',data:{}},
		updateName:{url:root+'/updateName',type:'POST',dataType:'JSON',data:{productId:'',productName:''}},
		deletePrice:{url:root+'/deletePrice',type:'POST',data:{priceId:''}},
		deletePicture:{url:root+'/deletePicture',type:'POST',data:{pictureId:''}},
		deleteAllPictures:{url:root+'/deleteAllPictures',type:'POST',data:{productId:''}},
		batchTagProduct:{url:root+'/batchTagProduct',type:'POST',data:{productIds:'',imageTagIds:''}},
		getPage:{url:root+'/page',type:'POST',dataType:'JSON',data:{}},
		getCategorySpec:{url:root+'/getCategorySpec',type:'POST',dataType:'JSON',data:{}},
		loadExtendedAttributeSchema:{url:root+'/loadExtendedAttributeSchema',type:'POST',dataType:'JSON',data:{categoryid:''}},
		loadParameterSchema:{url:root+'/loadParameterSchema',type:'POST',dataType:'JSON',data:{categoryid:''}}
	};
	function _ajax(controller,success,error) {
		var ajaxOptions=$.extend(true,controller,{success:success,error:error});
		$.ajax(ajaxOptions);
	}
	function _getPage(data,success,error) {
		controllers.getPage.data=data;
		_ajax(controllers.getPage,success,error);
	}
	function _updateName(productId,productName,success,error){
		var data=controllers.updateName.data;
		data.productId=productId;
		data.productName=productName;
		_ajax(controllers.updateName,success,error);
	}
	function _add(data,success,error){
		console.log(data);
		//var data={categoryId:categoryId,categoryName:categoryName,brandId:brandId,brandName:brandName,name:name,code:code,alias:alias,description:description,details:details,mobileDetails:mobileDetails,seoSettingDTO:seoSettingDTO};
		controllers.add.data='productDetailJSON='+JSON.stringify(data);
		_ajax(controllers.add,success,error);
	};
	function _update(id,categoryId,categoryName,brandId,brandName,name,code,alias,description,details,mobileDetails,seoSettingDTO,success,error){
		var data={id:id,categoryId:categoryId,categoryName:categoryName,brandId:brandId,brandName:brandName,name:name,code:code,alias:alias,description:description,details:details,mobileDetails:mobileDetails,seoSettingDTO:seoSettingDTO};
		controllers.update.data='ProductDetailJSON='+JSON.stringify(data);
		_ajax(controllers.update,success,error);
	};
	function _del(id,success,error){
		controllers.del.url=root+'/del/'+id;
		_ajax(controllers.del,success,error);
	}
	function _deletePrice(priceId,success,error){
		controllers.deletePrice.data.priceId=priceId;
		_ajax(controllers.deletePrice,success,error);
	};
	function _deletePicture(pictureId,success,error){
		controllers.deletePicture.data.pictureId=pictureId;
		_ajax(controllers.deletePicture,success,error);
	};
	function _batchTagProduct(productIds,imageTagIds,success,error){
		controllers.batchTagProduct.data.productIds = productIds;
		controllers.batchTagProduct.data.imageTagIds = imageTagIds;
		_ajax(controllers.batchTagProduct,success,error);
	};
	function _deleteAllPictures(productId,success,error){
		controllers.deleteAllPictures.data.productId=productId;
		_ajax(controllers.deleteAllPictures,success,error);
	};
	
	function _getCategorySpec(id,success,error){
		controllers.getCategorySpec.data.id=id;
		_ajax(controllers.getCategorySpec,success,error);
	};
	
	function _loadExtendedAttributeSchema(categoryid,success,error){
		controllers.loadExtendedAttributeSchema.data.categoryid=categoryid;
		_ajax(controllers.loadExtendedAttributeSchema,success,error);
	}

	function _loadParameterSchema(categoryid,success,error){
		controllers.loadParameterSchema.data.categoryid=categoryid;
		_ajax(controllers.loadParameterSchema,success,error);
	}

	return {
		controllers:controllers,
		getPage:_getPage,
		updateName:_updateName,
		add:_add,
		update:_update,
		del:_del,
		deletePrice:_deletePrice,
		deletePicture:_deletePicture,
		batchTagProduct:_batchTagProduct,
		deleteAllPictures:_deleteAllPictures,
		getCategorySpec:_getCategorySpec,
		loadExtendedAttributeSchema:_loadExtendedAttributeSchema,
		loadParameterSchema:_loadParameterSchema
	};
});
