/**
 * 商品核心模块
 */
define(['layer','js/module/product/productControllerjy',
	'nice-validator-zh_CN',
	'ueditor',
	'js/module/pageControls'], function(layer,productController) {
			
	var pictures=[];
	
	var productSpecObjs=[];
	
	var _initPicture=function(pics){
		//商品图片初始化
		require(['fileuploadingridviewexcel',
			'js/module/album/albumExcelController'], 
			function(upload,albumController) {
			var delSuccess=function(data){
				if (data) {
					if (data.result) {
						layer.msg(data.tip);
					} else {
						layer.msg(data.tip);
					}
				}
			};
			function data_delete(data) {
				var pictureId = data.pictureid;
				//商品id
				var productId=$('#hid_productId').val();
				if (typeof(pics) != "undefined" && typeof(productId) != "undefined") {
					//编辑商品状态
					productController.deletePicture(productId,pictureId,delSuccess)
				}else{
					//新增商品状态
					albumController.del(pictureId,delSuccess);
				}
			}
			$('#btnAllDelete').on('click',function(){
				$('#tbl_pictures .delete').trigger('click');
			});
			//var uploadRoot = '/vjdassets/upload/';
			var uploadRoot = '/vjdassets/excelfile/';
			var uploadUrl = albumController.controllers.upload.url;
			upload.init($('#frm_picture'), uploadRoot,uploadUrl,data_delete,pics);	
		});
	}
		
	var _addProduct=function(e){
		e.preventDefault();				
		
		//图片
		if(pictures.length>0){
			productObj.pictures= pictures;
		}					
		
		window.setInterval(function(){     
			location.href =productController.controllers.show.url;
	    },2000);
	}
		
	var _addPicture=function(){
		pictures.length=0;
		$("p a[data-gallery='']",$('#frm_picture')).each(function() {
			if ($(this).attr('href')) {
				pictures.push($(this).data('id'));
			}
		});
	}	
	
	//上传文件后 下一步事件
	var _uploadResult=function(){
		//$('#tab_confirm').empty();
		/*$.ajax({  
            type:"POST",  
            url:"/8005/album/uploadResult",  
            dataType:"json",  
            success:function(dataMap){
            	var fieldList = dataMap.resultList; 
            	var str = "";
            	if(fieldList != null && fieldList.length > 0){ 
            		for(var i = 0; i< fieldList.length; i++){
            			str += fieldList[i]+"<br>";  
            		}
            		$('#tab_confirm').append(str);
            	}
            },  
        }); */
	}
	
	var _updatePicture=function(e){
		e.preventDefault();	
		pictures.length=0;
		var submitSuccess=function(data){
			if(data.result){
				layer.msg(data.tip);
				$('#btn_listproduct').trigger('click');
			}else{
				layer.msg(data.tip);
		 	}
		};
		$("p a[data-gallery='']",$('#frm_picture')).each(function() {
			if ($(this).attr('href')) {
				var item={
					id:$(this).data('id'),
				};
				pictures.push(item);
			}
		});
		var productObj={};
		//商品id
		productObj.id=$('#hid_productId').val();
		//图片
		if(pictures.length>0){
			productObj.pictureList= pictures;
		}
		productController.updatePicture(productObj,submitSuccess);
	}
	
    var _validatePictures=function(){
    	//图片
		if($("p a[data-gallery='']",$('#frm_picture')).size()>0){
			return true;
		}
		return false;
    } 
	
	return {
		initPicture:_initPicture,
		uploadResult:_uploadResult,
		addProduct:_addProduct,
		addPicture:_addPicture,
		updatePicture:_updatePicture,
		validatePictures:_validatePictures,
    };
});
