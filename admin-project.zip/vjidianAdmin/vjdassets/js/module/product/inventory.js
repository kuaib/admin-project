/**
 * 商品领域对象
 */
define([ 'jquery' ], function($) {
	"use strict";
	var root="https://admin.vjidian.com/308/inventoryRule";
	//定义全部请求的Controller
	var controllers = {
		add:{url:root+'/add',type:'POST',dataType:'JSON',data:{}},
		editRule:{url:root+'/operate/edit/',type:'POST',dataType:'JSON',data:{}},
		update:{url:root+'/update',type:'POST',dataType:'JSON',data:{}},
		deleteInventory:{url:root+'/delete',type:'POST',data:{ruleId:''}},
		deleteDetail:{url:root+'/deleteDetail',type:'POST',data:{ruleDetailId:''}},
		getPage:{url:root+'/page',type:'POST',dataType:'JSON',data:{}}
	};
	function _ajax(controller,success,error) {
		var ajaxOptions=$.extend(true,controller,{success:success,error:error});
		$.ajax(ajaxOptions);
	}
	function _getPage(data,success,error) {
		controllers.getPage.data=data;
		_ajax(controllers.getPage,success,error);
	}
	function _add(data,success,error){
		console.log(data);
		controllers.add.data='ruleJSON='+JSON.stringify(data);
		_ajax(controllers.add,success,error);
	};
	function _update(data,success,error){
		controllers.update.data='ruleJSON='+JSON.stringify(data);
		_ajax(controllers.update,success,error);
	};
	function _deleteInventory(ruleId,success,error){
		controllers.deleteInventory.data.ruleId=ruleId;
		_ajax(controllers.deleteInventory,success,error);
	};
	function _deleteDetail(ruleDetailId,success,error){
		controllers.deletePicture.data.pictureId=ruleDetailId;
		_ajax(controllers.deleteDetail,success,error);
	};
	return {
		controllers:controllers,
		getPage:_getPage,
		add:_add,
		update:_update,
		deleteInventory:_deleteInventory,
		deleteDetail:_deleteDetail,
	};
});
