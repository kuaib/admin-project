/**
 * 商品核心模块
 */
define(['js/module/product/productController','layer',
	'nice-validator-zh_CN',
	'ueditor',
	'js/module/pageControls'], function(productController,layer) {

	//款式
	var productStyleObjs=[];
	//扩展属性
	var attributeValues=[];
	//参数
	var parameter=[];

	var pictures=[]; // 产品基本信息
	var pictures_def="";// 图片是否为默认图片
	var pictures1=[]; // 新增规格型号信息
	var pictures_def1="";// 图片是否为默认图片

	var productSpecObjs=[];

	//富文本编辑集合
	//var richtextList;

	var _initBaseForm=function(){
		//编辑器初始化

		detailLocationName=[];
		detailLocationName.push($("#hid_detailLocationName").val());

		var editorConfig={
			initialFrameWidth:800,//初始化宽度
			initialFrameHeight:200,//初始化高度
			maximumWords:5000,//最大字数
			savePath:detailLocationName,
			pictureLocation:$("#hid_detailLocation").val(),
		}
		var editorENConfig={
			initialFrameWidth:800,//初始化宽度
			initialFrameHeight:200,//初始化高度
			maximumWords:10000,//最大字数
			savePath:detailLocationName,
			pictureLocation:$("#hid_detailLocation").val(),
		}
		//商品文描（产品管理只用这个）   // kuaibing 11月29日注释了下面的三条
		var editor_details = UE.getEditor('ue_details',editorConfig);
		//商品英文文描
		//var editor_detailsEN = UE.getEditor('ue_detailsEN',editorENConfig);

		// 移动端商品文描
		//var editor_mobileDetails = UE.getEditor('ue_mobileDetails',editorConfig);

		// 移动端商品英文文描
		//var editor_mobileDetailsEN = UE.getEditor('ue_mobileDetailsEN',editorENConfig);

		//下拉渲染
		require(['js/module/select'], function(select) {
			select.init();
		});

		//输入框最大长度校验初始化
		require(['maxlength'], function() {
			$('input[maxlength]').maxlength({
				threshold:5,
				warningClass:'label label-info',
				alwaysShow:true,
				placement:'top'
			});
		});
	};

	var _initPicture=function(pics,tag,data_delete,manufacturerId,location){
		//商品图片初始化
		require(['fileuploadingridview','app'],
			function(upload) {
				//var delSuccess=function(data){
				//	if (data) {
				//		if (data.result) {
				//			layer.msg(data.tip);
				//		} else {
				//			layer.msg(data.tip);
				//		}
				//	}
				//};
				//function data_delete(data) {
				//	var pictureId = data.pictureid;
				//	// 产品id
				//	var productId=$('#hid_productId').val();
				//	if (typeof(pics) != "undefined" && typeof(productId) != "undefined") {
				//		//编辑商品状态
				//		productController.deletePicture(productId,pictureId,delSuccess)
				//	}else{
				//		//新增商品状态
				//		albumController.del(pictureId,delSuccess);
				//	}
				//}
				$('#btnAllDelete').on('click',function(){
					$('#tbl_pictures .delete').trigger('click');
				});
				$('#btnAllDelete1').on('click',function(){
					$('#tbl_pictures1 .delete').trigger('click');
				});
				var uploadRoot = '/assets/upload/';
				//var uploadUrl = albumController.controllers.upload.url;
				var uploadUrl = website_address + 'vjidian-basic/album/upload?manufacturerId=' + localStorage.manufacturerId + '&location=' + location;
				upload.init(tag, uploadRoot,uploadUrl,data_delete,pics); // 规格图片 location=16
			});
	}

	function data_delete(data) {
		require(['fileuploadingridview',
				'js/module/album/albumController', 'app'],
			function (upload, albumController) {
				var delSuccess = function (data) {
					if (data) {
						if (data.success == true) {
							layer.msg(data.msg);
						} else {
							layer.msg(data.msg);
						}
					}
				};
				var pictureId = data.pictureid;
				// 产品id
				var productId = $('#hid_productId').val();
				//if (typeof(productId) != "undefined") {
				if (productId != "" && typeof(productId) != "undefined") {
					//编辑产品状态
					productController.deletePicture(productId, pictureId, delSuccess)
				} else {
					//新增产品状态
					albumController.del(pictureId,delSuccess);
				}
			});
	}
	function data_delete1(data) {
		require(['fileuploadingridview',
				'js/module/album/albumController', 'app'],
			function (upload, albumController) {
				var delSuccess = function (data) {
					if (data) {
						if (data.success == true) {
							layer.msg(data.msg);
						} else {
							layer.msg(data.msg);
						}
					}
				};
				var pictureId = data.pictureid;
				// 产品id
				var productId=$('#hid_productId').val();
				// 商品id
				var goodsId = $("#specId").val();
				// 编辑商品图片
				//if(typeof(pics) != "undefined" && typeof(productId) != "undefined" && typeof(productId) != "goodsId"){
				if(productId != "" && goodsId != "" && typeof(goodsId) != "undefined"){
					productController.deletePicture1(goodsId,pictureId,delSuccess);
				}else{
					// 新增商品图片
					albumController.del1(pictureId,delSuccess);
				}
			});
	}



	var _initCatagorySelect=function(changeFn){
		//分类级联初始化
		require(['js/module/category/categoryController',
			'bootstrap-cascadeselect'], function(categoryController) {
			$('#txt_category').cascadeSelect({
				url:categoryController.controllers.getChilden.url, // 数据获取url
				parameter: "id",
				text: "name",
				value: "id",
				emptyOption: "请选择",
				cssClass: "selectpicker",
				cssStyle: { "margin-right": "10px" },
				rootId:1,
				hasChildren:"isParent", //赋给option的hasChildren属性，后台获取isParent的值
				selectGroupName:"cascadeSelectGroup",
				onchange:changeFn
			})
			$('.cascadeSelect').hide();
		});
	};




	function setProduct(productObj){
		productObj.categoryName=$('#txt_category').attr('data-name');
		//商品品牌
		var brandId=$('#sel_brand').find('option:selected').val();
		if(brandId != 0){
			productObj.brandId=brandId;
			productObj.brandName=$('#sel_brand').find('option:selected').text();
		};

		productObj.manufacturerId = $('#hid_manufacturer').val();

		//商品名称
		productObj.name=$('#txt_productName').val();
		//商品英文名称
		productObj.nameEN=$('#txt_productNameEN').val();
		//商品编码
		productObj.code=$('#txt_productCode').val();
		//销售单位
		productObj.salesUnit=$('#txt_productSalesUnit').val();
		//单品商品重量
		productObj.weight=$('#txt_productWeight').val();
		//商品别名
		productObj.alias=$('#txt_productAlias').val();
		//商品简介
		productObj.description=$('#txt_productDescription').val();
		//商品英文简介
		productObj.descriptionEN=$('#txt_productDescriptionEN').val();
		//包装清单
		productObj.packingList=$('#txt_packingList').val();
		//最小起订量
		productObj.minimumOrderQuantity=$('#txt_minimumOrderQuantity').val();
		//步长
		productObj.orderStep=$('#txt_orderStep').val();
		return productObj;
	}

	var _addProduct=function(e){
		e.preventDefault();
		//验证商品分类
		var categoryId=$("#txt_category").val();
		if(!categoryId){
            layer.msg("请选择分类");
			return false;
		}

		var productObj={};
		//商品分类
		productObj.categoryId=categoryId;

		setProduct(productObj);

		$('tbody>tr',$('#tbl_productStyle')).each(function(index){
			var $tr=$(this);
			$tds=$tr.find('td');
			var item={
				name:$('input',$tds[0]).val(),
				code:$('input',$tds[1]).val(),
				barCode:$('input',$tds[2]).val(),
				weight:$('input[type=hidden]',$tds[3]).val(),
				volume:$('input[type=hidden]',$tds[4]).val(),
				optionIdList:$tr.data('optionids'),
			};
			productStyleObjs.push(item);
		})

		//商品文描
		productObj.details=UE.utils.unhtml(UE.getEditor('ue_details').getContent());
		//商品英文文描
		//productObj.detailsEN=UE.utils.unhtml(UE.getEditor('ue_detailsEN').getContent());
		//移动端文描
		//productObj.mobileDetails=UE.utils.unhtml(UE.getEditor('ue_mobileDetails').getContent());
		//移动端英文文描
		//productObj.mobileDetailsEN=UE.utils.unhtml(UE.getEditor('ue_mobileDetailsEN').getContent());

		//图片
		if(pictures.length>0){
			productObj.pictures= pictures;
		}

		// kuaibing新增
		if(pictures1.length>0){
			productObj.pictures1= pictures1;
		}

		//规格
		if(productSpecObjs.length>0){
			productObj.specifications= productSpecObjs;
		}

		//款式
		if(productStyleObjs.length>0){
			productObj.productStyles= productStyleObjs;
		}
		//扩展属性
		if(attributeValues.length>0){
			productObj.attributeValues=attributeValues;
		}
		//参数
		if(parameter.length>0){
			productObj.parameterValues=parameter;
		}

		var submitSuccess=function(data){
			if(data.result){
				layer.msg(data.tip);
				//$('#product_wizard').find('.button-submit').show();
				window.setInterval(function(){
					location.href =productController.controllers.show.url;
				},500);

			}else{
                layer.msg(data.tip);
			}
		};
		//console.log(productObj);
		//提交表单
		productController.add(productObj,submitSuccess);
		$('#product_wizard').find('.button-submit').hide();
		//window.setInterval(function(){
		//	$('#product_wizard').find('.button-submit').show();
		//},5000);
	}

	var _updateProduct=function(e){
		e.preventDefault();

		//验证商品分类
		var categoryId=$('#txt_category').val();
		if(!categoryId){
            layer.msg('请选择分类');
			return false;
		}
		var productObj={};

		//商品id
		productObj.id=$('#hid_productId').val();
		//商品分类
		productObj.categoryId=categoryId;
		//商品对象赋值
		setProduct(productObj);

		var submitSuccess=function(data){
			if(data.result){
				layer.msg(data.tip);
				window.setInterval(function(){
					location.href=productController.controllers.show.url;
				},2000);
			}else{
                layer.msg(data.tip);
			}
		};
		//提交表单
		productController.updateProduct(productObj,submitSuccess);
	}

	// 新增图片
	var _addPicture=function(){
		pictures.length=0; // 为了下一步再上一步时清空
		pictures_def = ""; // 为了下一步再上一步时清空
		var $a;
		$("p a[data-gallery='']",$("#frm_product")).each(function() {
			if ($(this).attr('href')) {
				$a = $(this).attr('href');
				pictures.push($(this).data('id'));
			}
		});
		$(".defaultPic",$("#frm_product")).each(function() {
			if ($a) {
				var checkFlag = $(this).prop("checked")?"1":"0";
				pictures_def += "," +checkFlag;
			}
		});
		pictures_def = pictures_def.substr(1);
		if(pictures_def.indexOf("1") == -1){ // 获取字符"1"所在的索引值，即判断是否已经有默认的图片
			$(".defaultPic",$("#frm_product")).first().prop("checked",true);
			pictures_def = pictures_def.replace("0","1");
		}
		return {
			pictures:pictures,
			pictures_def:pictures_def
		}
	}
	// 新增图片(kuaibing新增-->新增规格型号使用)
	var _addPicture1=function(){
		pictures1.length=0;
		pictures_def1 = "";
		var $a;
		$("p a[data-gallery='']",$("#frm_picture")).each(function() {
			if ($(this).attr('href')) {
				$a = $(this).attr('href');
				pictures1.push($(this).data('id'));
			}
		});
		$(".defaultPic",$("#frm_picture")).each(function() {
			if ($a) {
				var checkFlag = $(this).prop("checked")?"1":"0";
				pictures_def1 += "," + checkFlag;
			}
		});
		pictures_def1 = pictures_def1.substr(1);
		if(pictures_def1.indexOf("1") == -1){
			$(".defaultPic",$("#frm_picture")).first().prop("checked",true);
			pictures_def1 = pictures_def1.replace("0","1");
		}
		return {
			pictures1:pictures1,
			pictures_def1:pictures_def1
		}
	}

	// 更改图片         ----地址：productinfo/updatePicture
	var _updatePicture=function(e){
		e.preventDefault();
		pictures.length=0;
		var submitSuccess=function(data){
			if(data.result){
				layer.msg(data.tip);
				$('#btn_listproduct').trigger('click');
			}else{
                layer.msg(data.tip);
			}
		};
		$("p a[data-gallery='']",$("#frm_product")).each(function() {
			if ($(this).attr('href')) {
				var item={
					id:$(this).data('id'),
				};
				pictures.push(item);
			}
		});
		var productObj={};
		//商品id
		productObj.id=$('#hid_productId').val();
		//图片
		if(pictures.length>0){
			productObj.pictureList= pictures;
		}
		productController.updatePicture(productObj,submitSuccess);
	}
	// 更改图片(kuaibing新增-->新增规格型号使用)
	var _updatePicture1=function(e){
		e.preventDefault();
		pictures1.length=0;
		var submitSuccess=function(data){
			if(data.result){
				layer.msg(data.tip);
				$('#btn_listproduct').trigger('click');
			}else{
                layer.msg(data.tip);
			}
		};
		// kuaibing 11/30 增加了 $("#frm_product")
		$("p a[data-gallery='']",$('#frm_picture')).each(function() {
			if ($(this).attr('href')) {
				var item={
					id:$(this).data('id'),
				};
				pictures1.push(item);
			}
		});
		var productObj={};
		//商品id（是否应该是商品的id）
		productObj.id=$('#hid_productId').val();
		//图片
		if(pictures1.length>0){
			productObj.pictureList= pictures1;
		}
		productController.updatePicture(productObj,submitSuccess);
	}

	// 校验图片是否上传
	var _validatePictures=function(){
		if($("p a[data-gallery='']",$('#frm_product')).size()>0){
			return true;
		}
		return false;
	}
	// 校验图片是否上传(kuaibing新增-->新增规格型号使用)
	var _validatePictures1=function(){
		if($("p a[data-gallery='']",$('#frm_picture')).size()>0){
			return true;
		}
		return false;
	}

	//保存商品文描
	var _saveDetails=function(e){
		e.preventDefault();
		var submitSuccess=function(data){
			if(data.result){
                layer.msg(data.tip);
				$('#btn_listproduct').trigger('click')
			}else{
                layer.msg(data.tip);
			}
		};
		var productId=$('#hid_productId').val();
		//商品文描
		var details=UE.utils.unhtml(UE.getEditor('ue_details').getContent());
		//商品英文文描
		var detailsEN=UE.utils.unhtml(UE.getEditor('ue_detailsEN').getContent());
		productController.updateDetails(productId,details,detailsEN,submitSuccess);
	}

	//保存移动端商品文描
	var _saveMobileDetails=function(e){
		e.preventDefault();
		var submitSuccess=function(data){
			if(data.result){
                layer.msg(data.tip);
				$('#btn_listproduct').trigger('click')
			}else{
                layer.msg(data.tip);
			}
		};
		var productId=$('#hid_productId').val();
		//移动端文描
		var mobileDetails=UE.utils.unhtml(UE.getEditor('ue_mobileDetails').getContent());
		//移动端英文文描
		var mobileDetailsEN=UE.utils.unhtml(UE.getEditor('ue_mobileDetailsEN').getContent());
		productController.updateMobileDetails(productId,mobileDetails,mobileDetailsEN,submitSuccess);
	}

	//列出规格模板
	var _loadSpecificationSchema=function(categoryId){

		var dtd = $.Deferred(); // 新建一个deferred对象

		var $pnl_productSpec=$("#pnl_productSpec");
		$pnl_productSpec.empty();
		var success=function(data){
			if(data.length>0){
				//显示多款式
				$('#sec_multipleStyle').show();
				//$('#sec_singleStyle').hide();

				require(['js/module/checkbox_radio'], function(uniform) {
					//美化checkbox
					uniform.init();
				});

			}
			else{
				//显示单品
				//$('#sec_singleStyle').show();
				//$('#sec_multipleStyle').hide();
				$('#sec_multipleStyle').show();
			}
			dtd.resolve(); // 改变deferred对象的执行状态
		};
		//获取商品规格
		productController.loadSpecificationSchema(categoryId,success);
		return dtd;
	}

	var _loadSpecification=function(categoryId,productId){
		$.when( _loadSpecificationSchema(categoryId)).done(
			function(){
				//获取商品规格
				var $pnl_productSpec=$('#pnl_productSpec');
				function success(data){
					if(data!=null && data.length>0){
						$.each(data, function (id, value) {
							$('li',$pnl_productSpec).each(function(){
								var $li=$(this);
								var badgeCount = 0;
								$('input[type=checkbox]', $li).each(function(){
									var $this=$(this);
									if(value.attributeOptionId==$this.val()){
										$this.attr('checked', true);
										$this.parent().addClass('checked');
										var specItem={
											attributeId:value.attributeId,
											attributeOptionId:value.attributeOptionId,
										};
										productSpecObjs.push(specItem);
										var $badge = $('.badge', $li.prev());
										var badgeCount = $badge.text();
										$badge.text(Number(badgeCount)+1);
									}
								});
							});
						});
					}else{
						//$.Warn(tip);
					}
				}
				productController.loadSpecification(productId,success);
			}
		);
	}


	//列出扩展属性模板
	var _loadExtendedAtrributeSchema=function(categoryid){
		function success(data){
			if(data){
				$('#sec_attribute').empty();
				var container = $('<div>');
				richtextList = [];
				$.each(data,function(index, item){
					var row = $('<div>',{class:'form-group'});
					var hidden = $('<input>',{type:'hidden',name:'attributeid',val:item.id,'data-attributetype':item.attributeType});
					row.append(hidden);
					var label = $('<label>',{class:'control-label col-md-2',text:item.frontLabel});
					row.append(label);
					var control;
					var controlid;
					var controlname = 'attributevalue';
					switch(item.attributeType){
						//varchar
						case 1:
							controlid = 'txt_varchar'+index;
							control = $('<input>',{id:controlid,type:'text',name:controlname,val:item.defaultValue,maxlength:200,class:'form-control'});
							if(item.required){
								control.attr('data-rule','required');
								control.attr('data-msg-required','请输入'+item.frontLabel);
							}
							break;
						//datetime
						case 2:
							controlid = 'txt_date'+index;
							control = $('<input>',{id:controlid,type:'text',name:controlname,val:item.defaultValue,maxlength:19,class:'date-picker form-control'});
							if(item.required){
								control.attr('data-rule','required');
								control.attr('data-msg-required','请输入'+item.frontLabel);
							}
							break;
						//decimal
						case 3:
							controlid = 'txt_decimal'+index;
							control = $('<input>',{id:controlid,type:'text',name:controlname,val:item.defaultValue,maxlength:20,class:'form-control'});
							if(item.required){
								control.attr('data-rule','required');
								control.attr('data-msg-required','请输入'+item.frontLabel);
							}

							break;
						//int
						case 4:
							controlid = 'txt_int'+index;
							control = $('<input>',{id:controlid,type:'text',name:controlname,val:item.defaultValue,maxlength:11,class:'form-control'});
							if(item.required){
								control.attr('data-rule','required');
								control.attr('data-msg-required','请输入'+item.frontLabel);
							}
							break;
						//text
						case 5:
							controlid = 'txt_richtext'+index;
							control = $('<input>',{id:controlid,name:controlname,type:'hidden'});
							richtextList[index] = controlid;
							break;
						//multiple
						case 6:
							controlid = 'sel_eaMulti'+index;
							if(item.unique){
								control = $('<select>',{id:controlid,name:controlname});
							}else{
								control = $('<select>',{id:controlid,name:controlname,multiple:'multiple','data-keepOrder':true,'data-dblClick':true});
							}
							$.each(item.options,function(optionid,option){
								var option = $('<option>',{val:optionid,text:option});
								control.append(option);
							});
							if(item.required){
								$('#sec_attribute').on('blur','#sel_eaMulti'+index,function(){
									if($(this).val()==''){
										layer.msg('请选择'+item.frontLabel);
									}
								});
							}
							break;
						default:
							controlid = null;
							control = null;
							break;
					}
					var controlWrapper = $('<div>',{class:'col-md-3'});
					controlWrapper.append(control);
					if(item.attributeType == 5){
						var scriptId = controlid+'script';
						controlWrapper.append($('<script>',{id:scriptId,name:scriptId,type:'text/plain'}));
					}
					row.append(controlWrapper);
					if(controlid){
						var tip = $('<span>',{class:'msg-box col-md-1',for:controlid});
						row.append(tip);
					}
					container.append(row);
				});
				$('#sec_attribute').append(container);

				//初始化多选
				require(['multi-select'], function(){
					$('#sec_attribute select[multiple=multiple]').multiSelect({
						keepOrder:true,
						selectableHeader:'待选项',
						selectionHeader:'已选项'
					});
				})

				//初始化日期选择
				require(['js/module/datepicker'], function(datepicker){
					datepicker.init('+0d');
				})

				//初始化富文本
				$.each(richtextList,function(key,value){
					if(value){
						var ueditor = UE.getEditor(value+'script',{
							initialFrameWidth:800,//初始化宽度
							initialFrameHeight:200,//初始化高度
							maximumWords:2000,//最大字数
							zIndex:0//防止日期选择框被遮挡
						});
						ueditor.addListener('contentChange',function(){
							$('#'+value).val(ueditor.getContent());
						});
					}
				});
			}
		}
		productController.loadExtendedAttributeSchema(categoryid, success);
	}

	//列出扩展属性
	var _loadExtendedAttribut=function(productid){
		function success(data){
			if(data){
				$('#sec_attribute').empty();
				var container = $('<div>');
				richtextList = [];
				multiselectList=[];
				$.each(data,function(index, group){
					if(typeof(group.entityList)!='undefined'){
						$.each(group.entityList,function(index, item){
							var attribute=item.attribute;
							var attributeValue=item.attributeValue;
							var row = $('<div>',{class:'form-group'});
							var hidden = $('<input>',{type:'hidden',name:'attributeid',val:attribute.id,'data-attributetype':attribute.attributeType,'data-attributeValueId':attributeValue.id});
							row.append(hidden);
							var label = $('<label>',{class:'control-label col-md-1',text:attribute.frontLabel});
							row.append(label);
							var controlWrapper = $('<div>',{class:'col-md-3'});
							var control;
							var controlid;
							var controlname = 'attributevalue';

							var value=attribute.defaultValue;
							if (typeof(attributeValue)!= "undefined") {

								if(typeof(attributeValue.value)!= "undefined"){
									value=attributeValue.value
								}
								else{
									value=attributeValue.multiSelectOptionIds
								}
							}

							switch(attribute.attributeType){
								//varchar
								case 1:
									controlid = 'txt_varchar'+index;
									control = $('<input>',{id:controlid,type:'text',name:controlname,val:value,maxlength:200,class:'form-control'});
									if(attribute.required){
										control.attr('data-rule','required');
										control.attr('data-msg-required','请输入'+attribute.frontLabel);
									}
									break;
								//datetime
								case 2:
									controlid = 'txt_date'+index;
									control = $('<input>',{id:controlid,type:'text',name:controlname,val:value,maxlength:19,class:'date-picker form-control'});
									if(attribute.required){
										control.attr('data-rule','required');
										control.attr('data-msg-required','请输入'+attribute.frontLabel);
									}
									break;
								//decimal
								case 3:
									controlid = 'txt_decimal'+index;
									control = $('<input>',{id:controlid,type:'text',name:controlname,val:value,maxlength:20,class:'form-control'});
									if(attribute.required){
										control.attr('data-rule','required');
										control.attr('data-msg-required','请输入'+attribute.frontLabel);
									}

									break;
								//int
								case 4:
									controlid = 'txt_int'+index;
									control = $('<input>',{id:controlid,type:'text',name:controlname,val:value,maxlength:11,class:'form-control'});
									if(attribute.required){
										control.attr('data-rule','required');
										control.attr('data-msg-required','请输入'+attribute.frontLabel);
									}
									break;
								//text
								case 5:
									controlid = 'txt_richtext'+index;
									control = $('<input>',{id:controlid,name:controlname,type:'hidden',val:value});
									richtextList[index] = controlid;
									break;
								//multiple
								case 6:
									controlid = 'sel_eaMulti'+index;
									multiselectList.push(controlid);
									if(attribute.unique){
										control = $('<select>',{id:controlid,name:controlname});
									}else{
										control = $('<select>',{id:controlid,name:controlname,multiple:'multiple','data-keepOrder':true,'data-dblClick':true});
									}
									$.each(attribute.options,function(optionid,option){
										var option = $('<option>',{val:optionid,text:option});
										control.append(option);
									});
									if(attribute.required){
										$('#sec_attribute').on('blur','#sel_eaMulti'+index,function(){
											if($(this).val()==''){
												layer.msg('请选择'+attribute.frontLabel);
											}
										});
									}

									break;
								default:
									controlid = null;
									control = null;
									break;
							}

							var controlWrapper = $('<div>',{class:'col-md-3'});

							controlWrapper.append(control);
							if(attribute.attributeType == 5){
								var scriptId = controlid+'script';
								controlWrapper.append($('<script>',{id:scriptId,name:scriptId,type:'text/plain'}));
							}
							if(attribute.attributeType == 6){
								controlWrapper.append($('<input>',{id:"hid_"+controlid,type:'hidden',val:value}));
							}

							row.append(controlWrapper);
							if(controlid){
								var tip = $('<span>',{class:'msg-box col-md-1',for:controlid});
								row.append(tip);
							}
							container.append(row);
							//container.append(initExtendedAttributRow(index,richtextList,item.attribute,item.attributeValue));
						})
					}
				});
				$('#sec_attribute').append(container);

				//初始化多选
				require(['multi-select'], function(){
					$('#sec_attribute select[multiple=multiple]').multiSelect({
						keepOrder:true,
						selectableHeader:'待选项',
						selectionHeader:'已选项'
					});

					//赋值
					$.each(multiselectList,function(key,value){
						$('#'+value).multiSelect('select',$('#hid_'+value).val().split(','));
					})
				})

				//初始化日期选择
				require(['js/module/datepicker'], function(datepicker){
					datepicker.init('+0d');
				})

				//初始化富文本
				$.each(richtextList,function(key,value){

					if(value){
						var ueditor = UE.getEditor(value+'script',{
							initialFrameWidth:800,//初始化宽度
							initialFrameHeight:200,//初始化高度
							maximumWords:2000,//最大字数
							zIndex:0//防止日期选择框被遮挡
						});


						/*ueditor.ready(function() {
						 ueditor.setContent($('#'+value).val());
						 });*/

						ueditor.addListener('contentChange',function(){
							$('#'+value).val(ueditor.getContent());
						});

						ueditor.addListener('ready', function () {
							//editor准备好之后才可以使用
							ueditor.setContent($('#'+value).val());
						});
					}
				});

			}
		}
		productController.loadExtendedAttribute(productid,success);
	}


	//列出参数模板
	var _loadParameterSchema=function(categoryid){
		function success(data){
			if(data){
				$('#sec_parameter').empty();
				var panelGroup = $('<div>',{class:'panel-group'});
				$.each(data,function(index,group){
					var groupId = 'pnl_parameterGroup' + group.id;
					var panel = $('<div>',{class:'panel panel-default'});
					var head = $('<h4>',{class:'panel-title'});
					head.append($('<a>',{'data-toggle':'collapse','data-parent':'#accordion',href:'#'+groupId,text:group.name}));
					var panelHead = $('<div>',{class:'panel-heading'});
					panelHead.append(head);
					panel.append(panelHead);
					var panelBody = $('<div>',{class:'panel-body'});
					$.each(group.attributes,function(id,attribute){
						var attributeId = 'txt_parameter' + attribute.id;
						var formGroup = $('<div>',{class:'form-group'});
						var hidden = $('<input>',{type:'hidden',name:'attributeid',val:attribute.id,'data-attributetype':attribute.attributeType});
						var label = $('<label>',{class:'col-md-2 control-label',text:attribute.backendLabel+":",for:attributeId});
						var div=$('<div>',{class:'col-md-3'});
						var input = $('<input>',{id:attributeId,type:'text','data-rule':'length[~160]','data-msg-length':'请输入至多160个字符',maxlength:160,class:'form-control',val:attribute.defaultValue,name:'attributevalue'});
						formGroup.append(hidden).append(label).append(div.append(input));
						var messageBox = $('<span>',{class:'msg-box'});
						formGroup.append(messageBox);
						//panelBody.append(formGroup);
					});
					var panelBodyWrapper = $('<div>',{id:groupId,class:'panel-collapse collapse in'});
					//panelBodyWrapper.append(panelBody);
					panel.append(panelBodyWrapper);
					panelGroup.append(panel);
				});
				panelGroup.appendTo('#sec_parameter');
			}
		}
		productController.loadParameterSchema(categoryid, success);
	}

	//列出参数数据
	var _loadParameter=function(productid){
		function success(data){
			if(data){
				$('#sec_parameter').empty();
				var panelGroup = $('<div>',{class:'panel-group'});
				$.each(data,function(index,group){
					var groupId = 'pnl_parameterGroup' + group.id;
					var panel = $('<div>',{class:'panel panel-default'});
					var head = $('<h4>',{class:'panel-title'});
					head.append($('<a>',{'data-toggle':'collapse','data-parent':'#accordion',href:'#'+groupId,text:group.groupName}));
					var panelHead = $('<div>',{class:'panel-heading'});
					panelHead.append(head);
					panel.append(panelHead);
					var panelBody = $('<div>',{class:'panel-body'});
					$.each(group.entityList,function(id,item){
						var attribute=item.attribute;
						var attributeValue=item.attributeValue;
						var attributeId = 'txt_parameter' + attribute.id;
						var formGroup = $('<div>',{class:'form-group'});
						var hidden = $('<input>',{type:'hidden',name:'attributeid',val:attribute.id,'data-attributetype':attribute.attributeType,'data-attributeValueId':attributeValue.id});
						var label = $('<label>',{class:'col-md-1 control-label',text:attribute.backendLabel+":",for:attributeId});
						var div=$('<div>',{class:'col-md-3'});
						var input = $('<input>',{id:attributeId,type:'text','data-rule':'length[~160]','data-msg-length':'请输入至多160个字符',maxlength:160,class:'form-control',val:attributeValue.value,name:'attributevalue'});
						formGroup.append(hidden).append(label).append(div.append(input));
						var messageBox = $('<span>',{class:'msg-box'});
						formGroup.append(messageBox);
						//panelBody.append(formGroup);
					});
					var panelBodyWrapper = $('<div>',{id:groupId,class:'panel-collapse collapse in'});
					//panelBodyWrapper.append(panelBody);
					panel.append(panelBodyWrapper);
					panelGroup.append(panel);
				});
				panelGroup.appendTo('#sec_parameter');
			}
		}
		productController.loadParameter(productid,success);
	}


	//生成货品列表
	var _generateStyle=function(e){
		e.preventDefault();
		$('#pnl_style').show();
		var productCode=$('#txt_productCode').val();
		var productWeight=$('#txt_productWeight').val();
		var $tblProductStyle=$('tbody',$('#tbl_productStyle'));
		var $tr = assembleStyleRow(productCode, productWeight);
		$tblProductStyle.append($tr);
	}

	function _clearStyle(e){
		e.preventDefault();
		$('#tbl_productStyle tbody tr').each(function(i, tr){
			if(!$(this).data('id')){
				tr.remove();
			}
		});
	}

	function _deleteStyle(e){
		e.preventDefault();
		var $tr = $(this).parents('tr');
		var styleId = $tr.data('id');
		if(styleId > 0){
			function success(data){
				if(data.result){
                    layer.msg(data.tip);
					window.setInterval(function(){
						location.href=productController.controllers.editView.url+$('#hid_productId').val();
					},2000);
				}else{
					layer.msg(data.tip);
				}
			}
			productController.deleteStyle(styleId, success);
		}else{
			$tr.remove();
		}
	}

	function assembleStyleRow(productCode, productWeight){
		var $tr=$('<tr>',{
			'data-optionids':'[]',
			'data-stylename':''
		});

		var i = $('#tbl_productStyle tr').length-1;

		//var $td_name=$('<td>',{text:''});
		var $td_name=$('<td>').append($('<input>',{
			class:'form-control',
			type:'text',
			name:'name',
			id:'name'+i,
			'data-rule':'length[2~60]',
			style:'width:260px'
		}));

		var $td_goodscode=$('<td>').append($('<input>',{
			class:'form-control',
			type:'text',
			name:'goodscode',
			id:"goodscode"+i,
			val:productCode,
			'data-rule':'required;length[0~60]',
			style:'width:140px'
		}));
		var $td_barcode=$('<td>').append($('<input>',{
			class:'form-control',
			type:'text',
			name:'barcode',
			id:'barcode'+i,
			'data-rule':'length[0~60]',
			style:'width:140px'
		}));

		var $hidWeight = $('<input>',{
			type:'hidden',
			id:'hid_weight'+i,
			val:productWeight
		});
		var $selWeightUnit = $('<select>',{
			class:'sel_weight',
			id:'sel_weight'+i,
			'data-id':i
		});

		var $txtWeight = $('<input>',{
			class:'form-control txt_weight',
			type:'text',
			id:'txt_weight'+i,
			'data-id':i,
			val:productWeight,
			'data-rule':'required;floating;',
			style:'float:left;width:70px'
		});

		var options = ['克','千克','吨'];
		var unitType;
		if(productWeight >= 1000000){
			unitType = 3;
		}else if(productWeight >= 1000){
			unitType = 2;
		}else{
			unitType = 1;
		}
		$.each(options, function(index, text){
			var $option;
			if(unitType == (index + 1)){
				$option = $('<option>', {val:index + 1, text:text, selected:'selected'});
			}else{
				$option = $('<option>', {val:index + 1, text:text});
			}
			$selWeightUnit.append($option);
		});

		var $divWeightUnit = $('<div>',{
			class:'input-group-addon',
			//style:'padding:0'
			style:'padding:0;float:left;'
		});
		$divWeightUnit.append($selWeightUnit);

		var $div_weight = $('<div>', {class:'input-group'});
		$div_weight.append($hidWeight).append($txtWeight).append($divWeightUnit);
		var $td_weight=$('<td>').append($div_weight);

		var $hidVolume = $('<input>',{
			type:'hidden',
			id:'hid_volume'+i
		});

		var $txtVolume = $('<input>',{
			class:'form-control txt_volume',
			type:'text',
			id:'txt_volume'+i,
			'data-id':i,
			'data-rule':'required;floating;',
			style:'float:left;width:70px;'
		});

		var $selVolumeUnit = $('<select>',{
			class:'sel_volume',
			id:'sel_volume'+i,
			'data-id':i
		});

		var volumeOptions = ['立方厘米','立方米'];
		var volumeUnitType = 1;

		$.each(volumeOptions, function(index, text){
			var $option;
			if(volumeUnitType == (index + 1)){
				$option = $('<option>', {val:index + 1, text:text, selected:'selected'});
			}else{
				$option = $('<option>', {val:index + 1, text:text});
			}
			$selVolumeUnit.append($option);
		});

		var $divVolumeUnit = $('<div>',{
			class:'input-group-addon',
			//style:'padding:0'
			style:'padding:0;float:left;'
		});
		$divVolumeUnit.append($selVolumeUnit);

		var $div_volume = $('<div>', {class:'input-group'});
		$div_volume.append($hidVolume).append($txtVolume).append($divVolumeUnit);
		var $td_volume=$('<td>').append($div_volume);

		var $deleteButton = $('<button>', {class:'btn btn-danger deleteStyle', text:'删除'});
		var $td_operate = $('<td>').append($deleteButton);
		$tr.append($td_name)
			.append($td_goodscode)
			.append($td_barcode)
			.append($td_weight)
			.append($td_volume)
			.append($td_operate);
		return $tr;
	}

	function setProductStyle(){
		//清除款式
		productStyleObjs.length=0;
		//赋值goods对象
		$('tbody>tr',$('#tbl_productStyle')).each(function(index){
			var $tr=$(this);
			$tds=$tr.find('td');

			//多项款式规格重量初始化数据
			ui_changeWeightinit($tr.data('id'));
			//多项款式规格体积初始化数据
			ui_changeVolumeinit($tr.data('id'));

			var item={
				id:$tr.data('id'),
				//name:$tr.data('stylename'),
				name:$('input',$tds[0]).val(),
				code:$('input',$tds[1]).val(),
				barCode:$('input',$tds[2]).val(),
				weight:$('input[type=hidden]',$tds[3]).val(),
				volume:$('input[type=hidden]',$tds[4]).val(),
				optionIdList:$tr.data('optionids'),
			};
			/*if($tr.data('id')){
			 item.id=$tr.data('id')
			 }*/
			productStyleObjs.push(item);
		})

		//如果是多款
		/*if(productSpecObjs.length>0){
		 //赋值goods对象
		 $('tbody>tr',$('#tbl_productStyle')).each(function(index){
		 var $tr=$(this);
		 $tds=$tr.find('td');

		 //多项款式规格重量初始化数据
		 ui_changeWeightinit($tr.data('id'));
		 //多项款式规格体积初始化数据
		 ui_changeVolumeinit($tr.data('id'));

		 var item={
		 //name:$tr.data('stylename'),
		 name:$('input',$tds[0]).val(),
		 code:$('input',$tds[1]).val(),
		 barCode:$('input',$tds[2]).val(),
		 weight:$('input[type=hidden]',$tds[3]).val(),
		 volume:$('input[type=hidden]',$tds[4]).val(),
		 optionIdList:$tr.data('optionids'),
		 };
		 if($tr.data('id')){
		 item.id=$tr.data('id')
		 }
		 productStyleObjs.push(item);
		 })
		 }else{

		 //单一款式规格重量初始化数据
		 ui_calculateWeightinit();
		 //单一款式规格体积初始化数据
		 ui_calculateVolumeinit();

		 var item={
		 name:$('#txt_productName').val(),
		 code:$('#txt_goodscode').val(),
		 barCode:$('#txt_barcode').val(),
		 weight:$('#hid_weight').val(),
		 volume:$('#hid_volume').val()
		 };
		 //alert("商品名称1："+$('#txt_productName').val()+" "+$('#txt_goodscode').val()+" "+$('#txt_barcode').val()+" "+$('#hid_weight').val()+" "+$('#hid_volume').val());
		 productStyleObjs.push(item);
		 }*/
		return productStyleObjs;
	}

	//新增货品
	var _addGoods=function(){
		setProductStyle();
	}

	//单一款式规格重量初始化数据
	function ui_calculateWeightinit(){
		var weight = $('#txt_weight').val();
		if(weight != ''){
			var weight = Number(weight);
			var type = $('#sel_weight').val();
			if(type == 1){
				$('#hid_weight').val(weight);
			}else if(type == 3 ){
				$('#hid_weight').val(weight * 1000 * 1000);
			}else{
				$('#hid_weight').val(weight * 1000);
			}
		}else{
			$('#hid_weight').val(0);
		}
	}
	//多项款式规格重量初始化数据
	function ui_changeWeightinit(idvalue){
		//var id =$(this).data('id');
		var id = idvalue;
		var weight = $('#txt_weight' + id).val();
		var unit = $('#sel_weight' + id).val();
		var hidWeight = $('#hid_weight' + id);
		if(weight != ''){
			if(unit == 1){
				hidWeight.val(weight);
			}else if(unit == 3 ){
				hidWeight.val(weight * 1000 * 1000);
			}else{
				hidWeight.val(weight * 1000);
			}
		}else{
			hidWeight.val(0);
		}
	}

	//单一款式规格体积初始化数据
	function ui_calculateVolumeinit(){
		var volume = $('#txt_volume').val();
		if(volume != ''){
			var volume = Number(volume);
			var type = $('#sel_volume').val();
			if(type == 1){
				$('#hid_volume').val(volume);
			}else{
				$('#hid_volume').val(volume * 1000 * 1000);
			}
		}
	}
	//多项款式规格体积初始化数据
	function ui_changeVolumeinit(idvalue){
		//var id =$(this).data('id');
		var id = idvalue;
		var volume = $('#txt_volume' + id).val();
		var unit = $('#sel_volume' + id).val();
		var hidVolume = $('#hid_volume' + id);
		if(volume != ''){
			if(unit == 1){
				hidVolume.val(volume);
			}else{
				hidVolume.val(volume * 1000 * 1000);
			}
		}else{
			hidVolume.val(0);
		}
	}

	var _updateStles=function(productid){

		if(!_validateStyle()){
			return false;
		}

		setProductStyle();

		var productObj={};
		//商品id
		productObj.id=$('#hid_productId').val();

		if(productStyleObjs.length>0){
			for(var i=0;i<productStyleObjs.length;i++){
				productStyleObjs[i].productId=$('#hid_productId').val();
			}
			productObj.productStyles=productStyleObjs;
		}

		//款式
		/*if(productSpecObjs.length>0){
		 productObj.specifications= productSpecObjs;
		 if(productStyleObjs.length>0){
		 for(var i=0;i<productStyleObjs.length;i++){
		 productStyleObjs[i].productId=$('#hid_productId').val();
		 }
		 productObj.productStyles=productStyleObjs;
		 }
		 }else{
		 if(productStyleObjs.length>0){
		 for(var i=0;i<productStyleObjs.length;i++){
		 productStyleObjs[i].productId=$('#hid_productId').val();
		 productStyleObjs[i].id=$('#hid_singleProductStyleId').val();
		 }
		 productObj.productStyles=productStyleObjs;
		 }
		 }*/

		function success(data){
			var tip=data.tip;
			if(data.result){
                layer.msg(tip);
				window.setInterval(function(){
					location.href=productController.controllers.editView.url+productObj.id;
				},2000);
			}else{
                layer.msg(tip);
			}
		}
		productController.updateProductStyle(productObj,success);
	}


	function setExtendedAttribute(){
		attributeValues.length=0;
		//赋值attributeValues对象
		$('#sec_attribute .form-group').each(function(index,item){
			var that = $(this);
			var $hid=that.find('input[name=attributeid]');
			var typeid=$hid.data('attributetype');
			var item={
				attributeId:$hid.val(),
				attributeType:typeid,
				value:that.find('[name=attributevalue]').val(),
			};
			var attributeValueId=$hid.data('attributevalueid');
			if (attributeValueId) {
				item.id=attributeValueId;
			}

			//处理多选值
			if(typeid==6){
				var selectIds=[];

				if(item.value!=null){
					for(var i=0;i<item.value.length;i++){
						selectIds.push(item.value[i]);
					}
				}
				item.multiSelectOptionIds=selectIds;
			}
			attributeValues.push(item);
		});
	}

	//新增扩展属性
	var _addExtendedAttribute=function(){
		setExtendedAttribute();
	}

	var _updateExtendedAttribute=function(){
		setExtendedAttribute();
		function success(data){
			var tip=data.tip;
			if(data.result){
                layer.msg(tip);
				$('#btn_listproduct').trigger('click');
			}else{
                layer.msg(tip);
			}
		}

		var productObj={};
		//商品id
		productObj.id=$('#hid_productId').val();
		//商品id
		productObj.categoryId=$("#hid_category").val();;
		//货品
		if(attributeValues.length>0){
			productObj.attributeValues= attributeValues;
		}
		productController.updateExtendedAttribute(productObj,success);
	}

	function setParameter(){
		parameter.length=0;
		//赋值parameter对象
		$('#sec_parameter .form-group').each(function(index,item){
			var that = $(this);
			var $hid=that.find('input[name=attributeid]');
			var typeid=$hid.data('attributetype');
			var value=that.find('[name=attributevalue]').val();
			if(value){
				var item={
					attributeId:$hid.val(),
					attributeType:typeid,
					value:value,
				};
				var attributeValueId=$hid.data('attributevalueid');
				if (attributeValueId) {
					item.id=attributeValueId;
				}
				parameter.push(item);
			}
		});
	}

	//新增参数属性
	var _addParameter=function(){
		setParameter();
	}

	var _updateParameter=function(){
		setParameter();
		function success(data){
			var tip=data.tip;
			if(data.result){
                layer.msg(tip);
				$('#btn_listproduct').trigger('click')
			}else{
                layer.msg(tip);
			}
		}

		var productObj={};
		//商品id
		productObj.id=$('#hid_productId').val();
		//商品id
		productObj.categoryId=$("#hid_category").val();;
		//货品
		if(parameter.length>0){
			productObj.parameterValues= parameter;
		}
		productController.updateParameter(productObj,success);
	}


	//规格全选
	var _allSpecCheck=function(){
		var checked = $(this).is(':checked');
		$('input[type=checkbox]:not(":disabled")',$('#pnl_productSpec')).each(function(){
			var $this=$(this);
			if (checked) {
				$this.attr('checked', true);
				$this.parent().addClass('checked');
			} else {
				$this.attr('checked', false);
				$this.parent().removeClass('checked');
			}
		})
		$('li:has(input[type=checkbox])',$('#pnl_productSpec')).each(function(){
			_countSpecCount($(this));
		})
	}

	//计算选中规格的数量
	var _countSpecCount=function($li){
		var specCount=$li.find('.checked').size();
		$li.prev().find('span.badge').html(specCount);
	}

	function _validateStyle(){
		var result=true;
		$('tbody>tr',$('#tbl_productStyle')).each(function(index){
			var $tr=$(this);
			$tds=$tr.find('td');
			if($('input',$tds[0]).val().length < 2){
				alert("规格名称不能小于两个！");
				result=false;
				return result;
			}
		})
		return result;
	}

	//笛卡尔积计算
	var cross_join = {
		/**
		 * 参考例子
		 * cross_join.json_data = [
		 *   [1,2,3],
		 *   ['a','b','c','d'],
		 *   ['x','y'],
		 *   ['i','j','k']
		 *  ];
		 */
		json_data:[],   //笛卡尔乘积的数据
		json_data_format:function(data){    //json数据项的格式化
			return data;
		},
		json_obj_format:function(json){
			var result = [];
			for(var i=0; i<json.length; i++){
				var len = result.length;
				result[len] = cross_join.json_data_format(json[i]);
			}
			return result;
		},
		json_get_list:function(){   //外部调用，得到笛卡尔乘积的对象数据
			if(cross_join.json_data.length == 0){   //如果json_data为空，则返回空对象
				return [];
			}
			//合并list的内部函数
			var join_list = function(part1,part2){
				var result = [];
				for(var i=0; i<part1.length; i++){
					for(var j=0; j<part2.length; j++){
						var len = result.length;
						//合并json对象
						if(part1[i] instanceof Array){
							result[len] =part1[i].concat(cross_join.json_data_format(part2[j]));
						}
						else
						{
							result[len] =[part1[i],cross_join.json_data_format(part2[j])];
						}
					}
				}
				return result;
			};
			var result = cross_join.json_obj_format(cross_join.json_data[0]);   //初始化第一个json对象的格式化
			for(var i=1; i<cross_join.json_data.length; i++){
				result = join_list(result, cross_join.json_data[i]);
			}
			return result;
		}
	};

	return {
		initBaseForm:_initBaseForm,
		initPicture:_initPicture,
		initCatagorySelect:_initCatagorySelect,
		addProduct:_addProduct,
		updateProduct:_updateProduct,
		addPicture:_addPicture,
		updatePicture:_updatePicture,
		validatePictures:_validatePictures,
		updateStles:_updateStles,
		saveDetails:_saveDetails,
		saveMobileDetails:_saveMobileDetails,
		updateExtendedAttribute:_updateExtendedAttribute,
		updateParameter:_updateParameter,
		loadSpecificationSchema:_loadSpecificationSchema,
		loadSpecification:_loadSpecification,
		loadExtendedAttribut:_loadExtendedAttribut,
		loadExtendedAtrributeSchema:_loadExtendedAtrributeSchema,
		loadParameterSchema:_loadParameterSchema,
		loadParameter:_loadParameter,
		generateStyle:_generateStyle,
		clearStyle:_clearStyle,
		deleteStyle:_deleteStyle,
		addGoods:_addGoods,
		addExtendedAttribute:_addExtendedAttribute,
		addParameter:_addParameter,
		allSpecCheck:_allSpecCheck,
		countSpecCount:_countSpecCount,
		validateStyle:_validateStyle,
		// 新增（图片的）
		addPicture1:_addPicture1,
		updatePicture1:_updatePicture1,
		validatePictures1:_validatePictures1,
		data_delete:data_delete,
		data_delete1:data_delete1
	};
});

//var loginstate=localStorage.getItem("login_state");
//if(loginstate !="4"){
//	var productStarAdd = $('#product_state').html();
//	var productEdit = $('#product_state').html();
//	if(productStarAdd == 'state_0'){
//		var manufacturerId=localStorage.getItem("manufacturerId");
//	}
//	if(productEdit == 'state_1'){
//		var editmanufaurer=$('#hid_manufacturerId').val();
//		localStorage.setItem("manufacturerIdEdit",editmanufaurer);
//		var manufacturerId=localStorage.getItem("manufacturerIdEdit");
//	}
//
//	$('#submitEdit').click(function(){
//		var selectedValue = $('#sel_manufacturer').val();
//		localStorage.setItem("manufacturerIdEdit",selectedValue);
//		var manufacturerId=localStorage.getItem("manufacturerIdEdit")
//		$('#hid_manufacturerId').val(manufacturerId);
//	});
//}