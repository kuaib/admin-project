define([ 'jquery'], function($) {
	'use strict';
	var root='https://admin.vjidian.com/3004/productinfo';
	//定义全部请求的Controller
	var controllers = {
		show:{url:root+'/showexamine'},
		add:{url:root+'/addjy',type:'POST',dataType:'JSON',data:{}},
		addView:{url:root+'/operate/addjy/'},
		editView:{url:root+'/operate/editexamine/'},
		updateProduct:{url:root+'/updateProductjy',type:'POST',dataType:'JSON',data:{}},
		//updateDetails(url:root/'updateDetails',type:'POST',dataType:'JSON',data:{}:)
		updateProductStyle:{url:root+'/updateProductStylejy',type:'POST',dataType:'JSON',data:{}},
		updateExtendedAttribute:{url:root+'/updateExtendedAttribute',type:'POST',dataType:'JSON',data:{}},
		updateSpecification:{url:root+'/updateSpecification',type:'POST',dataType:'JSON',data:{}},
		updateParameter:{url:root+'/updateParameter',type:'POST',dataType:'JSON',data:{}},
		getPage:{url:root+'/pageexamine',type:'POST',dataType:'JSON',data:{}},
		loadSpecification:{url:root+'/loadSpecification',type:'POST',dataType:'JSON',data:{}},
		loadSpecificationSchema:{url:root+'/loadSpecificationSchema',type:'POST',dataType:'JSON',data:{}},
		loadExtendedAttribute:{url:root+'/loadExtendedAttribute',type:'POST',dataType:'JSON',data:{}},
		loadExtendedAttributeSchema:{url:root+'/loadExtendedAttributeSchema',type:'POST',dataType:'JSON',data:{}},
		loadParameterSchema:{url:root+'/loadParameterSchema',type:'POST',dataType:'JSON',data:{}},
		loadParameter:{url:root+'/loadParameter',type:'POST',dataType:'JSON',data:{}},
		updatePicture:{url:root+'/updatePicture',type:'POST',dataType:'JSON',data:{}},
		deletePicture:{url:root+'/deletePicture',type:'POST',data:{}},
		del:{url:root+'/deljy',type:'POST',dataType:'JSON',data:{}}, 
		deleteStyle:{url:root+'/deleteStylejy',type:'POST',dataType:'JSON',data:{}}, 
		examineNext:{url:root+'/examineNext',type:'POST',dataType:'JSON',data:{strPageSize:'',strPageNum:'',strRowno:''}},
		examineProduct:{url:root+'/examineProduct',type:'POST',dataType:'JSON',data:{productId:'',examineDetails:'',status:'',strPageSize:'',strPageNum:'',strRowno:''}},
		bachExamineProductList:{url:root+'/bachExamineProductList',type:'POST',dataType:'JSON',data:{productId:'',examineDetails:'',status:''}},
		examineStyle:{url:root+'/examineStyle',type:'POST',dataType:'JSON',data:{styleId:'',goodid:'',shelfStatus:'',examineDetails:''}}, 
		updateDetails:{url:root+'/updateDetails',type:'POST',dataType:'JSON',data:{}},
		updateMobileDetails:{url:root+'/updateMobileDetails',type:'POST',dataType:'JSON',data:{}},
		updateName:{url:root+'/updateName',type:'POST',dataType:'JSON',data:{productId:'',productName:''}},
		deletePrice:{url:root+'/deletePrice',type:'POST',data:{priceId:''}},
		deleteAllPictures:{url:root+'/deleteAllPictures',type:'POST',data:{productId:''}},
		batchTagProduct:{url:root+'/batchTagProduct',type:'POST',data:{productIds:'',imageTagIds:''}},
	};
	function _ajax(controller,success,error) {
		var ajaxOptions=$.extend(true,controller,{success:success,error:error});
		$.ajax(ajaxOptions);
	}
	function _getPage(data,success,error) {
		controllers.getPage.data=data;
		_ajax(controllers.getPage,success,error);
	}
	function _updateName(productId,productName,success,error){
		var data=controllers.updateName.data;
		data.productId=productId;
		data.productName=productName;
		_ajax(controllers.updateName,success,error);
	}
	function _add(data,success,error){
		controllers.add.data.productJSON=JSON.stringify(data);
		_ajax(controllers.add,success,error);
	}
	function _editView(data,success,error){
		controllers.add.data.productJSON=JSON.stringify(data);
		_ajax(controllers.add,success,error);
	}
	function _updateProduct(data,success,error){
		controllers.updateProduct.data='productJSON='+JSON.stringify(data);
		_ajax(controllers.updateProduct,success,error);
	}
	function _updateSpecification(data,success,error){
		controllers.updateSpecification.data='productJSON='+JSON.stringify(data);
		_ajax(controllers.updateSpecification,success,error);
	}
	function _updateProductStyle(data,success,error){
		controllers.updateProductStyle.data.productJSON=JSON.stringify(data);
		_ajax(controllers.updateProductStyle,success,error);
	}
	function _updateExtendedAttribute(data,success,error){
		controllers.updateExtendedAttribute.data='productJSON='+JSON.stringify(data);
		_ajax(controllers.updateExtendedAttribute,success,error);
	}
	function _updateParameter(data,success,error){
		controllers.updateParameter.data='productJSON='+JSON.stringify(data);
		_ajax(controllers.updateParameter,success,error);
	}
	function _del(id,success,error){
		//controllers.del.url=controllers.del.url+'/'+id;
		controllers.del.url=root+'/deljy/'+id;
		_ajax(controllers.del,success,error);
	}
	function _deleteStyle(styleId,success,error){
		controllers.deleteStyle.data={styleId:styleId};
		_ajax(controllers.deleteStyle,success,error);
	}
	function _examineNext(strPageSize,strPageNum,strRowno,success,error){
		controllers.examineNext.data.strPageSize=strPageSize;
		controllers.examineNext.data.strPageNum=strPageNum;
		controllers.examineNext.data.strRowno=strRowno;
		_ajax(controllers.examineNext,success,error);
	}
	function _examineProduct(productId,examineDetails,status,strPageSize,strPageNum,strRowno,success,error){
		controllers.examineProduct.data.productId=productId;
		controllers.examineProduct.data.examineDetails=examineDetails;
		controllers.examineProduct.data.status=status;
		
		controllers.examineProduct.data.strPageSize=strPageSize;
		controllers.examineProduct.data.strPageNum=strPageNum;
		controllers.examineProduct.data.strRowno=strRowno;
		
		_ajax(controllers.examineProduct,success,error);
	}
	function _bachExamineProductList(productId,examineDetails,status,success,error){
		controllers.bachExamineProductList.data.productId=productId;
		controllers.bachExamineProductList.data.examineDetails=examineDetails;
		controllers.bachExamineProductList.data.status=status;
		_ajax(controllers.bachExamineProductList,success,error);
	}
	function _examineStyle(styleId,goodid,shelfStatus,examineDetails,success,error){
		controllers.examineStyle.data.styleId=styleId;
		controllers.examineStyle.data.goodid=goodid;
		controllers.examineStyle.data.shelfStatus=shelfStatus;
		controllers.examineStyle.data.examineDetails=examineDetails;
		//controllers.examineStyle.data={styleId:styleId,styleName:styleName};
		_ajax(controllers.examineStyle,success,error);
	}
	function _deletePrice(priceId,success,error){
		controllers.deletePrice.data.priceId=priceId;
		_ajax(controllers.deletePrice,success,error);
	}
	function _deletePicture(productId,pictureId,success,error){
		controllers.deletePicture.data.productId=productId;
		controllers.deletePicture.data.pictureId=pictureId;
		_ajax(controllers.deletePicture,success,error);
	}
	function _batchTagProduct(productIds,imageTagIds,success,error){
		var data = {productIds:productIds, imageTagIds:imageTagIds};
		controllers.batchTagProduct.data = data;
		_ajax(controllers.batchTagProduct,success,error);
	}
	function _deleteAllPictures(productId,success,error){
		controllers.deleteAllPictures.data.productId=productId;
		_ajax(controllers.deleteAllPictures,success,error);
	}
	function _loadSpecificationSchema(categoryid,success,error){
		controllers.loadSpecificationSchema.data.categoryid=categoryid;
		_ajax(controllers.loadSpecificationSchema,success,error);
	}
	function _loadSpecification(productId,success,error){
		controllers.loadSpecification.data.productId=productId;
		_ajax(controllers.loadSpecification,success,error);
	}
	function _loadExtendedAttributeSchema(categoryid,success,error){
		controllers.loadExtendedAttributeSchema.data.categoryid=categoryid;
		_ajax(controllers.loadExtendedAttributeSchema,success,error);
	}
	function _loadExtendedAttribute(productid,success,error){
		controllers.loadExtendedAttribute.data.productid=productid;
		_ajax(controllers.loadExtendedAttribute,success,error);
	}
	function _loadParameterSchema(categoryid,success,error){
		controllers.loadParameterSchema.data.categoryid=categoryid;
		_ajax(controllers.loadParameterSchema,success,error);
	}
	function _loadParameter(productid,success,error){
		controllers.loadParameter.data.productid=productid;
		_ajax(controllers.loadParameter,success,error);
	}
	function _updatePicture(data,success,error){
		controllers.updatePicture.data.productJSON=JSON.stringify(data);
		_ajax(controllers.updatePicture,success,error);
	}
	function _updateDetails(productId,details,detailsEN,success,error){
		var data = {productId:productId,details:details,detailsEN:detailsEN};
		controllers.updateDetails.data = data;
		_ajax(controllers.updateDetails,success,error);
	}
	function _updateMobileDetails(productId,mobileDetails,mobileDetailsEN,success,error){
		var data = {productId:productId,mobileDetails:mobileDetails,mobileDetailsEN:mobileDetailsEN};
		controllers.updateMobileDetails.data = data;
		_ajax(controllers.updateMobileDetails,success,error);
	}
	
	return {
		controllers:controllers,
		getPage:_getPage,
		updateName:_updateName,
		add:_add,
		updateProduct:_updateProduct,
		updatePicture:_updatePicture,
		updateSpecification:_updateSpecification,
		updateProductStyle:_updateProductStyle,
		updateExtendedAttribute:_updateExtendedAttribute,
		updateParameter:_updateParameter,
		del:_del,
		deleteStyle:_deleteStyle,
		examineNext:_examineNext,
		examineProduct:_examineProduct,
		examineStyle:_examineStyle,
		deletePrice:_deletePrice,
		deletePicture:_deletePicture,
		batchTagProduct:_batchTagProduct,
		deleteAllPictures:_deleteAllPictures,
		loadSpecificationSchema:_loadSpecificationSchema,
		loadSpecification:_loadSpecification,
		loadExtendedAttributeSchema:_loadExtendedAttributeSchema,
		loadExtendedAttribute:_loadExtendedAttribute,
		loadParameterSchema:_loadParameterSchema,
		loadParameter:_loadParameter,
		updateDetails:_updateDetails,
		updateMobileDetails:_updateMobileDetails,
		bachExamineProductList:_bachExamineProductList,
	};
});
