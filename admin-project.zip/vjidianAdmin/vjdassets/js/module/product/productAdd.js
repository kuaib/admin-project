define(['js/module/bootstrap-dialog','js/module/product/product','app','layer'],function(dialog,product){
    var flag = true; // 区分表格数据编辑还是新增
    var current = false; // 判断验证是否通过
    var count = [];  // 规格参数下拉选项的默认值
// 初始化厂家
    function initManufacturer(){
        var htmlMan = "";
        $.ajax({
            //url: website_address + "vjidian-basic/manufactureradmin/listPage", 分页查询
            url: website_address + "vjidian-basic/manufactureradmin/listManufacturer", // 全部查询
            data:{ticketc:ticketc},
            type:"post",
            success: function(data){
                data = JSON.parse(data);
                $.each(data,function(i,v){
                    k = parseInt(i)+1;
                    htmlMan += '<option value="' + v.id + '">' + v.name + '</option>';
                });
                $("#sel_manufacturer").append(htmlMan);
                $('.selectpicker').selectpicker('refresh'); // 为了刷新下拉插件，使其显示
            }
        })
    }

// 上传图片前对厂家的验证
    function menConfirm(){
        if(!$('#sel_manufacturer').val()){
            layer.msg("必须先选择厂家才能上传图片");
            return false;
        }
    }

// 清空弹层信息
    function clearCover(){
        $(':input','#frm_picture')
            .not(':button, :submit, :reset, :hidden')
            .val('')
            .removeAttr('checked')
            .removeAttr('selected');
        $("#sel_weight").val("千克");// 初始化重量单位为千克
        $("#sel_volume").val("立方分米");// 初始化体积单位为立方分米
        $('#tbl_pictures1').find('.template-download').remove();// 清除图片
        $("#btnAllDelete1").css("display","none"); // 隐藏"删除全部已上传"按钮
        $(".specPara .form-group").html(""); // 清除规格参数的html
    }

// 图片是否默认单选
    function singPic(){
        var $this = $(this);
        $this.prop("checked",true);
        $this.parent().parent().siblings().find(".defaultPic").prop("checked",false);
    }

// 新增产品规格型号
    function addNew(){
        $(".cover").css("display","block");
        //product.initPicture([],$("#frm_picture"),$('#hid_manufacturer').val(),16);
        flag = true;
        clearCover(); // 清空弹层
        $.ajax({
            url: website_address + "vjidian-category/productAttributeOptionAdmin/getOptionsByCategoryId",
            data:{
                categoryId: $("#hid_categoryId").val(),
                ticketc:ticketc
            },
            success:function(data){
                //渲染 各种规格参数(html拼接到弹层中)
                var html = "";
                $.each(data.result,function(i,v){
                    var html1='',html2='',html3 = '</select></div>';
                    html1 += '<div class="inlBox"><label data-attrId="'+ v.id+'" class="specLabel">' + v.backendlabel + '</label>' +
                        '<select class="specSelect">' +
                        '<option value="">请选择</option>'
                    $.each(v.attributeOption,function(idx,val){
                        html2 += '<option value="' + val.id + '">' + val.value + '</option>'
                    });
                    html += html1 + html2 + html3;
                });
                $(".specPara .form-group").append(html);
            }
        })
    }

// 验证弹层中信息
    function confirmData(specifications,list,specParasTags){
        if(specifications.indexOf("规格") != -1 || specifications.indexOf("型号") != -1){
            dialog.alert({
                title: '警告',
                message: "产品规格型号不能出现：“规格”或“型号” 字样"
            });
            $("#txt_specifications").val("");
            $("#txt_specifications").focus();
            current = true;
            return false;
        }
        else if($("p a[data-gallery='']",$('#frm_picture')).size()<=0){
            layer.msg("请选择一张图片,并上传");
            current = true;
            return false;
        }
        else if(specifications.length <= 0){
            $("#txt_specifications").focus();
            $("#txt_specifications").blur();
            $("#txt_specifications").focus();
            current = true;
            return false;
        }
        //else if(list.length <= 0){
        //    $("#txt_list").focus();
        //    $("#txt_list").blur();
        //    $("#txt_list").focus();
        //    current = true;
        //    return false;
        //}
        // else if(count.length < 1){
        //     dialog.alert({
        //         title: '警告',
        //         message: "规格参数最少选择一项"
        //     });
        //     current = true;
        //     return false;
        // }
        else{current = false;}
    }

// 遍历获取各项规格参数的值(被选中的select(selected))
    function totalData(tags){
        var html1 = "",html2 = "";
        count = []; // 为了验证规格参数的数量(每次清空数组防止重复)
        $.each(tags,function(i,v){
            var $this = $(this);
            if($this.val() != ""){
                count.push($this.val());
                html1 += $this.prev().data("attrid") + "," + $this.prev().text() + "," + $this.find("option:selected").val() + "," + $this.find("option:selected").text() + ":";
                html2 += $this.prev().text() + "：" + $this.find("option:selected").text() + "， ";
            }else{
                return;
            }
        });
        return {
            html1:html1.slice(0,html1.length - 1),
            html2:html2.slice(0,html2.length - 2) // 因为最后有一个空格
        }
    }

// 复制表格行
    function copyStyle(e){
        e.preventDefault();
        var $this = $(this);
        var $tr = $this.parents('tr');
        var productId = $("#hid_productId").val();
        $.post(website_address + "vjidian-product/goodsAdmin/styleCopy",
            {goodsId:$tr.attr("data-goodId"),productId: productId,ticketc:ticketc},
            function(data){
                if(data.success == false){
                    layer.msg(data.msg);
                    return false;
                }
                var $newtr =  $tr.clone()
                $newtr.appendTo($tr.parent());
                $newtr.attr({"data-goodId":data.result});// 改变唯一标识
                // 如果是连续的复制，-1不行，所以需要后台返回一个复制后的新编号
                //$newtr.find("td").eq(0).find("div").text($tr.find("td").eq(0).find("div").text(data.name));
            })
    }

// 编辑表格行(渲染弹层)
    var thisEditTr;
    function editStyle(e){
        e.preventDefault();
        $(".cover").css("display","block");
        clearCover();
        flag = false;
        var $that = $(this);
        $("#specId").val($that.parent().parent().data("goodid")); // 隐藏域
        var productId = $("#hid_productId").val();
        var goodsId = $("#specId").val();

        $(".specPara .form-group").html("");// 清空规格参数的select
        thisEditTr = $that.parent().parent("tr");

        // 弹层下半部分展现
        $.ajax({
            url: website_address + "vjidian-category/productAttributeOptionAdmin/getOptionsByCategoryId",
            data:{
                categoryId: $("#hid_categoryId").val(),
                ticketc:ticketc
            },
            success:function(data){
                //渲染 各种规格参数(html拼接到弹层中)
                var html = "";
                $.each(data.result,function(i,v){
                    var html1='',html2='',html3 = '</select></div>';
                    html1 += '<div class="inlBox"><label data-attrId="'+ v.id+'" class="specLabel">' + v.backendlabel + '</label>' +
                        '<select class="specSelect">' +
                        '<option value="">请选择</option>'
                    $.each(v.attributeOption,function(idx,val){
                        html2 += '<option value="' + val.id + '">' + val.value + '</option>'
                    });
                    html += html1 + html2 + html3;
                });
                $(".specPara .form-group").append(html);
            },
            complete: function(){
                // 弹层上半部分展现
                $.ajax({
                    url:website_address + "vjidian-product/goodsAdmin/view",
                    data: {"goodsId":goodsId,"productId":productId,ticketc:ticketc},
                    success:function(data){
                        var data1 = data.result;
                        var data2 = data.map.attributeOptionList; // 规格参数的集合

                        $("#txt_specifications").val(data1.name); // 规格型号
                        product.initPicture(data1.pictureList,$("#frm_picture"),product.data_delete1);  // 上传上的图片初始化，后台传的是一个数组
                        $("#txt_factNum").val(data1.code); // 厂家编号
                        $("#txt_list").val(data1.packingList);// 包装清单
                        $("#txt_weight").val(data1.weight);// 重量
                        $("#sel_weight").val(data1.weightUnit);// 重量单位
                        $("#txt_volume").val(data1.volume); // 体积
                        $("#sel_volume").val(data1.volumeUnit); // 体积单位

                        var myList = $(".cover .specPara .form-group .inlBox");
                        $.each(myList,function(){
                            var labTagId = $(this).find("label").attr("data-attrid");
                            var selTag = $(this).find("select");
                            $.each(data2,function(i,v){
                                if(v.attributeId == labTagId){
                                    selTag.val(v.optionId);
                                }
                            });
                        });
                    }
                });
            }
        })

    }

// 删除表格行
    function deleteStyle(e){
        e.preventDefault();
        var $tr = $(this).parents('tr');
        var goodId = $tr.data('goodid');
        var productId = $("#hid_productId").val();
        $.ajax({
            url: website_address + "vjidian-product/goodsAdmin/delete",
            data: {"goodsIds":goodId,"productId":productId,"ticketc":ticketc},
            success: function(data){
                if(data.success == false){
                    dialog.alert({
                        title: '很抱歉',
                        message: data.msg
                    });
                    return false;
                }
                dialog.alert({
                    title: '恭喜您',
                    message: data.msg
                });
                $tr.remove();
            }
        })
    }

// 保存弹层判断
    function saveCover(e,firstCategoryId,secondCategoryId,thirdCategoryId,fourCategoryId,firstCategoryName,secondCategoryName,thirdCategoryName,fourCategoryName){
        if(flag){
            // 新增
            addSave(e,firstCategoryId,secondCategoryId,thirdCategoryId,fourCategoryId,firstCategoryName,secondCategoryName,thirdCategoryName,fourCategoryName);
        }else{
            // 编辑
            editSave(e);
        }
    }

// 弹层（新增-保存）
    function addSave(e,firstCategoryId,secondCategoryId,thirdCategoryId,fourCategoryId,firstCategoryName,secondCategoryName,thirdCategoryName,fourCategoryName){
        e.preventDefault();
        // 产品规格型号
        var specifications = $("#txt_specifications").val();
        // 厂家编号
        var factNum = $("#txt_factNum").parent().prev().text() + $("#txt_factNum").val();
        // 包装清单
        var list = $("#txt_list").val();
        // 重量
        var weigth = $("#txt_weight").val() == "" ? "" :
            ($("#txt_weight").parent().prev().text()  + $("#txt_weight").val() + $("#sel_weight").find("option:selected").text());
        // 体积
        var volume = $("#txt_volume").val() == "" ? "" :
            ($("#txt_volume").parent().prev().text()  + $("#txt_volume").val() + $("#sel_volume").find("option:selected").text());
        // 各项规格参数总和
        var specParasTags = $(".cover .specPara .form-group select");
        var specParas1 = totalData(specParasTags).html1;// 传给后台
        var specParas2 = totalData(specParasTags).html2;// 用来渲染

        // 产品规格图片
        var picObj = product.addPicture1();
        var picId = picObj.pictures1;
        var deft = picObj.pictures_def1;
        var pictureIds = "";
        if(picId.length > 0){
            $.each(picId,function(i,v){
                pictureIds += "," + v;
            });
            pictureIds = pictureIds.substr(1);
        }

        $.ajax({
            url: website_address + "vjidian-product/goodsAdmin/save",
            type:"POST",
            data: {
                "pictureIds":pictureIds, // 图片的id们
                "deft":deft, // 是否为默认图片
                "sort": "", // 图片排序(id,sort:id,sort形式)
                "name":specifications,
                "manufacturerId":$("#hid_manufacturer").val(),
                "code": $("#txt_factNum").val(),
                "packingList": list,
                "weight": $("#txt_weight").val(),
                "weightUnit": $("#sel_weight").find("option:selected").text(),
                "volume": $("#txt_volume").val(),
                "volumeUnit": $("#sel_volume").find("option:selected").text(),
                "propvalueIds": specParas1,
                "propvalue": specParas2,
                "productId": $("#hid_productId").val(),
                firstCategoryId: firstCategoryId,
                secondCategoryId: secondCategoryId,
                thirdCategoryId: thirdCategoryId,
                fourCategoryId:fourCategoryId,
                firstCategoryName:firstCategoryName,
                secondCategoryName:secondCategoryName,
                thirdCategoryName:thirdCategoryName,
                fourCategoryName:fourCategoryName,
                "ticketc": ticketc
            },
            beforeSend: function(){
                // 验证弹层信息填写
                confirmData(specifications,list,specParasTags);
                if(current){
                    return false;
                }
            },
            success: function(data){
                if(data.success == false){
                    dialog.alert({
                        title: '很抱歉',
                        message: data.msg
                    });
                    return false;
                }
                // 保存一个该条记录的主键id，用于在修改的时候知道是哪条记录(后台返回)
                addTableChildren(specifications,data.map.pictureUrl,specParas2,factNum,list,weigth,volume,data.result);
            }
        })
    }

// 弹层（新增）（在表格后面追加添加的行数据）
    function addTableChildren(specifications,pictures1,specParas2,factNum,list,weigth,volume,goodId){
        var $tr=$('<tr>',{
            'data-optionids':'[]',
            'data-stylename':'',
            'data-itemId':'tr' + ($('#tbl_productStyle tr').length - 1), // 该行的唯一标识
            'data-goodId': goodId
        });

        //产品规格型号
        var $td_name=$('<td data-tdId="0">').append($('<div>'+specifications+'</div>'));

        // 图片
        var $td_goodscode=$('<td data-tdId="1">').append($('<div><img src="'+pictures1+'"></div>'));

        // 各项规格参数
        var $td_barcode = $('<td data-tdId="2">').append($('<div style="width:100%;white-space: normal">'+specParas2+'</div>'));

        // 其他参数
        var $fwv = $('<td data-tdId="3">').append($('<div style="width:100%;white-space: normal">'+ factNum + '<br/>' + weigth + '<br/>' + volume +'</div>'));

        // 包装清单
        var $list = $('<td data-tdId="4">').append($('<div>'+list+'</div>'));

        var $editButton = $('<button>', {class:'btn btn-success editStyle btnMargin', text:'编辑'});
        var $copyButton = $('<button>', {class:'btn btn-success copyStyle btnMargin', text:'复制'});
        var $deleteButton = $('<button>', {class:'btn btn-success deleteStyle', text:'删除'});
        var $td_operate = $('<td>').append($editButton).append($copyButton).append($deleteButton);
        $tr.append($td_name)
            .append($td_goodscode)
            .append($td_barcode)
            .append($fwv)
            .append($list)
            .append($td_operate);
        var $tblProductStyle=$('tbody',$('#tbl_productStyle'));
        $tblProductStyle.append($tr);
        clearCover(); // 清空弹层
        $(".cover").css("display","none");
        $('#pnl_style').show();
    }

// 弹层（编辑-保存）
    function editSave(e,firstCategoryId,secondCategoryId,thirdCategoryId,fourCategoryId,firstCategoryName,secondCategoryName,thirdCategoryName,fourCategoryName){
        e.preventDefault();
        //var strId = $(this).parents("tr").data("goodid");
        var strId = $("#specId").val();;
        // 产品规格型号
        var specifications = $("#txt_specifications").val();
        // 产品规格图片
        var picObj = product.addPicture1();
        var picId = picObj.pictures1;
        var deft = picObj.pictures_def1;
        var pictureIds = "";
        if(picId.length > 0){
            $.each(picId,function(i,v){
                pictureIds += "," + v;
            });
            pictureIds = pictureIds.substr(1);
        }

        // 厂家编号
        var factNum = $("#txt_factNum").parent().prev().text() + $("#txt_factNum").val();
        // 包装清单
        var list = $("#txt_list").val();
        // 重量
        var weigth = $("#txt_weight").val() == "" ? "" :
            ($("#txt_weight").parent().prev().text()  + $("#txt_weight").val() + $("#sel_weight").find("option:selected").text());
        // 体积
        var volume = $("#txt_volume").val() == "" ? "" :
            ($("#txt_volume").parent().prev().text()  + $("#txt_volume").val() + $("#sel_volume").find("option:selected").text());
        // 各项规格参数总和
        var specParasTags = $(".cover .specPara .form-group select");
        var specParas1 = totalData(specParasTags).html1;// 传给后台
        var specParas2 = totalData(specParasTags).html2;// 用来渲染
        $.ajax({
            url: website_address + "vjidian-product/goodsAdmin/update",
            data: {
                "name":specifications,
                "pictureIds":pictureIds, // 图片的id们
                "deft":deft, // 是否为默认图片
                "sort": "",  // 图片排序
                "manufacturerId":$('#hid_manufacturer').val(),
                "code": $("#txt_factNum").val(),
                "packingList": list,
                "weight": $("#txt_weight").val(),
                "weightUnit": $("#sel_weight").find("option:selected").text(),
                "volume": $("#txt_volume").val(),
                "volumeUnit": $("#sel_volume").find("option:selected").text(),
                "propvalueIds": specParas1,
                "propvalue": specParas2,
                "productId": $("#hid_productId").val(),
                firstCategoryId: firstCategoryId,
                secondCategoryId: secondCategoryId,
                thirdCategoryId: thirdCategoryId,
                fourCategoryId:fourCategoryId,
                firstCategoryName:firstCategoryName,
                secondCategoryName:secondCategoryName,
                thirdCategoryName:thirdCategoryName,
                fourCategoryName:fourCategoryName,
                strId: strId,
                "ticketc": ticketc
            },
            beforeSend: function(){
                // 验证弹层信息填写
                confirmData(specifications,list,specParasTags);
                if(current){
                    return false;
                }
            },
            success: function(data){
                if(data.success == false){
                    dialog.alert({
                        title: '很抱歉',
                        message: data.msg
                    });
                    return false;
                }
                editTableChildren(specifications,data.map.pictureUrl,specParas2,factNum,list,weigth,volume);
            }
        });
    }

// 弹层（编辑）（修改表格行数据）
    function editTableChildren(specifications,pictures1,specParas2,factNum,list,weigth,volume){
        thisEditTr.find("td").eq(0).find("div").text(specifications);
        thisEditTr.find("td").eq(1).find("div").find("img").attr("src",pictures1);
        thisEditTr.find("td").eq(2).find("div").text(specParas2);
        thisEditTr.find("td").eq(3).find("div").html(factNum + " <br/> " +　weigth　+"<br/>" + volume);
        thisEditTr.find("td").eq(4).find("div").text(list);
        //clearCover(); // 清空弹层
        $(".cover").css("display","none");
    }


    /****************************************编辑系列**************************************/
// 弹层中（编辑）
    function editSeries(){
        var hid_manufacturer = $("#hid_manufacturer").val();  //厂家id
        var hid_manufacturerName = $("#hid_manufacturerName").val();  //厂家名
        var hid_brandId = $("#hid_brandId").val();  //品牌id
        var hid_brandName = $("#hid_brandName").val();  //品牌名称


        // if(hid_manufacturer == ""){
        //     alert("请选择厂家");
        //     return;
        // }else if(hid_brandId == ""){
        //     alert("请选择品牌");
        //     return;
        // }
        //点击编辑系列从后台提取数据
        $.ajax({
            url : website_address + '/vjidian-product/seriesAdmin/listSeriesByManufacturerId',
            data :　{
                manufacturerId : hid_manufacturer,
                manufacturerName : hid_manufacturerName,
                brandId : hid_brandId,
                brandName : hid_brandName,
                ticketc : ticketc
            },
            success : function(data){
                if(data.success){
                    var trHtml = "";
                    $.each(data.result,function(k,v){
                        trHtml  += '<tr>'
                            +'<td><div class="checker"><span><input type="checkbox"></span></div></td>'
                            +'<td><input type="text" value="'+v.name+'" data-series='+v.id+' ></td>'
                            +'<td>'+v.productNum+'</td></tr>';
                    })
                    $("#tbl_xl tbody").html(trHtml);
                }else{
                    dialog.alert({
                        title : "警告",
                        message : data.msg
                    });
                }
            }

        })
        $(".cover1").show();
        $('body,html').animate({scrollTop:0},0);
    }

//新增点击增加一行
    function addLine(){
        var cover1Tr = '<tr><td><div class="checker"><span><input type="checkbox"></span></div></td><td><input type="text" value="" data-series="0"></td><td>0</td></tr>';
        $("#tbl_xl tbody").append(cover1Tr);
        ifCheckboxChecked();
    }

//全选框点击下面所有复选框选中
    function selAll(){
        $(this).parent("span").toggleClass("checked");
        if($(this).parent("span").hasClass("checked")){
            for(var i=0;i<$("#tbl_xl tbody span").length;i++){
                $("#tbl_xl tbody span").eq(i).addClass("checked");
            }
        }else{
            for(var i=0;i<$("#tbl_xl tbody span").length;i++){
                $("#tbl_xl tbody span").eq(i).removeClass("checked");
            }
        }
    }

//点击单选框
    function sleSing(){
        $(this).toggleClass("checked");
        ifCheckboxChecked();
    }

//判断是否全选中
    function ifCheckboxChecked(){
        var checkedLen = $("#tbl_xl tbody span.checked").length;
        var checkboxLen = $("#tbl_xl tbody span").length;
        if(checkedLen == checkboxLen){
            $("#allCheck").parent("span").addClass("checked");
        }else{
            $("#allCheck").parent("span").removeClass("checked");
        }
    }

//删除选中的行
    function delSelLine(){
        var checkedLen = $("#tbl_xl tbody span.checked").length;
        if(checkedLen != 0){
            if($("#tbl_xl tbody span.checked").parents("td").siblings().text() > 0){
                layer.msg("数量大于1的序列不允许删除！");
            }else{
                var confirmDialog = confirm("您确定要删除吗？");
                if(confirmDialog){
                    var seriesId="";
                    for(var i=0;i<$("#tbl_xl tbody span.checked").length;i++){
                        seriesId += ","+$("#tbl_xl tbody span.checked").eq(i).parent().parent().parent().find("td").eq(1).find("input").data("series");
                    }
                    seriesId = seriesId.substr(1);
                    $.ajax({
                        url : website_address + 'vjidian-product/seriesAdmin/batchDelete',
                        data : {
                            seriesId : seriesId,
                            ticketc : ticketc
                        },
                        success : function(data){
                            if(data.success){
                                dialog.alert({
                                    title : "恭喜您",
                                    message : data.msg
                                });
                                if($("#allCheck").parent("span").hasClass("checked")){
                                    $("#tbl_xl tbody").html("");
                                    $("#allCheck").parent("span").removeClass("checked");
                                }else{
                                    $("#tbl_xl tbody span.checked").parent().parent().parent().remove();
                                }
                                // 删除数据后前一页下拉框内容变化
                                var seriesIdAfter="",seriesNameAfter="";
                                for(var i=0;i<$("#tbl_xl tbody tr").length;i++){
                                    if($("#tbl_xl tbody tr").eq(i).find("td").eq(1).find("input").val() == ""){
                                        layer.msg("系列名称不能为空");
                                        return false;
                                    }else{
                                        seriesIdAfter += ","+$("#tbl_xl tbody tr").eq(i).find("td").eq(1).find("input").data("series");
                                        seriesNameAfter += ","+$("#tbl_xl tbody tr").eq(i).find("td").eq(1).find("input").val();
                                    }
                                }
                                seriesIdAfter = seriesIdAfter.substr(1);
                                seriesNameAfter = seriesNameAfter.substr(1);
                                var optionSeriesAfter = "<option>请选择</option>";
                                seriesIdAfter = seriesIdAfter.split(",");
                                seriesNameAfter = seriesNameAfter.split(",");
                                for(var i=0;i<seriesIdAfter.length;i++){
                                    optionSeriesAfter += '<option value="'+seriesIdAfter[i]+'">'+seriesNameAfter[i]+'</option>'
                                }
                                $("#sel_series").html(optionSeriesAfter);
                            }else{
                                dialog.alert({
                                    title : "警告",
                                    message : data.msg
                                });
                            }
                        }
                    })
                }
            }
        }else{
            layer.msg("请选择删除项");
        }
    }

//保存点击
    function saveSeries(){
        var hid_manufacturer = $("#hid_manufacturer").val();  //厂家id
        var hid_manufacturerName = $("#hid_manufacturerName").val();  //厂家名
        var hid_brandId = $("#hid_brandId").val();  //品牌id
        var hid_brandName = $("#hid_brandName").val();  //品牌名称
        var seriesId="",seriesName="";
        for(var i=0;i<$("#tbl_xl tbody tr").length;i++){
            if($("#tbl_xl tbody tr").eq(i).find("td").eq(1).find("input").val() == ""){
                layer.msg("系列名称不能为空");
                return false;
            }else{
                seriesId += ","+$("#tbl_xl tbody tr").eq(i).find("td").eq(1).find("input").data("series");
                seriesName += ","+$("#tbl_xl tbody tr").eq(i).find("td").eq(1).find("input").val();
            }
        }
        seriesId = seriesId.substr(1);
        seriesName = seriesName.substr(1);
        $.ajax({
            url : website_address + 'vjidian-product/seriesAdmin/save',
            data : {
                manufacturerId : hid_manufacturer,
                manufacturerName : hid_manufacturerName,
                brandId : hid_brandId,
                brandName : hid_brandName,
                seriesId : seriesId,
                seriesName : seriesName,
                ticketc : ticketc
            },
            success : function(data){
                if(data.success){
                    dialog.alert({
                        title : "恭喜您",
                        message : data.msg
                    });
                    $(".cover1").hide();
                    var result = data.result;
                    var optionSeries = "<option>请选择</option>";
                    $.each(result,function(k,v){
                        optionSeries += '<option value="'+v.id+'">'+v.name+'</option>';
                    })
                    $("#sel_series").html(optionSeries);
                }else{
                    dialog.alert({
                        title : "警告",
                        message : data.msg
                    });
                }
            }
        })
    }

    return {
        initManufacturer:initManufacturer,
        menConfirm:menConfirm,
        addNew:addNew,
        confirmData:confirmData,
        totalData:totalData,
        copyStyle:copyStyle,
        editStyle:editStyle,
        deleteStyle:deleteStyle,
        saveCover:saveCover,
        addSave:addSave,
        addTableChildren:addTableChildren,
        editSave:editSave,
        editTableChildren:editTableChildren,

        editSeries:editSeries,
        addLine:addLine,
        selAll:selAll,
        sleSing:sleSing,
        ifCheckboxChecked:ifCheckboxChecked,
        delSelLine:delSelLine,
        saveSeries:saveSeries,
        singPic:singPic
    }
})


