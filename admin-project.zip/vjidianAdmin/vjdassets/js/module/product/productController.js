define([ 'jquery','app'], function($) {
	'use strict';
	//var root='/3001/productinfo';
	var root=website_address;
	//定义全部请求的Controller
	var controllers = {
		show:{url:root+'/show'},
		add:{url:root+'/add',type:'POST',dataType:'JSON',data:{}},
		addView:{url:root+'/operate/add/'},
		picturegroup:{url:root+'/picturegroup'},
		editView:{url:root+'/operate/edit/'},
		updateProduct:{url:root+'/updateProduct',type:'POST',dataType:'JSON',data:{}},
		//updateDetails(url:root/'updateDetails',type:'POST',dataType:'JSON',data:{}:)
		updateProductStyle:{url:root+'/updateProductStyle',type:'POST',dataType:'JSON',data:{}},
		updateExtendedAttribute:{url:root+'/updateExtendedAttribute',type:'POST',dataType:'JSON',data:{}},
		updateSpecification:{url:root+'/updateSpecification',type:'POST',dataType:'JSON',data:{}},
		updateParameter:{url:root+'/updateParameter',type:'POST',dataType:'JSON',data:{}},
		getPage:{url:root+'/page',type:'POST',dataType:'JSON',data:{}},
		loadSpecification:{url:root+'/loadSpecification',type:'POST',dataType:'JSON',data:{}},
		loadSpecificationSchema:{url:root+'/loadSpecificationSchema',type:'POST',dataType:'JSON',data:{}},
		loadExtendedAttribute:{url:root+'/loadExtendedAttribute',type:'POST',dataType:'JSON',data:{}},
		loadExtendedAttributeSchema:{url:root+'/loadExtendedAttributeSchema',type:'POST',dataType:'JSON',data:{}},
		loadParameterSchema:{url:root+'/loadParameterSchema',type:'POST',dataType:'JSON',data:{}},
		loadParameter:{url:root+'/loadParameter',type:'POST',dataType:'JSON',data:{}},
		updatePicture:{url:root+'/updatePicture',type:'POST',dataType:'JSON',data:{}},
		deletePicture:{url:root+'vjidian-product/productAdmin/delPic',type:'POST',data:{ticketc:ticketc}}, // 产品删除
		deletePicture1:{url:root+'vjidian-product/goodsAdmin/delPic',type:'POST',data:{ticketc:ticketc}}, // 商品删除
		del:{url:root+'/del',type:'POST',dataType:'JSON',data:{}},
		bachDeleteProductList:{url:root+'/bachDeleteProductList',type:'POST',dataType:'JSON',data:{productId:'',examineDetails:'',status:''}},
		deleteStyle:{url:root+'/deleteStyle',type:'POST',dataType:'JSON',data:{}},
		updateDetails:{url:root+'/updateDetails',type:'POST',dataType:'JSON',data:{}},
		updateMobileDetails:{url:root+'/updateMobileDetails',type:'POST',dataType:'JSON',data:{}},
		updateName:{url:root+'/updateName',type:'POST',dataType:'JSON',data:{productId:'',productName:''}},
		deletePrice:{url:root+'/deletePrice',type:'POST',data:{priceId:''}},
		deleteAllPictures:{url:root+'/deleteAllPictures',type:'POST',data:{productId:''}},
		batchTagProduct:{url:root+'/batchTagProduct',type:'POST',data:{productIds:'',imageTagIds:''}},
		getListByManufacturerId:{url:root+'/loadBrand',type:'POST',dataType:'JSON',data:{}},


	};
	function _ajax(controller,success,error) {
		var ajaxOptions=$.extend(true,controller,{success:success,error:error});
		$.ajax(ajaxOptions);
	}
	function _getPage(data,success,error) {
		controllers.getPage.data=data;
		_ajax(controllers.getPage,success,error);
	}
	function _updateName(productId,productName,success,error){
		var data=controllers.updateName.data;
		data.productId=productId;
		data.productName=productName;
		_ajax(controllers.updateName,success,error);
	}
	function _add(data,success,error){
		controllers.add.data.productJSON=JSON.stringify(data);
		_ajax(controllers.add,success,error);
	}
	function _updateProduct(data,success,error){
		controllers.updateProduct.data='productJSON='+JSON.stringify(data);
		_ajax(controllers.updateProduct,success,error);
	}
	function _updateSpecification(data,success,error){
		controllers.updateSpecification.data='productJSON='+JSON.stringify(data);
		_ajax(controllers.updateSpecification,success,error);
	}
	function _updateProductStyle(data,success,error){
		controllers.updateProductStyle.data.productJSON=JSON.stringify(data);
		_ajax(controllers.updateProductStyle,success,error);
	}
	function _updateExtendedAttribute(data,success,error){
		controllers.updateExtendedAttribute.data='productJSON='+JSON.stringify(data);
		_ajax(controllers.updateExtendedAttribute,success,error);
	}
	function _updateParameter(data,success,error){
		controllers.updateParameter.data='productJSON='+JSON.stringify(data);
		_ajax(controllers.updateParameter,success,error);
	}
	function _del(id,success,error){
		//controllers.del.url=controllers.del.url+'/'+id;
		controllers.del.url=root+'/del/'+id;
		_ajax(controllers.del,success,error);
	}
	function _bachDeleteProductList(productId,examineDetails,status,success,error){
		controllers.bachDeleteProductList.data.productId=productId;
		controllers.bachDeleteProductList.data.examineDetails=examineDetails;
		controllers.bachDeleteProductList.data.status=status;
		_ajax(controllers.bachDeleteProductList,success,error);
	}
	function _deleteStyle(styleId,success,error){
		controllers.deleteStyle.data={styleId:styleId};
		_ajax(controllers.deleteStyle,success,error);
	}
	function _deletePrice(priceId,success,error){
		controllers.deletePrice.data.priceId=priceId;
		_ajax(controllers.deletePrice,success,error);
	}
	//系统原来的图片删除
	//function _deletePicture(productId,pictureId,success,error){
	//	controllers.deletePicture.data.productId=productId;
	//	controllers.deletePicture.data.pictureId=pictureId;
	//	_ajax(controllers.deletePicture,success,error);
	//}

	/*********12/13 kuaibing修改的图片删除*********/
	//产品图片删除
	function _deletePicture(productId,pictureId,success,error){
		controllers.deletePicture.data.productId=productId;
		controllers.deletePicture.data.pictureId=pictureId;
		_ajax(controllers.deletePicture,success,error);
	}
	//商品图片删除
	function _deletePicture1(goodsId,pictureId,success,error){
		controllers.deletePicture1.data.goodsId=goodsId; // 新增商品型号id
		controllers.deletePicture1.data.pictureId=pictureId;
		_ajax(controllers.deletePicture1,success,error);
	}
	/*********12/13 kuaibing修改的图片删除*********/

	function _batchTagProduct(productIds,imageTagIds,success,error){
		var data = {productIds:productIds, imageTagIds:imageTagIds};
		controllers.batchTagProduct.data = data;
		_ajax(controllers.batchTagProduct,success,error);
	}
	function _deleteAllPictures(productId,success,error){
		controllers.deleteAllPictures.data.productId=productId;
		_ajax(controllers.deleteAllPictures,success,error);
	}
	function _loadSpecificationSchema(categoryid,success,error){
		controllers.loadSpecificationSchema.data.categoryid=categoryid;
		_ajax(controllers.loadSpecificationSchema,success,error);
	}
	function _loadSpecification(productId,success,error){
		controllers.loadSpecification.data.productId=productId;
		_ajax(controllers.loadSpecification,success,error);
	}
	function _loadExtendedAttributeSchema(categoryid,success,error){
		controllers.loadExtendedAttributeSchema.data.categoryid=categoryid;
		_ajax(controllers.loadExtendedAttributeSchema,success,error);
	}
	function _loadExtendedAttribute(productid,success,error){
		controllers.loadExtendedAttribute.data.productid=productid;
		_ajax(controllers.loadExtendedAttribute,success,error);
	}
	function _loadParameterSchema(categoryid,success,error){
		controllers.loadParameterSchema.data.categoryid=categoryid;
		_ajax(controllers.loadParameterSchema,success,error);
	}
	function _loadParameter(productid,success,error){
		controllers.loadParameter.data.productid=productid;
		_ajax(controllers.loadParameter,success,error);
	}
	function _updatePicture(data,success,error){
		controllers.updatePicture.data.productJSON=JSON.stringify(data);
		_ajax(controllers.updatePicture,success,error);
	}
	function _updateDetails(productId,details,detailsEN,success,error){
		var data = {productId:productId,details:details,detailsEN:detailsEN};
		controllers.updateDetails.data = data;
		_ajax(controllers.updateDetails,success,error);
	}
	function _updateMobileDetails(productId,mobileDetails,mobileDetailsEN,success,error){
		var data = {productId:productId,mobileDetails:mobileDetails,mobileDetailsEN:mobileDetailsEN};
		controllers.updateMobileDetails.data = data;
		_ajax(controllers.updateMobileDetails,success,error);
	}
	function _getListByManufacturerId(manufacturerId,success,error) {
		controllers.getListByManufacturerId.data.manufacturerId=manufacturerId;
		_ajax(controllers.getListByManufacturerId,success,error);
	}
	return {
		controllers:controllers,
		getPage:_getPage,
		updateName:_updateName,
		add:_add,
		updateProduct:_updateProduct,
		updatePicture:_updatePicture,
		updateSpecification:_updateSpecification,
		updateProductStyle:_updateProductStyle,
		updateExtendedAttribute:_updateExtendedAttribute,
		updateParameter:_updateParameter,
		del:_del,
		deleteStyle:_deleteStyle,
		deletePrice:_deletePrice,
		deletePicture:_deletePicture,
		batchTagProduct:_batchTagProduct,
		deleteAllPictures:_deleteAllPictures,
		loadSpecificationSchema:_loadSpecificationSchema,
		loadSpecification:_loadSpecification,
		loadExtendedAttributeSchema:_loadExtendedAttributeSchema,
		loadExtendedAttribute:_loadExtendedAttribute,
		loadParameterSchema:_loadParameterSchema,
		loadParameter:_loadParameter,
		updateDetails:_updateDetails,
		updateMobileDetails:_updateMobileDetails,
		bachDeleteProductList:_bachDeleteProductList,
		getListByManufacturerId:_getListByManufacturerId,
		// 12/14 kuaibing新增
		deletePicture1:_deletePicture1 // 商品图片删除
	};
});