/**
 * 商品列表模块
 */
define(['layer','js/module/product/productControllerexamine',
	'js/module/operateButton',
	'data-grid-assemble'], 
	function(layer,productController,operateButton,dataGrid) {

	function renderCreateTime(cell,type,row,meta){
		var d = new Date();
		//审核时间为空
		if (!cell && typeof(cell)!="undefined" && cell!=0){
			return "";
		}else{//审核时间不为空
			d.setTime(cell);
			return d.format('yyyy-MM-dd HH:mm:ss');
		}　		
	}
	
	function ui_auditStateRender(cell,type,row,meta){
		switch(cell){
			case 0:
				return '禁用';
			case 1:
				return '<i class="fa fa-check-circle-o" title="审核通过" style="color:#35aa47;font-size:14px;"></i>审核通过';
			case 2:
				return '<i class="fa fa-check-circle-o" title="审核部分通过" style="color:#35aa47;font-size:14px;"></i>审核部分通过';
			case 3:
				return '<i class="fa fa-times-circle" title="审核不通过" style="color:#e02222;font-size:14px;"></i>审核不通过';
			case 4:
				return '待审核';	
		}
	}
	
	function ui_productTypeRender(cell,type,row,meta){
		switch(cell){
			case 0:
				return '详细商品';
			case 1:
				return '简易商品';
		}
	}
	
	var _actions = {			
			pass: {
				//className: 'fa fa-check-circle-o operationIcon',
				className: 'fa fa-edit operationIcon',
				tip: '审核内容',
				fn: editProduct,
			},
			
		};
	
	var _columns = [ 
		{title:"商品编码",data:"code",order: ["desc"],width:"20%",className:"text-left",orderable:false },
		{title:"审核状态",data:"status",width:"10%",orderable  :false,className:"text-center",defaultContent:'',render:ui_auditStateRender},
		//{title:'审核状态',data:'auditS',width:'10%',orderable : false,className:'text-center',defaultContent:'',render:ui_auditStateRender},
		{title:"商品名称",data:"name",width:"20%",orderable : false,orderable:false},
		{title:"商品类型",data:"productType",width:"10%",orderable  :false,className:"text-center",defaultContent:'',render:ui_productTypeRender},
		{title:"品牌名称",data:"brandName",order: ["desc"],width:"15%",className:"text-left",orderable:false,defaultContent:""},
		{title:"商品分类",data:"categoryName",width:"15%",className:"text-left" ,orderable:false},
		{title:"审核时间",data:"examineTime",width:"20%",className:"text-left" ,orderable:false, render:renderCreateTime}
	];
	var options={
		table:$('#tbl_product'),
		deferRender: true,
		showChecked:true,
		dom:'t',
		columns:_columns,
		ajax:{
		 	url:productController.controllers.getPage.url,
		 	data:function(d){
				var data = $.extend({}, d, {
	    			searchContent: $.trim($('#txt_searchContent').val()),
	    			iDisplayLength: $('#hid_pageSize').val(),
	    			iDisplayStart: $('#hid_pageNum').val(),
	    			searchKey: $('#sel_searchType a.curr').data('search'),
	    			examineState:$('#sel_examineState').val(),
				});
				return data;
			}
		},
		//定义操作列
		actions:_actions			
	};

	var jqTable=dataGrid.init(options);

	//编辑商品
	function viewProduct(){
		var id = $(this).attr('data-id');
		window.open('http://shop.vjidian.com/product/'+id,'_blank');
	}

	//编辑商品
	function editProduct(){
		var productId=$(this).data('id');
		var iDisplayLength=$('#hid_pageSize').val();
		var iDisplayStart=$('#hid_pageNum').val();
		var rowno=$(this).data('rowno');
		
		var url =productController.controllers.editView.url;
		url = url + productId+"/"+ iDisplayLength+"/"+ iDisplayStart+"/"+ rowno;
		window.location.href=url;
	}
	
	$(function() {
		//刷新数据
		$('#btn_refresh').on('click',refreshTable);
	})
	
	require(['nice-validator'], function() { 
		$.validator.config({
	        messages: {
	            length: {
	                eq: '请输入{1}个字符',
	                rg: '请输入{1}到{2}个字符',
	                gt: '请至少输入{1}个字符',
	                lt: '请最多输入{1}个字符',
	                eq_2: "",
	                rg_2: "",
	                gt_2: "",
	                lt_2: ""
	            }
	        }
	    });
		//去掉icon
		$.validator.setTheme({
			'default': {
                showOk: false
            }
	    });
	})
	
	// 点击编辑商品名称
	function editProductName(e){
		e.preventDefault();
		var nRow=$(this).parents('tr')[0];
		var aData = jqTable.fnGetData(nRow);
	    var jqTds = $('>td', nRow);
	    //防止换行
	    $(jqTds[3]).addClass('form-inline');
	    var html = [];
		html.push('<input type="text" id="list_eidt_'+aData.id+'" class="form-control input-medium"'+
				'data-rule="商品名称:required;firstletter;length[8~60, true];lastletter"'+
				'data-rule-firstletter="[/^[^0-9]/,\'请以非数字作为第一个字符！\']"'+									
				'data-rule-lastletter="[/[^ ]$/,\'请以非空格作为最后一个字符！\']"'+
				'data-tip="输入商品名称"'+
				'data-msg-length="请至少输入8个字符（1个汉字计为2个字符）"'+
				'data-msg-required="请输入商品名称!"'+
				'value="' + aData.name + '">');
		html.push('&nbsp;&nbsp;')
		var attr={"class":'update',title:"更新","data-id":aData.id};
		html.push(operateButton.getUpdateBtnEl(attr)[0].outerHTML)
		html.push('&nbsp;')
		html.push(operateButton.getCancelBtnEl()[0].outerHTML)
	    jqTds[3].innerHTML = html.join('');
	}

	//取消编辑商品名称
	function cancelEdit(e){
		e.preventDefault();
        var nRow = $(this).parents('tr')[0];
        var jqTds = $('>td', nRow);
        var aData = jqTable.fnGetData(nRow);
      	//还原表格内的内容
        jqTds[3].innerHTML=aData.name+'&nbsp;'+operateButton.getPencilEditBtnEl(aData.id,"点击编辑商品名称")[0].outerHTML;;
	}
	
    function updateProductName(e){
    	$('#form_product').trigger("validate");
    	var $this=$(this);
    	var nRow = $this.parents('tr')[0];
	    var tdInput = $('input[type=text]', nRow);
	    var jqTds = $('>td', nRow);
	   	var name=$(tdInput).val();
	    var id=$this.data("id");
	    if (tdInput.isValid() ) {
	    	product.updateName(id,name,
	    		function(msg){
	    			layer.msg(msg.status);
	     			//更新原来的aData中的数据
	     			jqTable.fnUpdate(name, nRow, 3, false);
	     			var oCheck=$('input[type=checkbox]',nRow);
	     			oCheck.uniform();
					jqTds[3].innerHTML=name+'&nbsp;'+operateButton.getPencilEditBtnEl(id,"点击编辑商品名称")[0].outerHTML;
	   			}
   			); 
	    }
	}

    //删除商品
    function deleteProduct(e){
    	e.preventDefault();
    	var id=$(this).data("id");
    	console.log(id);
    	require(['js/module/bootstrap-dialog'], function(dialog) {
 			dialog.confirm('删除商品','<i class="fa fa-exclamation-triangle"></i><span>确定要删除吗?</span>', function(result){
 				if(result) {
	            	var deleteSuccess=function(data){
	            		if(data.result){
	     					layer.msg(data.tip);
	     					refreshTable();
	     				}else{
	     					layer.msg(data.tip);
	     			 	}
    				};
    				productController.del(id,deleteSuccess);	    			
	            };
		    });
		});
    }

    //回车搜索
    function searchEnter(e){
		if(e.keyCode==13){
			//重绘表格,会在fnServerData方法里传递参数
			refreshTable();
		}
	}

    function refreshTable(){
    	jqTable.fnDraw();
	}
    
    //搜索按钮
	function searchBtn(){
		refreshTable();
	}
	
	// 批量审核通过操作
	$('#list_product_bachExamine').click(function(){
		var gsid="";
	 	var gmsl="";
	 	$(".selectRow:checked").each(function(){
		   gsid=gsid+","+$(this).val();
		   //gmsl=gmsl+","+"1";
		});
	 	
		gsid=gsid.substring(1);
		//gmsl=gmsl.substring(1);
		gmsl="审核通过";
		
		function success(data){
			if(data.result){
				layer.msg(data.tip);
				window.setInterval(function(){  
					location.href =productController.controllers.show.url;
			    },3000);
			}else{
				layer.msg(data.tip);
			}
		}	
		productController.bachExamineProductList(gsid,gmsl,1, success);
	});
	
	// 批量审核不通过操作
	$('#list_product_unbachExamine').click(function(){
		var gsid="";
	 	var gmsl="";
	 	$(".selectRow:checked").each(function(){
		   gsid=gsid+","+$(this).val();
		   //gmsl=gmsl+","+"1";
		});
	 	
		gsid=gsid.substring(1);
		//gmsl=gmsl.substring(1);
		gmsl="审核不通过";
		
		function success(data){
			if(data.result){
				layer.msg(data.tip);
				window.setInterval(function(){  
					location.href =productController.controllers.show.url;
			    },3000);
			}else{
				layer.msg(data.tip);
			}
		}	
		productController.bachExamineProductList(gsid,gmsl,3, success);
	});
});