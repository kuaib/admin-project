/**
 * 商品筛选器
 */
define([ 'jquery' ], function($) {
	"use strict";
	var root="/311/product/filter";
	//定义全部请求的Controller
	var controllers = {
		show:{url:root+'/show'},
		fuzzyMatch:{url:root+'/fuzzyMatch'},
		countList:{url:root+'/countList',data:{filterSuggestList:''}},
		countTree:{url:root+'/countTree',data:{filterSuggestTree:''}},
		save:{url:root+'/save',data:{filterSuggestTree:''}},
		find:{url:root+'/find'},
		addView:{url:root+'/addView'},
		del:{url:root+'/delete',data:{filterId:0}}
	};
	function _ajax(controller,success,error) {
		var ajaxOptions=$.extend(true,controller,{type:'POST',dataType:'JSON',success:success,error:error});
		$.ajax(ajaxOptions);
	}
	function _countList(filterSuggestList,success){
		controllers.countList.data.filterSuggestList = filterSuggestList;
		_ajax(controllers.countList,success);
	}
	function _countTree(filterSuggestTree,success){
		controllers.countTree.data.filterSuggestTree = filterSuggestTree;
		_ajax(controllers.countTree,success);
	}
	function _save(filterSuggestTree,success){
		controllers.save.data.filterSuggestTree = filterSuggestTree;
		_ajax(controllers.save,success);
	}
	function _del(filterId,success){
		controllers.del.data.filterId = filterId;
		_ajax(controllers.del,success);
	}
	return {
		controllers:controllers,
		countList:_countList,
		countTree:_countTree,
		save:_save,
		del:_del
	};
});