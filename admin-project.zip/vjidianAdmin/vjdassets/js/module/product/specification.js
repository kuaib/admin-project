define(['jquery'], function($) {
	'use strict';
	var root='https://admin.vjidian.com/8004/specification';
	//定义全部请求的Controller
	var controllers = {
		list:{url:root+'/list'},
		add:{url:root+'/add',data:{frontlabel:'',backendlabel:'',option:''}},
		update:{url:root+'/update',data:{frontlabel:'',backendlabel:'',optionid:'',option:''}},
		get:{url:root+'/get',data:{attributeid:''}},
		del:{url:root+'/delete',data:{attributeid:''}},
		deleteOption:{url:root+'/deleteOption',data:{optionid:''}}
	};
	function _ajax(controller,success,error) {
		var ajaxOptions=$.extend(true,controller,{type:'POST',dataType:'JSON',success:success,error:error});
		$.ajax(ajaxOptions);
	}
	function _get(attributeid,success,error) {
		controllers.get.data.attributeid=attributeid;
		_ajax(controllers.get,success,error);
	}
	function _add(data,success,error){
		controllers.add.data=data;
		_ajax(controllers.add,success,error);
	}
	function _update(data,success,error){
		controllers.update.data=data;
		_ajax(controllers.update,success,error);
	}
	function _del(attributeid,success,error){
		controllers.del.data.attributeid=attributeid;
		_ajax(controllers.del,success,error);
	}
	function _deleteOption(optionid,success,error){
		controllers.deleteOption.data.optionid=optionid;
		_ajax(controllers.deleteOption,success,error);
	}
	return {
		controllers:controllers,
		get:_get,
		add:_add,
		update:_update,
		del:_del,
		deleteOption:_deleteOption
	};
});