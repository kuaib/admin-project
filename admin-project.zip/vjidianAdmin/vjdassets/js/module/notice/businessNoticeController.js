define([ 'jquery' ], function($) {
	'use strict';
	var root='https://admin.vjidian.com/9105/businessNotice';
	//定义全部请求的Controller
	var controllers = {
		getPage:{url:root+'/page',type:'POST',dataType:'JSON',data:{}},
	};
	function _ajax(controller,success,error) {
		var ajaxOptions=$.extend(true,controller,{
			type:'POST',
			dataType:'JSON',
			success:success,
			error:error
		});
		$.ajax(ajaxOptions);
	}

	function _getPage(data,success,error) {
		controllers.getPage.data=data;
		_ajax(controllers.getPage,success,error);
	}

	return {
		getPage:_getPage,
		controllers:controllers,
	};
});
