define([ 'jquery' ], function($) {
	'use strict';
	var root='https://admin.vjidian.com/7010/goodsTradeStatistics';
	//定义全部请求的Controller
	var controllers = {
		show:{url:root+'/show'},
		search:{url:root+'/search',data:{}},
	};
	function _ajax(controller,success,error) {
		var ajaxOptions=$.extend(true,controller,{
			type:'POST',
			dataType:'JSON',
			success:success,
			error:error
		});
		$.ajax(ajaxOptions);
	}
	function _search(id,success,error){
		controllers.excuteJzb.data.id=id;
		_ajax(controllers.excuteJzb,success,error);
	}
	
	return {
		search:_search,
		controllers:controllers
	};
});
