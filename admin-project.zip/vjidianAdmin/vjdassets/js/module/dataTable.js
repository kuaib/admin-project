define(['jquery','DT_bootstrap'], function( $ ) {
	var ajaxParams = []; // set filter mode
	var init=function(ctl,options){	
		 options = $.extend(true, {
				//sDom控制table的布局
		    	"sDom": "<'table-scrollable't><'row'<'col-md-8 col-sm-12 pull-right'pli><'col-md-4 col-sm-12'>r>>",
				//国际化
		    	"oLanguage": {
		    		"sProcessing": '<img src="/vjdassets/img/loading-spinner-grey.gif"/><span>&nbsp;&nbsp;Loading...</span>',
					"sSearch": "搜索:",
					"sLengthMenu": "页<span class='seperator'>|</span>每页显示 _MENU_ 条,",
				    "sZeroRecords": "未查找到相关结果",
					"sInfo": "显示第  _START_ 条到第  _END_ 条记录,共  _TOTAL_ 条",
					"sInfoEmpty": "",
					"oPaginate": {
						"sPrevious": " 上一页 ",
						"sNext":     " 下一页 ",           
		                "sPage": "第",
		                "sPageOf": "页,共"
					},
					"sInfoFiltered": ""
				},
				//是否显示表格相关信息：例如翻页信息等。
				"bInfo": true,
				
				//初始化datatable，但对序号为0列的列不进行排序，别的列均可进行排序
		        "aoColumnDefs" : [ { 
			            "sClass" : "center", 
			            "aTargets" : [0] 
		        	},{ 
		            	//第一列不用排序
			            "bSortable" : false, 
			            "aTargets" : [0] }
		        ], 
		        //开关，是否显示一个每页长度的选择条（需要分页器支持）
		        "bLengthChange":true,
				//开关，以指定当正在处理数据的时候，是否显示“正在处理”这个提示信息
		        "bProcessing":true,
				//用于指定分页器风格
		        "sPaginationType": "bootstrap_extended",
				//指定按多列数据排序的依据,如[[0,'asc'], [1,'desc']]
		        //"aaSorting": [[1, 'asc']],
				//选择每页的条目数
		        "aLengthMenu": [
		            [10,20,30,40,50],
		            [10,20,30,40,50]
		        ],
		      	//用于指定一屏显示的条数，需开启分页器
		        "iDisplayLength": 10,
				//是否启用进度显示，进度条等
		        "bProcessing": true,
				//是否启用服务器处理数据源，必须sAjaxSource指明数据源位置
				"bServerSide": true,
				//是否开启列排序功能，如果想禁用某一列排序，可以在每列设置使用bSortable参数
				"bSort": true,
				
				//服务器模式的回调函数，用来处理服务器返回过来的数据
				//--------------客户端有需要的话，可以覆盖此方法-------------
				//-------------覆盖的话，模块入参successFn,errorFn事件就失效了
		        /*"fnServerData": function ( sSource, aoData, fnCallback, oSettings ) {
		        	for(var i in ajaxParams) {
                        var param = ajaxParams[i];
                        aoData.push({"name" : param.name, "value": param.value});
                    }
		        	//console.log(oSettings.oInstance.fnPagingInfo())
		        	//console.log(oSettings.oInstance.fnPagingInfo().iPage+1);
		        	
		        	//aoData[0].value=oSettings.oInstance.fnPagingInfo().iPage+1;
		        	//console.log(aoData[0].value)
		        	//console.log()
		        	oSettings.jqXHR = $.ajax({
						"dataType": 'json',
		              	"type": "POST",
		              	"url": sSource,
		             	"data": aoData,
		              	"success": function(res, textStatus, jqXHR) {
		              		//successFn(res, textStatus, jqXHR);
		              		fnCallback(res, textStatus, jqXHR);
		              		
		              		//console.log(oSettings)
		              	},
		              	"error": function(jqXHR, textStatus, errorThrown) {
		                	//出现错误时，移除进度条
		                	//console.log(jqXHR.status)
		              		//errorFn(jqXHR, textStatus, errorThrown);
							$('.dataTables_processing').remove();
		              	}
					});
				},*/
		        		
		        //ajaxURL
				//--------------客户端有需要的话，要覆盖此方法-------------
				//"sAjaxSource": "",

				//向后台传递的传递参数
				//--------------客户端有需要的话，要覆盖此方法-------------
		        "fnServerParams": function ( aoData) {
		        	
		        },

		       	//重绘table后的回调函数 
				//--------------客户端有需要的话，要覆盖此方法-------------
		     	"fnDrawCallback": function( oSettings ) {
		     		clearAjaxParams();
		    	},
		    	
		        //mData数据项，sTitle表头
		    	/*aoColumns例子，勿删，需要在外面自己定义
		        "aoColumns":[
					{"mData":"categoryId", "mRender": function ( data, type, full ) {
		          			return '<input type="checkbox" class="checker" value='+data+'" />';
						}
					},
					{"mData":"categoryId","asSorting": ["asc"]},
					{"mData":"categoryName"},
					{"mData":"available","bSortable" : false},
					{"mData":"searchable","bSortable" : false},
					{"mData":"categoryId","bSortable" : false,"mRender": function ( data, type, full ) {
							var html = []; 
							html.push('<a id="'+data+'" class="showEditForm" href="#" title="编辑"><i class="fa fa-pencil-square-o operationIcon"></i></a>');
							html.push('<a id="'+data+'" class="delete" href="#" title="删除"><i class="fa fa-trash-o operationIcon"></i></a>');
		        			return html.join(''); 
						}
					},
					{"mData":"categoryId","bSortable" : false,"mRender": function ( data, type, full ) {
							return '<span class="row-details row-details-close"></span>'
						}
					}
		 		]
		 		*/
		    }, options);
	
		//重新定义table的布局样式
		$.fn.dataTableExt.oStdClasses.sWrapper = $.fn.dataTableExt.oStdClasses.sWrapper + " dataTables_extended_wrapper";
		
		var oTable = ctl.dataTable(options);

	    //重定义下拉框样式
		$('.dataTables_length select').addClass("form-control input-xsmall input-sm");
		
		return oTable;
	}
	
	 var addAjaxParam= function(name, value) {
         ajaxParams.push({"name": name, "value": value});
     }

     var clearAjaxParams= function() {
         ajaxParams = [];
     }
	
	return {
		init:init,
		addAjaxParam:addAjaxParam,
		clearAjaxParams:clearAjaxParams
		
    };
});
