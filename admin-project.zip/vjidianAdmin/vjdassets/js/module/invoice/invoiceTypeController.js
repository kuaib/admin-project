define(['jquery'], function($) {
	"use strict";
	var root="https://admin.vjidian.com/502/invoiceType";
	//定义全部请求的Controller
	var controllers = {
		show: {url: root+'/show'},
		addView: {url: root+'/addView'},
		find: {url: root + '/find'},
		add: {url: root + '/add', data: {}},
		update: {url: root + '/update', data: {}},
		delete: {url: root + '/delete', data: {id : ''}},
		enable: {url: root + '/enable', data: {}},
		disable: {url: root + '/disable', data: {}},
		get: {url: root },
		getTagPicture: {url: root + '/getTagPicture', data: {}},
	};

	function _ajax(controller, success, error) {
		var ajaxOptions = $.extend(true, controller, {
			type: 'POST',
			dataType: 'JSON',
			success: success,
			error: error
		});
		$.ajax(ajaxOptions);
	}

	function _find(data, success, error) {
		controllers.find.data = data;
		_ajax(controllers.find, success, error);
	}

	function _add(data, success, error) {
		controllers.add.data = data;
		_ajax(controllers.add, success, error);
	}

	function _update(data, success, error) {
		controllers.update.data = data;
		_ajax(controllers.update, success, error);
	}

	function _delete(id, success, error) {
		controllers.delete.data.id = id;
		_ajax(controllers.delete, success, error);
	}

	function _enable(id, success, error) {
		console.log(id);
		controllers.enable.data.id = id;
		_ajax(controllers.enable, success, error);
	}

	function _disable(id, success, error) {
		controllers.disable.data.id = id;
		_ajax(controllers.disable, success, error);
	}
	
	function _getTagPicture(tagId, success, error) {
		controllers.getTagPicture.data.tagId = tagId;
		_ajax(controllers.getTagPicture, success, error);
	}

	return {
		controllers: controllers,
		find: _find,
		add: _add,
		update: _update,
		delete:_delete,
		enable: _enable,
		disable: _disable,
		getTagPicture: _getTagPicture
	};
});
