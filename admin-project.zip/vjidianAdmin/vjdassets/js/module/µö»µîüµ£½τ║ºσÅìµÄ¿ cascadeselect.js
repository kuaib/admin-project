
define(["jquery"],function($){
	(function ($) {
	    $.extend($.fn, {
	    	cascadeSelect: function (options) {

	            // 默认参数
	            var settings = {
	            	loadParentsUrl: "", // 数据获取url
	            	lastNodeParameter:"parentId",
	    			lastNodeId:"",
	                url: "", // 数据获取url
	                parameter: "pid", // 数据获取参数名称
	                text: "text", // 定义JSON数据格式：选择名称
	                value: "value", // 定义JSON数据格式：选择值
	                hasChildren:"children",
	                emptyOptionName: "请选择", // 选择提示,null表示无提示
	                emptyOptionValue:-1,
	                cssClass: "cascadeSelect", // 下拉框css名称
	                cssStyle: { "margin-right": "10px" }, // 下拉框左右css样式
	                selectGroupClass:"cascadeSelectGroup",
	                isFadeIn: true,// 是否渐显
	                rootId:0,
	                
	            };
	            $.extend(settings, options);
	            var $this = $(this);
	            $this.hide();
	          
	            var lastNodeId =settings.lastNodeId;
	            console.log(lastNodeId)
	            if (lastNodeId == null || lastNodeId == "") {
	            	addSelectElement($this);
                } else {
                	loadSelectElement($this);
                }

	            // 绑定Select元素
	            function bindSelectChangeEvent(element) {
	                element.bind("change", function () {
	                	addSelectElement(element);
	                    //方便取值
	                    $this.val(element.val());
	                    $this.attr("data-name",element.find('option:selected').text());
	                });
	            }

	            // 获取Json数据
	            function fillOption(element,key,selected) {
	            	element.empty();
                    if (settings.emptyOptionValue != null && settings.emptyOptionName!=null) {
                    	var option = $('<option>',{val:settings.emptyOptionValue,text:settings.emptyOptionName});
						element.append(option);
                    }
	                $.ajax({
	    	 			dataType:"json",
	    				type: "post",
	    				url:settings.url,
	    				async: false,
	    				data:settings.parameter+"="+key,
	    				success:function(data){
	    	                if (data && data.length > 0) {
	    	                    $.each(data, function (id, object) {
	    	                    	
	    	                    	var optItem={val:object[settings.value],'data-hasChild':object[settings.hasChildren],text:object[settings.text]};
	    	                    	if (selected && object[settings.value] == selected) {
	    	                    		optItem.selected=true;
	    	                    	}
	    	                        var option = $('<option>',optItem);
									element.append(option);
	    	                    });
	    	                }
	    	                else{
	    	                	element.remove();
	    	                }
	    				},
	    		 		error:function(xmlHttpRequest,data,status){
	    		 			console.log(xmlHttpRequest);
	    					console.log(data);
	    					console.log(status);
	    				}
	    			});
	            
	            }
	            function loadSelectElement(element) {
	             console.log(settings.loadParentsUrl);
            	 $.ajax({
	    	 			dataType:"json",
	    				type: "post",
	    				url:settings.loadParentsUrl,
	    				async: false,
	    				data:settings.lastNodeParameter+"="+settings.lastNodeId,
	    				success:function(map){				
	    	                if (map) {
	    	                    $.each(map, function (key, data) {           	                    	
	    	                    	var $select= $("<select>",{class:settings.cssClass+" "+settings.selectGroupClass});
	    	                    	
	    	                    	if (settings.emptyOptionValue != null && settings.emptyOptionName!=null) {
				                    	var option = $('<option>',{val:settings.emptyOptionValue,text:settings.emptyOptionName});
				                    	$select.append(option);
				                    }
	    	                    	$.each(data, function (index, value) {
	    	                    		
	    	                    		var optItem={val:value[settings.value],'data-hasChild':value.hasChild==1?true:false,text:value[settings.text]};
		    	                    	
	    	                    		if (value[settings.value] == key) {
		    	                    		optItem.selected=true;
		    	                    	}
		    	                        var option = $('<option>',optItem);
		    	                        $select.append(option);
	    	                    	})                    
									 //增加select
	    	     	                element.after($select);
	    	                    	element=$select;
	    	                    	
	    	                    	bindSelectChangeEvent($select);
	    	                    });
	    	                }
	    	               
	    				},
	    		 		error:function(xmlHttpRequest,data,status){
	    		 			console.log(xmlHttpRequest);
	    					console.log(data);
	    					console.log(status);
	    				}
	    			});
	            }
	            
	            
	            // 增加select
	            function addSelectElement(element, selected) {
	            	console.log(element);
	                var $select= $("<select>",{class:settings.cssClass+" "+settings.selectGroupClass,style:"display:none"})
	                var parentId=settings.rootId;
	                //判断是否已经存在select
	                if (element.is("select")) {
	                	//重置掉后面所有的select
	                    element.nextAll("select").remove();
	                    //点击了请选择按钮返回
	                    if (element.val() ==settings.emptyOptionValue) {
	                        return;
	                    }
	                    //如果没有子节点，返回
	                    var hasChilds = element.find('option:selected').data('haschild');
	                   
	                    if (!hasChilds){
	                    	return;
	                    } 
	                    parentId=element.val();
	                }
	                //增加select
	                element.after($select);
	                //填充数据
	                fillOption($select, parentId,selected);
	                if (settings.isFadeIn) {
	                	$select.fadeIn();
	                } else {
	                	$select.show();
	                }
	                bindSelectChangeEvent($select);
	                return $select;
	            }
	        }
	    });
	})($);
});

