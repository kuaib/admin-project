define([ 'jquery' ], function($) {
	'use strict';
	var root='https://admin.vjidian.com/6001/articlecategory';
	//定义全部请求的Controller
	var controllers = {
		findTree:{url:root+'/findTree'},
		showArticleCategory:{url:root+'/show'},
		findChildren:{url:root+'/findChildren',data:{id:0}},
		operateAdd:{url:root+'/operate/add'},
		addArticleCategory:{url:root+'/add',data:{}},
		updateArticleCategory:{url:root+'/update',data:{}},
		findPage:{url:root+'/page',data:{}},
		deleteArticleCategory:{url:root+'/delete',data:{id:0}},
		updateEnabled:{url:root+'/updateEnabled',data:{id:0}},
		updateSequence:{url:root+'/updateSequence',data:{id:0}},
		editArticleCategory:{url:root+'/operate/edit/'},
		batchUpdateSequence:{url:root+'/batchUpdateSequence',data:{ids:'',sequences:''}}
	};
	function _ajax(controller,success,error) {
		var ajaxOptions=$.extend(true,controller,{success:success,error:error,type:'POST',dataType:'JSON'});
		$.ajax(ajaxOptions);
	}
	function _findChildren(id,success,error){
		controllers.findChildren.data.id=id;
		_ajax(controllers.findChildren,success,error);
	}
	function _addArticleCategory(data,success,error){
		controllers.addArticleCategory.data='articleCategoryJSON='+JSON.stringify(data);
		_ajax(controllers.addArticleCategory,success,error);
	}
	function _updateArticleCategory(data,success,error){
		controllers.updateArticleCategory.data='articleCategoryJSON='+JSON.stringify(data);
		_ajax(controllers.updateArticleCategory,success,error);
	}
	function _findPage(data,success,error) {
		controllers.findPage.data=data;
		_ajax(controllers.findPage,success,error);
	}
	function _deleteArticleCategory(id,success,error) {
		controllers.deleteArticleCategory.data.id=id;
		_ajax(controllers.deleteArticleCategory,success,error);
	}
	
	function _updateSequence(id,success,error) {
		controllers.updateSequence.data.id=id;
		_ajax(controllers.updateSequence,success,error);
	}
	
	function _updateEnabled(id,enabled,success,error){
		controllers.updateEnabled.data.id=id;
		controllers.updateEnabled.data.enabled=enabled;
		_ajax(controllers.updateEnabled,success,error);
	}
	
	function _editArticleCategory(id){
		controllers.editArticleCategory.url +=id;
		return controllers.editArticleCategory.url;
	}
	
	function _batchUpdateSequence(ids,sequences,success,error){
		controllers.batchUpdateSequence.data.ids=ids;
		controllers.batchUpdateSequence.data.sequences=sequences;
		_ajax(controllers.batchUpdateSequence,success,error);
	}
	
	return {
		findChildren:_findChildren,
		addArticleCategory:_addArticleCategory,
		updateArticleCategory:_updateArticleCategory,
		findPage:_findPage,
		deleteArticleCategory:_deleteArticleCategory,
		updateEnabled:_updateEnabled,
		updateSequence:_updateSequence,
		editArticleCategory:_editArticleCategory,
		batchUpdateSequence:_batchUpdateSequence,
		controllers:controllers
	};
});