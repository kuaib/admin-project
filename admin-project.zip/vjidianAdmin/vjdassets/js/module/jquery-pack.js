define(['jquery'], function($) {
	'use strict';
	$.fn.serializeObject = function(){
		var o={};
		var a=this.serializeArray();
		$.each(a, function() {
			if (o[this.name]) {
				if (!o[this.name].push) {
					o[this.name]=[o[this.name]];
				}
				o[this.name].push(this.value||'');
			}else{
				o[this.name]=this.value||'';
			}
		});
		return o;
	};

	$.ajaxSetup({
		complete: function (jqXHR, status) {
			if(jqXHR.status == 403){
				$.Error(jqXHR.responseText);
			}
			if(jqXHR.status == 408){
				$.Error(jqXHR.responseText);
				setTimeout('location.href = "/login";',8000);
			}
		}
	});
});