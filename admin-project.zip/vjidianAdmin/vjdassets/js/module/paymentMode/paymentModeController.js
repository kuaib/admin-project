/**
 * 支付方式管理
 */
define(['jquery'], function($) {
	'use strict';
	var root_content = '/8007/paymentMode';
	var root = 'https://admin.vjidian.com/8007/paymentMode';
	var controllers = {
		show: {
			url: root + '/show'
		},
		showContent: {
			url: root_content + '/showContent'
		},
		find: {
			url: root + '/find'
		},
		editView: {
			url: root + '/editView/'
		},
		editContentView: {
			url: root_content + '/editContentView/'
		},
		edit: {
			url: root_content + '/edit',
			data: {}
		},
		disable: {
			url: root_content + '/disable',
			data: {
				id: 0
			}
		},
		enable: {
			url: root_content + '/enable',
			data: {
				id: 0
			}
		},
		editPoint4FreightRule: {
			url: root + '/editPoint4FreightRule',
			data: {}
		},
		editCouponsPayRule: {
			url: root + '/editCouponsPayRule',
			data: {}
		},
		editChinaPayRule: {
			url: root + '/editChinaPayRule',
			data: {}
		}
	};

	function _ajax(controller, success, error) {
		var ajaxOptions = $.extend(true, controller, {
			type: 'POST',
			dataType: 'JSON',
			success: success,
			error: error
		});
		$.ajax(ajaxOptions);
	}

	function _find(data, success, error) {
		controllers.find.data = data;
		_ajax(controllers.find, success, error);
	}

	function _edit(data, success, error) {
		controllers.edit.data = data;
		_ajax(controllers.edit, success, error);
	}

	function _enable(id, success, error) {
		controllers.enable.data.id = id;
		_ajax(controllers.enable, success, error);
	}

	function _disable(id, success, error) {
		controllers.disable.data.id = id;
		_ajax(controllers.disable, success, error);
	}

	function _editPoint4FreightRule(data, success, error) {
		controllers.editPoint4FreightRule.data = data;
		_ajax(controllers.editPoint4FreightRule, success, error);
	}

	function _editCouponsPayRule(data, success, error) {
		controllers.editCouponsPayRule.data = data;
		_ajax(controllers.editCouponsPayRule, success, error);
	}
	
	function _editChinaPayRule(data, success, error) {
		controllers.editChinaPayRule.data = data;
		_ajax(controllers.editChinaPayRule, success, error);
	}

	return {
		controllers: controllers,
		find: _find,
		edit: _edit,
		enable: _enable,
		disable: _disable,
		editPoint4FreightRule: _editPoint4FreightRule,
		editCouponsPayRule: _editCouponsPayRule,
		editChinaPayRule:_editChinaPayRule,
	};
});
