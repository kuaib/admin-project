/**
 * @class 图片类型配置
 * @method find
 */
define(['jquery'], function ($) {
	'use strict';
	var root = 'https://admin.vjidian.com/913/jobMonitor';
	var controllers = {
		find: {
			url: root + '/find'
		}
	};

	return {
		controllers:controllers
	};
});
