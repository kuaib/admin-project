define(['jquery',
	'data-grid-assemble',
	'bootstrap-cascadeselect',
	'bootstrap-select',
	'js/module/multi-select',
	'plugins/flexbox/js/jquery.flexbox',
	'css!/vjidianAdmin/vjdassets/plugins/flexbox/css/jquery.flexbox'],
	function($,dataGrid){

	/*级联下拉菜单插件
	 ****************************/
	$.fn.simpleCascade=function(url,settings){
		var cascadeSettings = {
			url: url, 
			parameter: "id", 
	        text: "name", 
	        value: "id", 
            emptyOption: "请选择", 
            cssClass: "selectpicker", 
            cssStyle: { "margin-right": "10px"}, 
            hasChildren:"isParent",
            selectGroupName:"cascadeSelectGroup",
            selectedValue:['']
		};
		if(settings.rootId){
			cascadeSettings.rootId = settings.rootId;
		};
		if(settings.maxLevel){
			cascadeSettings.maxLevel = settings.maxLevel;
		};
		if(settings.fn){
			cascadeSettings.onchange = settings.fn;
		};
		this.cascadeSelect(cascadeSettings);
	};

	/*搜索下拉菜单插件
	 ****************************/
	$.fn.searchSelect=function(url,multiple,selectedValue,param,arr){
		var $that = this;
		$that.addClass('selectpicker');
		$that.attr({"data-live-search":true});
		if(multiple=='true'){
			$that.attr('multiple','');
		}
		$.ajax({
			url:url,
			data:param,
			success:createOptions
		});
		function createOptions(data){
			var data = JSON.parse(data);
			$that.empty();
			var oPt = $('<option>',{val:-1,text:'请选择',selected:true,disabled:true});
			$that.append(oPt);
			for(var i=0;i<data.length;i++){
				var oPt=null;
				if(!arr){
					 oPt= $('<option>',{val:data[i].id,text:data[i].name,selected:false});
					if(selectedValue == data[i].id)
						oPt[0].selected = true;
				}else{
					 oPt= $('<option>',{val:data[i][arr[0]],text:data[i][arr[1]],selected:false});
					 oPt.attr('data-type',data[i][arr[2]]);
				}
				$that.append(oPt);
			}
			$that.selectpicker('refresh');
		}
	};

	/*带搜索功能的多选下拉框插件
	 ****************************/
	$.fn.searchMultipleSelect=function(url,param,selectedValue){
		var $that = this;
		$that.addClass('selectpicker');
		$that.attr({"data-live-search":true});
		$that.attr('multiple','');
		
		$.ajax({
			url:url,
			data:param,
			success:createOptions
		});
		function createOptions(data){
			var data = JSON.parse(data);   
			$that.empty();
			for(var i=0;i<data.length;i++){
				var oPt = $('<option>',{val:data[i].id,text:data[i].name,selected:false});
				//selectedValue多选操作处理
				if(selectedValue!=null){
				//var sEvl = selectedValue.length;
					for(var k in selectedValue){
						if(selectedValue[k] == data[i].id )
							oPt[0].selected = true;
					}
				}
				$that.append(oPt);
			}
			$that.selectpicker();
		}
	};

	/*多选插件
	 ****************************/
	 $.fn.fnMultiSelect=function(url,fnselect,fnDeselect){
	 	var $that = this;
	 	$that.attr({mutiple:'mutiple',name:'my-select[]'});
	 	var fnselect = fnselect || null;
	 	var fnDeselect = fnDeselect || null;
	 	function createOptions(data){
 			var data = JSON.parse(data);
 			for(var i=0;i<data.length;i++){
				var oPt = $('<option>',{val:data[i].id,text:data[i].name});
					$that.append(oPt);
			}
			$that.multiSelect({
				keepOrder:true,
				selectableHeader: '<div style="padding-top: 5px;padding-bottom: 5px;padding-right: 8px;height: 27px;text-align:center;background-color:#4b8df8;color:white;font-weight:bold;margin-top: 4px;">可选列表</div>',
	  			selectionHeader: '<div style="padding-top: 5px;padding-bottom: 5px;padding-right: 8px;height: 27px;text-align:center;background-color:#4b8df8;color:white;font-weight:bold;margin-top: 4px;">已选列表</div>',
	  			afterSelect:fnselect,
	  			afterDeselect:fnDeselect
			});
 		}
	 	if(url){
	 		$.ajax({
	 			url:url,
	 			success:createOptions
	 		});
	 	}else{
	 		$that.multiSelect({
					keepOrder:true,
					selectableHeader: '<div style="padding-top: 5px;padding-bottom: 5px;padding-right: 8px;height: 27px;text-align:center;background-color:#4b8df8;color:white;font-weight:bold;margin-top: 4px;">可选列表</div>',
		  			selectionHeader: '<div style="padding-top: 5px;padding-bottom: 5px;padding-right: 8px;height: 27px;text-align:center;background-color:#4b8df8;color:white;font-weight:bold;margin-top: 4px;">已选列表</div>',
		  			afterSelect:fnselect,
		  			afterDeselect:fnDeselect
			});
	 	}
	 }

	/*单选插件
	 ****************************/
	 $.fn.radioChange=function(){
	 	var $that = this;
	 	$that.on('click','button',function(){
	 		var $self = $(this);
	 		if (!$self.hasClass('btn-primary')){
			$self.addClass('btn-primary');
			$self.siblings().removeClass('btn-primary');
			$that.find('input').val($self.val());
		}
	 	});
	 };

	 /*右侧滑入面板
	 ****************************/
	 $.fn.showPanel=function(content,width){
	 	var $that = this;
	 	var $width = width || 300;
	 	var oPortlet = $('.portlet');
	 	var oFilter = $('<div>',{style:'background-color:rgba(0,0,0,0.1);position:absolute;width:0;overflow-y:auto;padding-bottom:5px;',class:'pnlShow'});
	 	var oContainer = $('<div>',{style:'background-color:#fff;padding:0px 2px;margin:10px 5px;text-align:center',"class":'clearfix'});
	 	oFilter.append(oContainer);
	 	//如果传了参数
		if(content){
			oContainer.append(content);
		}
		oFilter.appendTo('body');
	 	$that.on('click',function(){
	 		var filterH =$(".portlet-body").height();
	 		oFilter.css({height:filterH});
	 		oFilter.css({right:$('body').width()-oPortlet.offset().left-oPortlet.width(),top:$that.offset().top+$that.height()});
	 		if(oFilter.width()==0){
	 			$('.pnlShow').css({width:0});
				oFilter.stop().animate({width:$width}, 100);
				if(content && content.hasClass('colvis')){
					$('.colvis .btn').trigger('click');
					$('.ColVis_collectionBackground').remove();
					$('.dropdown-checkboxes').css({width:$width-10});
					$('.dropdown-checkboxes').css({left:oPortlet.offset().left+oPortlet.width()-$('.dropdown-checkboxes').width()-16});
					$('.colvis').hide();
				}else{
					$('.ColVis_catcher').trigger('click');
					$('.colvis').show();
				}
			}else if(oFilter.width()==$width){
				oFilter.stop().animate({width:'0'}, 100);
				if(content && content.hasClass('colvis')){
					$('.ColVis_catcher').trigger('click');
					$('.colvis').show();
				}
			}
	 	});
	 	return oFilter;
	 };
	 
	 /*分页下拉菜单
	  ****************************/
	 $.fn.paginationSelect = function(url,param,json){
		 var $that = this;
		 $.ajax({
			 url:url,
			 data:param,
			 success:createOptions
		 });
		 function createOptions(data){
			 var result = {};
			 var data = JSON.parse(data);

			 result.results = data;
			 $that.empty();
			 $that.flexbox(result,json);
		 }
	 }
	 /*表格控件
	  ****************************/
	$.fn.dataGrid = function(url,columns){
		var $that = this;
		var options={
			table:$that, 
			dom: 't',
			showChecked:false,
			requireColVis:false,
			//定义列
			columns:columns,
			//定义ajax请求
			ajax:{
				url:url
			}
		};
		//初始化table
		var jqTable=dataGrid.init(options);
		return jqTable;
	}
});
