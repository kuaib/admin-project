/**
   登录日志
   create:jinzhesheng
   createtime:2016/11/2
 */
define(['jquery'], function ($) {
    'use strict';
    var root = 'https://admin.vjidian.com/9104/sessionLog';
    var controllers = {
		//登录日志
        url: {url: root + '/page'},
    };
    return {
        controllers: controllers,
    };
});