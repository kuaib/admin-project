/**
   会员点击量统计
   create:jinzhesheng
   createtime:2016/11/2
 */
define(['jquery'], function ($) {
    'use strict';
    var root = 'https://admin.vjidian.com/9104/sessionLog';
    var controllers = {
        url: {url: root + '/hitsPage'},
    };
    return {
        controllers: controllers,
    };
});