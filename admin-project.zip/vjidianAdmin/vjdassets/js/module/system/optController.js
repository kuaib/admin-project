/**
   操作日志
   create:jinzhesheng
   createtime:2016/11/2
 */
define(['jquery'], function ($) {
    'use strict';
    var root = 'https://admin.vjidian.com/9108/optionLog';
    var controllers = {
		//操作日志
        url: {url: root + '/find'},
    };
    return {
        controllers: controllers,
    };
});