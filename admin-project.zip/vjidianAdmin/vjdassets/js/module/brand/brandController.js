define([ 'jquery' ], function($) {
	'use strict';
	var root='https://admin.vjidian.com/8003/brand';
	//定义全部请求的Controller
	var controllers = {
		addBrand:{url:root+'/add',type:'POST',dataType:'JSON',data:{}},
		updateBrand:{url:root+'/update',type:'POST',dataType:'JSON',data:{}},
		getPage:{url:root+'/page',type:'POST',dataType:'JSON',data:{}},
		deleteBrand:{url:root+'/delete',type:'POST',dataType:'JSON',data:{}},
		updateShowable:{url:root+'/updateShowable',type:'POST',dataType:'JSON',data:{}},
		uploadLOGO:{url:root+'/uploadLOGO'},
		edit:{url:root+'/operate/edit/'},
		show:{url:root+'/show'},
		//启用操作
		enable:{url:root+'/enable',type:'POST',dataType:'JSON',data:{}},
		//禁用用操作
		disable:{url:root+'/disable',type:'POST',dataType:'JSON',data:{}},
	};
	function _ajax(controller,success,error) {
		var ajaxOptions=$.extend(true,controller,{success:success,error:error});
		$.ajax(ajaxOptions);
	}
	function _addBrand(data,success,error){
		controllers.addBrand.data='brandJSON='+JSON.stringify(data);
		_ajax(controllers.addBrand,success,error);
	}
	function _updateBrand(data,success,error){
		controllers.updateBrand.data=data;
		_ajax(controllers.updateBrand,success,error);
	}
	function _getPage(data,success,error) {
		controllers.getPage.data=data;
		_ajax(controllers.getPage,success,error);
	}
	function _deleteBrand(id,success,error) {
		controllers.deleteBrand.data.id=id;
		_ajax(controllers.deleteBrand,success,error);
	}
	
	function _updateShowable(id,showable,success,error){
		controllers.updateShowable.data.id=id;
		controllers.updateShowable.data.showable=showable;
		_ajax(controllers.updateShowable,success,error);
	}
	
	function _disable(id,success,error) {
		controllers.disable.data.id=id;
		_ajax(controllers.disable,success,error);
	}
	function _enable(id,success,error) {
		controllers.enable.data.id=id;
		_ajax(controllers.enable,success,error);
	}
	
	return {
		addBrand:_addBrand,
		updateBrand:_updateBrand,
		getPage:_getPage,
		deleteBrand:_deleteBrand,
		updateShowable:_updateShowable,
		controllers:controllers,
		enable:_enable,
		disable:_disable,
	};
});