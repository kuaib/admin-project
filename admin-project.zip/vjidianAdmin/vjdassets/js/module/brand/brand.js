/**
 * 品牌模块 
 * @author:陈振杰
 */
define(['js/module/brand/brandController','fileinput','ueditor','maxlength','js/module/ajaxfileupload','nice-validator-zh_CN'], function(brandController) {
		
	var _initBaseForm=function(){
		var editor = UE.getEditor('ue_container',{
	    	initialFrameWidth:800,//初始化宽度
			initialFrameHeight:200,//初始化高度
			maximumWords:5000//最大字数
		});
		UE.getEditor('ue_container_en',{
	    	initialFrameWidth:800,//初始化宽度
			initialFrameHeight:200,//初始化高度
			maximumWords:10000//最大字数
		});
		
		
		$('input[maxlength]').maxlength({
		    threshold:5,
		    warningClass:'label label-info',
		    alwaysShow:true,
		    placement:'top',
		});
		
		//单选按钮切换效果
		function searchItem(){
			
			if (!$(this).hasClass('btn-primary')){
				$(this).addClass('btn-primary');
				$(this).siblings().removeClass('btn-primary');
				$('#hid_status').val($(this).val());
			}
		}
		
		$('#div_status button').on('click',searchItem);
	}

	var _add=function(){
		var brand=getbrandObj();
		var url=brandController.controllers.addBrand.url;
		submit(url,brand);
	}
	var _add2=function(){
		var brand=getbrandObj();
		var url=brandController.controllers.addBrand.url;
		submit(url,brand,'grovel');
	}
	var _update=function(){
		var brand=getbrandObj();
		brand.id = $('#brandId').val();
		
		var logoId = $("#hid_logo").val();
		//当logo不为空时传值
		if(logoId!=null && logoId!=''){
			brand.logoId= logoId;
		}
		//console.log(brand);
		var url=brandController.controllers.updateBrand.url;
		submit(url,brand);
	}
	
	function submit(url,brandObj,grovel){
		
		$.ajaxFileUpload({
        	url:url, //用于文件上传的服务器端请求地址
            secureuri: false, //是否需要安全协议，一般设置为false
            fileElementId: 'file_logo', //文件上传域的ID
            data:brandObj,
            dataType: 'json', //返回值类型 一般设置为json     
            success: function (data, status){  //服务器成功响应处理函数
            	if(data){
            		if(grovel=="grovel"){
					    if(data.result){
							$.Success(data.tip);
						}else{
							$.Warn(data.tip);
					 	}
            		}else{
            			 if(data.result){
 							$.Success(data.tip);
 							window.setInterval(function(){     
 								location.href = brandController.controllers.show.url; 
 						    },2000);
 							
 						}else{
 							$.Warn(data.tip);
 					 	}
            		}
				}
             },
             error: function (data, status, e) {//服务器响应失败处理函数
                console.log(data);
             }
        })		
	}
	
	function getbrandObj(){
		var brand={};
		brand.name=$("#txt_Name").val();
		brand.nameEN=$("#txt_NameEN").val();
		brand.alias=$("#txt_Alias").val();
		brand.company=$("#txt_company").val();
		brand.companyEN=$("#txt_companyEN").val();
		brand.url=$("#txt_Url").val();
		brand.tel=$('#txt_tel').val();
		brand.description=UE.getEditor('ue_container').getContent();
		brand.descriptionEN=UE.getEditor('ue_container_en').getContent();
		brand.status = $("#hid_status").val();
		/*brand.showable=$("#chk_showable").parent().hasClass("checked")==true?1:0;
		var seoTitle = $('#input_title').val();
		var seoMetaKeyword = $('#input_meta_keyword').val();
		var seoMetaDescription = $('#input_meta_description').val();
		var seoUrl = $('#input_url').val();
		brand.seoTitle = seoTitle;
		brand.seoMetaKeyword = seoMetaKeyword;
		brand.seoMetaDescription = seoMetaDescription;
		brand.seoUrl = seoUrl;*/
		return brand;
	}
	return {
		initBaseForm:_initBaseForm,
		add:_add,
		add2:_add2,
		update:_update,
	}
})

