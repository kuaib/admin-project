define([ 'jquery' ], function($) {
	'use strict';
	var root='https://admin.vjidian.com/8009/brandDiscount';
	
	//定义全部请求的Controller
	var controllers = {
		batchUpdateBrandSequence:{url:root+'/batchUpdateBrandSequence',data:{}},
		batchUpdateBrandDiscount:{url:root+'/batchUpdateBrandDiscount',data:{}},
		getCategoryListByParentId:{url:root+'/getCategoryListByParentId',data:{}},
		getPage:{url:root+'/page',data:{}},
	};

	function _ajax(controller,success,error) {
		var ajaxOptions=$.extend(true,controller,{
			success:success,
			error:error,
			type: 'POST',
			dataType: 'JSON'
		});
		$.ajax(ajaxOptions);
	}
	

	function _batchUpdateBrandSequence(categoryId,data,success,error){
		controllers.batchUpdateBrandSequence.data.categoryId = categoryId;
		controllers.batchUpdateBrandSequence.data.sequences = data;
		_ajax(controllers.batchUpdateBrandSequence,success,error);
	}
	function _batchUpdateBrandDiscount(categoryId,data,success,error){
		controllers.batchUpdateBrandDiscount.data.categoryId = categoryId;
		controllers.batchUpdateBrandDiscount.data.discounts = data;
		_ajax(controllers.batchUpdateBrandDiscount,success,error);
	}
	function _getCategoryListByParentId(parentId,success,error){
		controllers.getCategoryListByParentId.data.id = parentId;
		_ajax(controllers.getCategoryListByParentId,success,error);
	}
	function _getBrandListPage(data,success,error){
		controllers.getBrandListPage.data = data;
		_ajax(controllers.getBrandListPage,success,error);
	}
	
	return {
		controllers:controllers,
		batchUpdateBrandSequence:_batchUpdateBrandSequence,
		batchUpdateBrandDiscount:_batchUpdateBrandDiscount,
		getCategoryListByParentId:_getCategoryListByParentId,
		getBrandListPage:_getBrandListPage,
	};
});