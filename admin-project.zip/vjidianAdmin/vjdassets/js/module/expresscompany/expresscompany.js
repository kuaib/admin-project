/**
 * 
 */
define(['js/module/expresscompany/expresscompanyController','nice-validator-zh_CN'], function(expresscompanyController) {
	
	function getExpresscompanyObj(){
		var expresscompanyObj = $('#frm_expresscompany').serializeObject();
		return expresscompanyObj;
	}
	
	
	var _add=function(){
		var expresscompany=getExpresscompanyObj();
		var submitSuccess=function(data){
		    if(data.result){
				$.Success(data.tip);
				window.setInterval(function(){     
					location.href = expresscompanyController.controllers.show.url; 
			    },2000);
				
			}else{
				$.Warn(data.tip);
		 	}
		};
		//提交表单
		expresscompanyController.add(expresscompany,submitSuccess);
	}
	
	var _update=function(){
		var expresscompany=getExpresscompanyObj();
		expresscompany.id=$("#txt_expresscompanyId").val();
		var submitSuccess=function(data){
		    if(data.result){
				$.Success(data.tip);
				window.setInterval(function(){     
					location.href = expresscompanyController.controllers.show.url; 
			    },2000);
				
			}else{
				$.Warn(data.tip);
		 	}
		};
		//提交表单
		expresscompanyController.update(expresscompany,submitSuccess);
	}
	
	return {
		add:_add,
		update:_update,
	}
})