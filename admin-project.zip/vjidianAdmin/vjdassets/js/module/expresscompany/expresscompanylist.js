/**
 * 商品列表模块 
 * @author:陈振杰
 */
define(['js/module/expresscompany/expresscompanyController','data-grid-assemble','js/module/pageControls'], function(expresscompanyController,dataGrid) {
	
	//datatable配置
	var options={
		table:$('#tbl_expresscompany'),
		deferRender: true,
		showChecked:false,
		dom:'t',
		//定义列
		columns:[ 
 			{title:"公司名称",data:"name",order: ["desc"],width:"20%",className:"text-left",orderable:false },
 			{title:"公司代码",data:"code",width:"20%",orderable : false,orderable:false},
 			{title:"公司网址",data:"url",width:"20%",orderable : false,orderable:false},
			{title:"询件网址",data:"queryURL",order: ["desc"],width:"20%",className:"text-left",orderable:false,defaultContent:""},
			{title:'启用状态',data:'status',orderable : false,className:'text-center',defaultContent:'',render:function(data,type,row,meta){
					var oIcon = $('<i>');
					if(row.status == 1){
						oIcon.addClass('fa fa-check-circle');
					}else if( row.status == 2 ){
						oIcon.addClass('fa fa-times-circle');
					}
					oIcon.css({color:'#2a6496'});
					return oIcon[0].outerHTML;
			}},
			{title:"显示顺序",data:"sequence",width:"10%",className:"text-left" ,orderable:false},
		],
		ajax:{
		 	url:expresscompanyController.controllers.getPage.url,
		 	data:function(d){
				var data = $.extend({}, d, {
	    			searchContent: $.trim($('#txt_searchContent').val()),
	    			iDisplayLength: $('#hid_pageSize').val(),
	    			iDisplayStart: $('#hid_pageNum').val(),
	    			searchKey: $('#sel_searchType a.curr').data('search'),
				});
				return data;
			}
		},
		//定义操作列
		actions:{
			edit:{
				className:null,
				tip:'',
				fn:edit
			},
			enabled:{
					className:'fa fa-stop operationIcon',
					tip:'禁用',
					fn:enabledExpressCompany,
					visible:function(cell,type,row,meta){
						if(row.status==1){
							return true;	
						}else{
							return false;
						}
					}
				},
			disabled:{
				className:'fa fa-play operationIcon',
				tip:'启用',
				fn:enabledExpressCompany,
				visible:function(cell,type,row,meta){
					if(row.status==1){
						return false;
					}else{
						return true;
					}
				}
			},
			delete:{
				className:null,
				tip:'删除',
				fn:deleteExpresscompany
			},
		},
	};

	//编辑
	function edit(){
		var url =expresscompanyController.controllers.edit.url;
		window.location.href=url+$(this).data('id');
	}
	
	//初始化table
	var jqTable=dataGrid.init(options);
	
	//$(function() {
		//刷新数据
		//$('#btn_refresh').on('click',refreshTable);
	//})
	
	require(['nice-validator'], function() { 
		$.validator.config({
	        messages: {
	            length: {
	                eq: '请输入{1}个字符',
	                rg: '请输入{1}到{2}个字符',
	                gt: '请至少输入{1}个字符',
	                lt: '请最多输入{1}个字符',
	                eq_2: "",
	                rg_2: "",
	                gt_2: "",
	                lt_2: ""
	            }
	        }
	    });
		//去掉icon
		$.validator.setTheme({
			'default': {
                showOk: false
            }
	    });
	})
	
    //删除
    function deleteExpresscompany(e){
    	e.preventDefault();
    	var id=$(this).data("id");
    	require(['js/module/bootstrap-dialog'], function(dialog) {
 			dialog.confirm('删除物流公司信息','<i class="fa fa-exclamation-triangle"></i><span>确定要删除吗?</span>', function(result){
 				if(result) {
	            	var deleteSuccess=function(data){
	            		if(data.result){
	     					$.Success(data.tip);
	     					refreshTable();
	     				}else{
	     					$.Warn(data.tip);
	     			 	}
    				};
    				expresscompanyController.del(id,deleteSuccess);	    			
	            };
		    });
		});
    }


    //回车搜索
    function searchEnter(e){
		if(e.keyCode==13){
			//重绘表格,会在fnServerData方法里传递参数
			refreshTable();
		}
	}

    function refreshTable(){
    	jqTable.fnDraw();
	}
    
    //搜索按钮
	function searchBtn(){
		refreshTable();
	}

	//启用禁用
	function enabledExpressCompany(e){
		e.preventDefault();
		var id=$(this).attr('data-id');
		var isEnabled = jqTable.fnGetData($(this).parents('tr')).status;
		var confirmTitle = isEnabled == 1 ? '禁用物流公司' :'启用物流公司';
		var confirmContent = isEnabled == 1 ? '确定要禁用物流公司吗？':'确定要启用物流公司吗？' ;
		require(['js/module/bootstrap-dialog'], function(dialog) {
			dialog.confirm(confirmTitle,'<i class="fa fa-exclamation-triangle"></i><span>'+confirmContent+'</span>', function(result){
			       if(result) {
		 	          expresscompanyController.changeStatus(id,isEnabled,$.Complete);
	    			}
			       jqTable.fnDraw();
		 	});
		 });
		
	}
	
})