define([ 'jquery' ], function($) {
	'use strict';
	var root='https://admin.vjidian.com/9002/guide';
	//定义全部请求的Controller
	var controllers = {
		//增加Controller
		addGuide:{url:root+'/add',type:'POST',dataType:'JSON',data:{}},
		addView:{url:root+'/addView/'},
		//更新Controller
		updateGuide:{url:root+'/update',type:'POST',dataType:'JSON',data:{}},
		//editView
		showEdit:{url:root+'/editView/'},
		//删除
		deleteGuide:{url:root+'/delete',type:'POST',data:{}},
		show:{url:root+'/show',},
		getPage:{url:root+'/find',type:'POST',dataType:'JSON',data:{}},
		//根据父亲Id查询子区域
		getChilden:{url:root+'/getChildren',type:'POST',dataType:'JSON',data:{}},
		//启用
		enable:{url:root+'/enable',type:'POST',dataType:'JSON',data:{}},
		//禁用
		disable:{url:root+'/disable',type:'POST',dataType:'JSON',data:{}},

		getEnableChilren:{url:root+'/getEnableChildren',type:'POST',dataType:'JSON',data:{}},
		//getCategory
		getCategory:{url:root+'/getCategory',type:'POST',dataType:'JSON',data:{}},
		
		getVirtualCategory:{url:root+'/getVirtualCategory',type:'POST',dataType:'JSON',data:{}},
	};
	function _ajax(controller,success,error) {
		var ajaxOptions=$.extend(true,controller,{success:success,error:error});
		$.ajax(ajaxOptions);
	}
	function _addGuide(data,success,error){
		controllers.addGuide.data=data;
		_ajax(controllers.addGuide,success,error);
	};
	function _updateGuide(data,success,error){
		controllers.updateGuide.data=data;
		_ajax(controllers.updateGuide,success,error);
	};
	function _deleteGuide(id,success,error) {
		controllers.deleteGuide.data.id=id;
		_ajax(controllers.deleteGuide,success,error);
	};
	
	function _getPage(data,success,error) {
		controllers.getPage.data=data;
		_ajax(controllers.getPage,success,error);
	};
	function _getChilden(id,success,error) {
		controllers.getChilden.data.id=id;
		_ajax(controllers.getChilden,success,error);
	};
	function _enable(data,success,error) {
		controllers.enable.data.id=data;
		_ajax(controllers.enable,success,error);
	}
	function _disable(data,success,error) {
		controllers.disable.data.id=data;
		_ajax(controllers.disable,success,error);
	}
	//getEnableChilren
	function _getEnableChilren(data,success,error) {
		controllers.getEnableChilren.data=data;
		_ajax(controllers.getEnableChilren,success,error);
	}

	//updateStatus
	return {
		controllers:controllers,
		addGuide:_addGuide,
		updateGuide:_updateGuide,
		deleteGuide:_deleteGuide,
		getPage:_getPage,
		getChilden:_getChilden,
		enable:_enable,
		disable:_disable,
		getEnableChilren:_getEnableChilren,
	};
});
