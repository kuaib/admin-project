define([ 'jquery' ], function($) {
	'use strict';
	var root='https://admin.vjidian.com/4006/jzb';
	//定义全部请求的Controller
	var controllers = {
		show:{url:root+'/show'},
		find:{url:root+'/find',data:{}},
		excuteJzb:{url:root+'/excuteJzb',data:{}}
	};
	function _ajax(controller,success,error) {
		var ajaxOptions=$.extend(true,controller,{
			type:'POST',
			dataType:'JSON',
			success:success,
			error:error
		});
		$.ajax(ajaxOptions);
	}
	function _excuteJzb(id,success,error){
		controllers.excuteJzb.data.id=id;
		_ajax(controllers.excuteJzb,success,error);
	}
	
	return {
		excuteJzb:_excuteJzb,
		controllers:controllers
	};
});
