define(['js/module/order/orderController',
	'data-grid-assemble',
	'js/module/bootstrap-dialog',
	'js/module/datepicker',
	'nice-validator-zh_CN'], 
	function(orderController,dataGrid,dialog,datepicker) {
	
	var options={
		table:$('#tbl_order'),
		deferRender:true,
		showChecked:true,
		dom:'t',
		columns:[
 			{title:"订单编号",data:"orderNumber",order: ["desc"],width:"10%",className:"text-left",orderable:false },
 			{title:"订单状态",data:"orderStatusName",width:"5%",orderable : false,orderable:false },
 			{title:"支付方式",data:"orderPayableVO.paymentTypeName",order: ["desc"],width:"8%",className:"text-left",orderable:false,defaultContent:""},
			{title:"支付状态",data:"orderPayableVO.paymentStatusName",order: ["desc"],width:"5%",className:"text-left",orderable:false,defaultContent:""},
			{title:"服务状态",data:"serviceStatusName",width:"5%",className:"text-left" ,orderable:false},
			{title:"应付总额(元)",data:"orderPayableVO.payableAmount",width:"10%",orderable : false,orderable:false},
			{title:"会员",data:"memberInfo.loginName",width:"10%",className:"text-left" ,orderable:false},
			{title:"收货人",data:"orderDeliveryInfo.receiverName",width:"10%",className:"text-left" ,orderable:false},
			{title:"手机号",data:"orderDeliveryInfo.receiverMobile",width:"10%",className:"text-left" ,orderable:false},
			{title:"下单时间",data:"orderCreateTimeStr",width:"10%",className:"text-left" ,orderable:false}
		],
		ajax:{
		 	url:orderController.controllers.find.url,
		 	data:function(d){
				var data = $.extend({}, d, {
	    			searchContent: $.trim($('#txt_searchContent').val()),
	    			iDisplayLength: $('#hid_pageSize').val(),
	    			iDisplayStart: $('#hid_pageNum').val(),
	    			searchKey: $('#sel_searchType a.curr').data('search'),
	    			state:$('#hid_orderState').val(),
				});
				
				var subsiteId=$('#search_siteId').val();
				if(subsiteId){
					data.subsiteId=subsiteId;
				}
				
				var orderNumber=$('#search_orderNumber').val();
				if(orderNumber){
					data.orderNumber=orderNumber;
				}
				
				var loginName=$('#search_loginName').val();
				if(loginName){
					data.loginName=loginName;
				}
				
				var mobile=$('#search_mobile').val();
				if(mobile){
					data.mobile=mobile;
				}
			
				var orderStatus=$('#search_orderStatus').val();
				if(orderStatus){
					data.orderStatus=orderStatus;
				}
				expressNumber=$('#search_expressNumber').val();
				if(expressNumber){
					data.expressNumber=expressNumber
				}
				
				startPayableAmount=$('#search_startPayableAmount').val();
				if(startPayableAmount){
					data.startPayableAmount=startPayableAmount
				}
				
				endPayableAmount=$('#search_endPayableAmount').val();
				if(endPayableAmount){
					data.endPayableAmount=endPayableAmount
				}
				
				startOrderCreateTime=$('#search_startOrderCreateTime').val();
				if(startOrderCreateTime){
					data.startOrderCreateTime=startOrderCreateTime
				}
				
				endOrderCreateTime=$('#search_endOrderCreateTime').val();
				if(endOrderCreateTime){
					data.endOrderCreateTime=endOrderCreateTime
				}
				
				paymentType=$('#search_paymentType').val();
				if(paymentType){
					data.paymentType=paymentType
				}
				
				paymentStatus=$('#search_paymentStatus').val();
				if(paymentStatus){
					data.paymentStatus=paymentStatus
				}
				
				deliveryModeId=$('#search_deliveryModeId').val();
				if(deliveryModeId){
					data.deliveryModeId=deliveryModeId
				}
				
				isInvoice=$('#search_isInvoice').val();
				if(isInvoice){
					data.isInvoice=isInvoice
				}
				
	
				return data;
			}
		},
		//定义操作列
		actions:{
			show:{
				fn:ui_showPermission
			}//,
			//view:{
			//	fn:ui_viewDetail
			//},
		},
	};
	
	//初始化table
	var jqTable=dataGrid.init(options);
	//初始化日期控件
	datepicker.init('+0d');

	// 查看订单详情
	function ui_viewDetail(){
		location.href=orderController.controllers.viewDetail.url + $(this).attr('data-id');
	}

	// 操作项展开和收起
	function ui_showPermission(){
		var $that = $(this);
		var row = $that.parents('tr')[0];
		var orderId = $that.data('id');
		var button = $that.parents('tr').find('i')[0];
		if(jqTable.fnIsOpen(row)){//已展开
			jqTable.fnClose(row);
			button.className = 'fa fa-chevron-down operationIcon';
		}else{
			//收起已经展开的行
			$('#tbl_order .detail').parents('tr').each(function(index,el){
				var _row = $(this).prev();
				_row.find('.fa-chevron-up')[0].className = "fa fa-chevron-down operationIcon";
				jqTable.fnClose(_row[0]);
			});
			var data=jqTable.fnGetData(row);
			var permissions=data.permissionList;
			var $container =$('<div>',{class:'detail'});
			var $ul=$('<ul>',{class:'nav nav-tabs'});
			if(permissions.length>0){
				for(var i=0;i<permissions.length;i++){
					var $li=$('<li>')
					var operateAttr;
					if(permissions[i].code=='detail'){
						 operateAttr={
						 	title:permissions[i].name,
						 	href:orderController.controllers.viewDetail.url + data.id,
						 	text:permissions[i].name};
					}else if(permissions[i].code=='confirmCancel' || permissions[i].code=='abortCancel'){
						continue;
					}else if(permissions[i].code=='cancel'){
						var superCancel = $('#hid_superCancel').val();
						if(superCancel == true || superCancel == 'true'){
							operateAttr={class:'operation',
							 title:permissions[i].name,
							 'data-toggle':'modal',
							 'data-target':'#pnl_'+permissions[i].code,
							 text:permissions[i].name};
						}else{
							continue;
						}
					}else if(permissions[i].code=='forcePay'){
						var superForcePay = $('#hid_forcePay').val();
						if(superForcePay == true || superForcePay == 'true'){
							operateAttr={class:'operation',
							 title:permissions[i].name,
							 'data-toggle':'modal',
							 'data-target':'#pnl_'+permissions[i].code,
							 text:permissions[i].name};
						}else{
							continue;
						}
					}else{
						 operateAttr={class:'operation',
						 title:permissions[i].name,
						 'data-toggle':'modal',
						 'data-target':'#pnl_'+permissions[i].code,
						 text:permissions[i].name};
					}
					var $a=$('<a>',operateAttr);
					$ul.append($li.append($a));
				}
			}
			$container.append($ul);
			jqTable.fnOpen(row, $container);
			button.className = 'fa fa-chevron-up operationIcon';
		}
	}
	
	
	var showOperationPanel=function(){
		var $this=$(this);
		var targetPanel=$this.data('target');
		var row = $this.parents('tr').prev('tr')[0];
		var orderDetail=jqTable.fnGetData(row);
		loadOrderDetailPanel(orderDetail,$(targetPanel));
	}

	
	
	//初始化订单明细表单
	function loadOrderDetailPanel(orderDetail,operationPanel){
		
		//重置表单
		$('form',operationPanel)[0].reset();
		//重置radio
		$('input[type=radio]',operationPanel).parent().removeClass('checked');
		
		//订单信息
		if(typeof(orderDetail)!='undefined'){
			
			var operationId=operationPanel[0].id;
			
			//通用属性
			$('#hid_orderId',operationPanel).val(orderDetail.id);
			//订单编号
			$('label[name=orderNumber]',operationPanel).text(orderDetail.orderNumber);
			//订单状态
			$('label[name=orderStatusName]',operationPanel).text(orderDetail.orderStatusName);
			//客服备注
			$('textarea[name=orderRemark]',operationPanel).text(orderDetail.orderRemark);
			//买家备注
			$('label[name=remark]',operationPanel).text(orderDetail.remark);
			//支付方式
			$('label[name=paymentModeTypeName]',operationPanel).text(orderDetail.orderPayableVO.paymentTypeName);	
			
			loadRemarkModal(orderDetail,operationPanel);
			
			loadUpdateInvocieModal(orderDetail,operationPanel);
		
			if(operationId=='pnl_updateAddress'){
				loadUpdateAddressModal(orderDetail,operationPanel);
			}
			
			loadReviewOrderModal(orderDetail,operationPanel);
			
			loadCancelModal(orderDetail,operationPanel);			
		}
	}
	
	//加载客服备注
	var loadRemarkModal=function(orderDetail,operationPanel){
		//备注历史
		$('tbody',$('#tbl_remarkHistory')).empty();
		$.each(orderDetail.remarks, function (id, value) {
			var $tr=$('<tr>'); 
			var $td_remark=$('<td>',{'class':'text-center'}).append(value.remark);
			var $td_tagImg;
			$('input[name=remarkTag]',operationPanel).each(function(){
				if(value.tag==$(this).val()){
					$td_tagImg=$('<img>',{src:$(this).data('src')});
				}
			})
			var $td_tag=$('<td>',{'class':'text-center'}).append($td_tagImg);
			var $td_createTime=$('<td>',{'class':'text-center'}).append(value.createTimeStr);
			var $td_createUser=$('<td>',{'class':'text-center'}).append(value.createUserStr);
			$tr.append($td_remark).append($td_tag).append($td_createTime).append($td_createUser);
			$('tbody',$('#tbl_remarkHistory')).append($tr);
		})
	}
	
	//加载修改发票窗口
	var loadUpdateInvocieModal=function(orderDetail,operationPanel){
		//是否需要发票
		$("input[name='needInvoice'][value="+orderDetail.invoiceStatus+"]",operationPanel).parent().addClass('checked');
		//发票类型
		$("#sel_invoiceTitleType",operationPanel).val(orderDetail.orderInvoiceVO.titleType);
		//发票抬头
		$("input[name='invoiceTitle']",operationPanel).val(orderDetail.orderInvoiceVO.title);
		//发票编码
		$("input[name='invoiceCode']",operationPanel).val(orderDetail.orderInvoiceVO.code);
		
	}
	
	//加载订单复合窗口
	var loadReviewOrderModal=function(orderDetail,operationPanel){
		$("label[name='checkStatusName']",operationPanel).text(orderDetail.checkStatusName);
	}
	
	//加载确认取消窗口
	var loadCancelModal=function(orderDetail,operationPanel){
		//取消原因
		if(orderDetail.orderCancelVO!=null){
			$("label[name=cancelReason]",operationPanel).text(orderDetail.orderCancelVO.reason);
		}
	}
	
	//订单配送
	var deliverOrder=function(){
		var $deliverPanel=$('#pnl_deliver');
		var orderId=$("#hid_orderId",$deliverPanel).val();
		var expressCompanyId=$("#sel_expressCompany",$deliverPanel).val();
		var expressNumber=$("#txt_expressNumber",$deliverPanel).val();
		var orderRemark=$("#txt_orderRemark",$deliverPanel).val();
		var submitSuccess=function(data){
		    if(data.result){
				$.Success(data.tip);
				$deliverPanel.modal('hide');
				jqTable.fnDraw();
			}else{
				$.Warn(data.tip);
		 	}
		};
		orderController.deliver(orderId, expressCompanyId, expressNumber, submitSuccess);
	}
	
	//订单复合
	var reviewOrder=function(){
		var $reviewPanel=$('#pnl_review');
		var orderId=$("#hid_orderId",$reviewPanel).val();
		var orderRemark=$("#txt_orderRemark",$reviewPanel).val();
		
		var submitSuccess=function(data){
		    if(data.result){
				$.Success(data.tip);   
				$reviewPanel.modal('hide');
				jqTable.fnDraw();
			}else{
				$.Warn(data.tip);
		 	}
		};
		orderController.review(orderId, orderRemark, submitSuccess);
	}
	
	//关闭订单
	var closeOrder=function(){
		var $closePanel=$('#pnl_close');
		var orderId=$("#hid_orderId",$closePanel).val();
		var cancelReasonId=$("#sel_closeReason").val();
		var remark=$("#txt_orderRemark",$closePanel).val();

		var submitSuccess=function(data){
		    if(data.result){
				$.Success(data.tip);   
				$closePanel.modal('hide');
				jqTable.fnDraw();
			}else{
				$.Warn(data.tip);
		 	}
		};
		orderController.close(orderId,cancelReasonId,remark, submitSuccess);
	}
	
	//订单备注
	var remarkOrder=function(){
		var $remarkPanel=$('#pnl_remark');
		var orderId=$("#hid_orderId",$remarkPanel).val();
		var orderRemark=$("#txt_orderRemark",$remarkPanel).val();
		var tag=null;
		$("input[name='remarkTag']",$remarkPanel).each(function(){
			var $radio=$(this);
			if($radio.parent().hasClass('checked')){
				tag=$radio.val();
			}
		})
		var submitSuccess=function(data){
		    if(data.result){
				$.Success(data.tip);
				$remarkPanel.modal('hide');
				jqTable.fnDraw();
			}else{
				$.Warn(data.tip);
		 	}
		};
		orderController.updateRemark(orderId, orderRemark,tag,submitSuccess);
	}
	
	//确认取消订单
	var confirmCancelOrder=function(){
		var $pnl_confirmCancel=$('#pnl_confirmCancel');
		var orderId=$("#hid_orderId",$pnl_confirmCancel).val();
		var orderRemark=$("#txt_orderRemark",$pnl_confirmCancel).val();
		var submitSuccess=function(data){
		    if(data.result){
				$.Success(data.tip);   
				$pnl_confirmCancel.modal('hide');
				jqTable.fnDraw();
			}else{
				$.Warn(data.tip);
		 	}
		};
		orderController.confirmCancel(orderId,orderRemark, submitSuccess);
	}
	
	//放弃取消
	// var abortCanel=function(){
	// 	var $cancelApplyPanel=$('#pnl_cancelApply');
	// 	var orderId=$("#hid_orderId",$cancelApplyPanel).val();
	// 	var orderRemark=$("#txt_orderRemark",$cancelApplyPanel).val();
	// 	var serviceMessage="";
		
	// 	var submitSuccess=function(data){
	// 	    if(data.result){
	// 			$.Success(data.tip);
	// 			$cancelApplyPanel.modal('hide');
	// 			jqTable.fnDraw();
	// 		}else{
	// 			$.Warn(data.tip);
	// 	 	}
	// 	};
	// 	orderController.abortCancel(orderId,serviceMessage,orderRemark, submitSuccess);
	// }
	
	//修改应付
	var updatePayableAmountOrder=function(){
		var $updatePaymentPanel=$('#pnl_updatePayment');
		var orderId=$("#hid_orderId",$updatePaymentPanel).val();
		var orderRemark=$("#txt_orderRemark",$updatePaymentPanel).val();
		var tuningAmount=$("#txt_tuningAmount",$updatePaymentPanel).val();
		
		var submitSuccess=function(data){
		    if(data.result){
				$.Success(data.tip);  
				$updatePaymentPanel.modal('hide');
				jqTable.fnDraw();
			}else{
				$.Warn(data.tip);
		 	}
		};
		orderController.updatePayableAmount(orderId,tuningAmount,orderRemark, submitSuccess);
	}
	
	//修改发票
	var updateInvocie=function(){
		var $updateInvociePanel=$('#pnl_updateInvocie');
		var orderId=$("#hid_orderId",$updateInvociePanel).val();
		var needInvoice;
		//是否需要发票
		$("input[name='needInvoice']",$updateInvociePanel).each(function(){
			if($(this).parent().hasClass('checked')){
				needInvoice=$(this).val()
			}
		})
		var invoiceTitleType=$("#sel_invoiceTitleType").val();
		var invoiceTitle=$("input[name='invoiceTitle']",$updateInvociePanel).val();
		var invoiceCode=$("input[name='invoiceCode']",$updateInvociePanel).val();
		var submitSuccess=function(data){
		    if(data.result){
				$.Success(data.tip);  
				$updateInvociePanel.modal('hide');
				jqTable.fnDraw();
			}else{
				$.Warn(data.tip);
		 	}
		};
		orderController.updateInvocie(orderId,needInvoice,invoiceTitleType,invoiceTitle,invoiceCode, submitSuccess);
	}
	
	//加入黑名单
	var addBlackList=function(){
		var $blackListPanel=$('#pnl_addBlackList');
		
		var $memberIdChk=$("input[name='chkLoginName']",$blackListPanel);
		var memberId=$memberIdChk.val();
		
		var loginName="";
		if($memberIdChk.parent().hasClass('checked')){
			loginName=$("label[name='loginName']",$blackListPanel).text();
		}
		
		var receiveName="";
		var $receiveNameChk=$("input[name='chkReceiverName']",$blackListPanel);
		if($receiveNameChk.parent().hasClass('checked')){
			receiveName=$receiveNameChk.val();
		}
		
		var mobile="";
		var $chkReceiverMobile=$("input[name='chkReceiverMobile']",$blackListPanel);
		if($chkReceiverMobile.parent().hasClass('checked')){
			mobile=$chkReceiverMobile.val();
		}

//		var regionId=0;
		var receiverAddress="";
		var $chkReceiverAddress=$("input[name='chkReceiverAddress']",$blackListPanel);
		if($chkReceiverAddress.parent().hasClass('checked')){
//			regionId=$chkReceiverAddress.attr("regionid");
//			receiverAddress=$chkReceiverAddress.attr("receiveraddress");
//			receiverAddress=$("input[name='receiverAddress'").val();
			var road=$("input[name='receiverAddress_road']",$blackListPanel).val();
			var community=$("input[name='receiverAddress_community']",$blackListPanel).val();
			var buildingNo=$("input[name='receiverAddress_buildingNo']",$blackListPanel).val();
			var room=$("input[name='receiverAddress_room']",$blackListPanel).val();
			var receiverAddress=road+"%$"+community+"%$"+buildingNo+"%$"+room;
		}
		
		var regionId=0;
		var $chkReceiverRegion=$("input[name='chkReceiverRegion']",$blackListPanel);
		if($chkReceiverRegion.parent().hasClass('checked')){
//			regionId=$chkReceiverAddress.attr("regionid");
//			receiverAddress=$chkReceiverAddress.attr("receiveraddress");
//			$("#regionId").nextAll("select").remove();
			regionId=$("#regionId").val();
		}
		
		
		var ip="";
		var $chkRegIP=$("input[name='chkRegIP']",$blackListPanel);
		if($chkRegIP.parent().hasClass('checked')){
			ip=$chkRegIP.val();
		}
		
		var remark=$("#txt_orderRemark",$blackListPanel).val();
		
		var submitSuccess=function(data){
		    if(data.result){
				$.Success(data.tip);  
				$blackListPanel.modal('hide');
				jqTable.fnDraw();
			}else{
				$.Warn(data.tip);
		 	}
		};
		function isEmptyStr(strVal){
			strVal = $.trim(strVal);
			if(strVal == '' || strVal == null || strVal == undefined){
				return true;
			}else{
				return false;
			}
		}
//		console.log(memberId);
//		console.log(loginName);
//		console.log(receiveName);
//		console.log(mobile);
//		console.log(regionId);
//		console.log(receiverAddress);
//		console.log(ip);
//		console.log(remark);

		if(isEmptyStr(loginName)&&isEmptyStr(receiveName)&&isEmptyStr(mobile)&&(isEmptyStr(regionId)||isEmptyStr(receiverAddress))&&isEmptyStr(ip)){
//			dialog.alert("请至少勾选一项");
			$.Warn("请至少勾选一项");
		}else if(isEmptyStr(remark)){
//			dialog.alert("备注不能为空");
			$.Warn("备注不能为空");
		}else{
			memberId=-1;
			orderController.addBlackList(memberId,loginName,receiveName,mobile,regionId,receiverAddress,ip,remark, submitSuccess);
		}
		
		
//		orderController.addBlackList(memberId,loginName,receiveName,mobile,regionId,receiverAddress,ip,remark, submitSuccess);
	}
	
	
	//修改地址
	var updateAddress=function(){
		
		$('#txt_address').nextAll('select').remove();
		
		var $updateAddressPanel=$('#pnl_updateAddress');
		var orderId=$('#hid_orderId',$updateAddressPanel).val();
		var orderDeliveryId=$('#hid_orderDeliveryId',$updateAddressPanel).val();
		var receiverName=$('input[name=receiverName]',$updateAddressPanel).val();
		var receiverMobile=$('input[name=receiverMobile]',$updateAddressPanel).val();
		var receiverPhone=$('input[name=receiverPhone]',$updateAddressPanel).val();
		var receiverPostCode=$('input[name=receiverPostCode]',$updateAddressPanel).val();
		var regionId=$('#txt_address',$updateAddressPanel).val();
		
		var road=$('input[name=receiverAddress_road]',$updateAddressPanel).val();
		var receiverAddress=road;
		
		var email=$('input[name=email]',$updateAddressPanel).val();
	
		var submitSuccess=function(data){
		    if(data.result){
				$.Success(data.tip);  
				$updateAddressPanel.modal('hide');
				jqTable.fnDraw();
			}else{
				$.Warn(data.tip);
		 	}
		};
		orderController.updateAddress(orderDeliveryId,orderId, receiverName, receiverMobile, receiverPhone, regionId, receiverAddress, email,receiverPostCode, submitSuccess);
	}
	
	//订单复核事件
	$('button[name=submit]',$('#pnl_review')).bind('click',reviewOrder);
	
	//订单发货事件
	$('button[name=submit]',$('#pnl_deliver')).bind('click',deliverOrder);
	
	//订单关闭
	$('button[name=submit]',$('#pnl_close')).bind('click',closeOrder);
	
	//订单备注
	$('button[name=submit]',$('#pnl_remark')).bind('click',remarkOrder);

	//修改应付
	$('button[name=submit]',$('#pnl_updatePayment')).bind('click',updatePayableAmountOrder);
	
	//修改发票
	$('button[name=submit]',$('#pnl_updateInvocie')).bind('click',updateInvocie);
	
	//加入黑名单
	//$("button[name='submit']",$('#pnl_addBlackList')).bind('click',addBlackList);
	
	//修改配送地址
	$('button[name=submit]',$('#pnl_updateAddress')).bind('click',updateAddress);
	
	
	//展开订单操作事件
	$('tbody',jqTable).on('click','a.operation',showOperationPanel);
	

	//tab标签状态切换事件
	$('a[data-toggle=tab]',$('#nav-tabs')).click(function(){
		var state=$(this).data('state');
		$('#hid_orderState').val(state);
		$('#hid_pageNum').val(1);
		jqTable.fnDraw();
		if(state == 4){
			$('#btn_batchDeliver').show();
		}else{
			$('#btn_batchDeliver').hide();
		}
	});
	
	var advanceFilter=function(){
		$("#hid_pageNum").val(1);
		jqTable.fnDraw();
	}
	
	$('button[name=submit]',$('#pnl_search')).bind('click',advanceFilter);
	
    function refreshTable(){
    	jqTable.fnDraw();
	}
    
    function formatDate(timestamp){
    	var now=new Date(timestamp); 
    	var year=now.getFullYear();     
        var month=now.getMonth()+1;     
        var date=now.getDate();     
        var hour=now.getHours();     
        var minute=now.getMinutes();     
        var second=now.getSeconds();     
        return year+"-"+month+"-"+date+"   "+hour+":"+minute+":"+second;     
   }  
   
    //搜索按钮
	function searchBtn(){
		refreshTable();
	}
	
	function toCurrency(i){
		i = parseFloat(i, 10).toFixed(2);
		return (i=='NaN') ? '0.00' : i;
	}
})