define([ 'jquery' ], function($) {
	'use strict';
	var root='https://admin.vjidian.com/6002/article';
	//定义全部请求的Controller
	var controllers = {
		showArticle:{url:root+'/show'},
		operateAdd:{url:root+'/operate/add'},
		addArticle:{url:root+'/add',data:{article:'',content:'',contentEN:''}},
		updateArticle:{url:root+'/update',data:{article:'',content:'',contentEN:''}},
		findPage:{url:root+'/page',data:{}},
		deleteArticle:{url:root+'/delete',data:{id:''}},
		updatePublished:{url:root+'/updatePublished',data:{id:''}},
		updateSequence:{url:root+'/updateSequence',data:{id:''}},
		getArticleDetial:{url:root+'/getArticleDetial',data:{id:''}},
		delArticles:{url:root+'/delArticles',data:{ids:''}},
		publisheds:{url:root+'/publisheds',data:{ids:''}},
		unPublisheds:{url:root+'/unPublisheds',data:{ids:''}},
		editArticle:{url:root+'/operate/edit/'},
		batchUpdateSequence:{url:root+'/batchUpdateSequence',data:{ids:'',sequences:''}},
	};
	function _ajax(controller,success,error) {
		var ajaxOptions=$.extend(true,controller,{success:success,error:error,type:'POST',dataType:'JSON'});
		$.ajax(ajaxOptions);
	}
	function _addArticle(article,content,contentEN,success,error){
		controllers.addArticle.data.articleJSON = JSON.stringify(article);
		controllers.addArticle.data.content = content;
		controllers.addArticle.data.contentEN = contentEN;
		_ajax(controllers.addArticle,success,error);
	}
	function _updateArticle(article,content,contentEN,success,error){
		controllers.updateArticle.data.articleJSON = JSON.stringify(article);
		controllers.updateArticle.data.content = content;
		controllers.updateArticle.data.contentEN = contentEN;
		_ajax(controllers.updateArticle,success,error);
	}
	function _findPage(data,success,error) {
		controllers.findPage.data=data;
		_ajax(controllers.findPage,success,error);
	}
	function _deleteArticle(id,success,error) {
		controllers.deleteArticle.data.id=id;
		_ajax(controllers.deleteArticle,success,error);
	}
	
	function _updateSequence(id,success,error) {
		controllers.updateSequence.data.id=id;
		_ajax(controllers.updateSequence,success,error);
	}
	
	function _updatePublished(id,published,success,error){
		controllers.updatePublished.data.id=id;
		controllers.updatePublished.data.published=published;
		_ajax(controllers.updatePublished,success,error);
	}
	
	function _getArticleDetial(id,success,error) {
		controllers.getArticleDetial.data.id=id;
		_ajax(controllers.getArticleDetial,success,error);
	}

	function _delArticles(ids,success,error) {
		controllers.delArticles.data.ids=ids;
		_ajax(controllers.delArticles,success,error);
	}
	
	function _publisheds(ids,success,error) {
		controllers.publisheds.data.ids=ids;
		_ajax(controllers.publisheds,success,error);
	}
	
	function _unPublisheds(ids,success,error) {
		controllers.unPublisheds.data.ids=ids;
		_ajax(controllers.unPublisheds,success,error);
	}
	
	function _editArticle(id){
		controllers.editArticle.url +=id;
		return controllers.editArticle.url;
	}
	
	function _batchUpdateSequence(ids,sequences,success,error){
		controllers.batchUpdateSequence.data.ids=ids;
		controllers.batchUpdateSequence.data.sequences=sequences;
		_ajax(controllers.batchUpdateSequence,success,error);
	}
	
	return {
		addArticle:_addArticle,
		updateArticle:_updateArticle,
		findPage:_findPage,
		deleteArticle:_deleteArticle,
		updatePublished:_updatePublished,
		updateSequence:_updateSequence,
		getArticleDetial:_getArticleDetial,
		delArticles:_delArticles,
		publisheds:_publisheds,
		unPublisheds:_unPublisheds,
		editArticle:_editArticle,
		batchUpdateSequence:_batchUpdateSequence,
		controllers:controllers
	};
});