define(['jquery','app'], function ($) {
	'use strict';
	//var root = 'https://admin.vjidian.com/8005/album';
	var root = website_address;
	var controllers = {
		find: {
			url: root + '/find',
			data: {}
		},
		thumb: {
			url: root + '/thumb',
			data: {
				id: ''
			}
		},
		water: {
			url: root + '/water',
			data: {
				id: ''
			}
		},
		//系统原来方法
		//del: {
		//	url: root + '/delete',
		//	data: {
		//		id: ''
		//	}
		//},
		// 12/14 kuaibing 新增
		// 产品删除
		del: {
			url: root + 'vjidian-product/productAdmin/delPic',
			data: {
				id: '',
				ticketc:ticketc
			}
		},
		// 商品删除
		del1: {
			url: root + 'vjidian-product/goodsAdmin/delPic',
			data: {
				id: '',
				ticketc:ticketc
			}
		},
		upload: {
			url: root + '/upload'
		},
		findThumbs: {
			url: root + '/findThumbs',
			data:{
				id: ''
			}
		},
		statistics: {
			url: root + '/statistics',
		},
		show: {
			url: root + '/show',
		}
	};

	function _ajax(controller, success, error) {
		var ajaxOptions = $.extend(true, controller, {
			success: success,
			error: error,
			type: 'POST',
			dataType: 'JSON'
		});
		$.ajax(ajaxOptions);
	}

	function _find(data, success, error) {
		controllers.find.data = data;
		_ajax(controllers.find, success, error);
	}

	function _thumb(id, success, error) {
		controllers.thumb.data.id = id;
		_ajax(controllers.thumb, success, error);
	}

	function _water(id, success, error) {
		controllers.water.data.id = id;
		_ajax(controllers.water, success, error);
	}

	//系统原来的图片删除
	//function _delete(ids, success, error) {
	//	controllers.del.data.id = ids;
	//	_ajax(controllers.del, success, error);
	//}

	/********** 12/13 kuaibing修改的图片删除**********/
	// 产品图片删除
	function _delete(ids, success, error) {
		controllers.del.data.pictureId = ids;
		if(typeof(ids) != "undefined"){ // typeof(ids) == "undefined" 时，相当于图片没有上传成功
			_ajax(controllers.del, success, error);
		}
	}
	// 商品图片删除
	function _delete1(ids, success, error) {
		controllers.del1.data.pictureId = ids;
		if(typeof(ids) != "undefined"){ // typeof(ids) == "undefined" 时，相当于图片没有上传成功
			_ajax(controllers.del1, success, error);
		}
	}
	/********** 12/13 kuaibing修改的图片删除**********/

	function _findThumbs(id, success, error){
		controllers.findThumbs.data.id = id;
		_ajax(controllers.findThumbs, success, error);
	}

	function _statistics(success, error){
		_ajax(controllers.statistics, success, error);
	}
	return {
		controllers:controllers,
		/**
		 * @method find 查询图片
		 * @param data
		 * @param success
		 * @param error
		 */
		find: _find,
		/**
		 * @method thumb 生成缩略图
		 * @param id
		 * @param success
		 * @param error
		 */
		thumb: _thumb,
		/**
		 * @method water 生成水印
		 * @param id
		 * @param success
		 * @param error
		 */
		water: _water,
		/**
		 * @method delete 删除图片
		 * @param ids 可以传单个Id，也可以传一组
		 * @param success
		 * @param error
		 */
		del: _delete, // 产品删除
		del1: _delete1, // 商品删除
		/**
		 * @method findThumbs 获取图片所有缩略图
		 * @param id 图片Id 
		 * @param success
		 * @param error
		 */
		findThumbs: _findThumbs,
		/**
		 * @method statistics 获取图片相关的统计信息
		 * @param success
		 * @param error
		 */
		statistics: _statistics
	};
});