/**
 * @class 图片类型配置
 * @method find
 */
define(['jquery'], function ($) {
	'use strict';
	var root = 'https://admin.vjidian.com/812/albumConfig';
	var controllers = {
		find: {
			url: root + '/find'
		},
		addView: {
			url: root + '/addView'
		},
		editView: {
			url: root + '/editView'
		},
		add: {
			url: root + '/add'
		},
		update: {
			url: root + '/update'
		},
		del: {
			url: root + '/delete',
			data: {
				id:0
			}
		},
		show: {
			url: root + '/show'
		},
		verifyLocationUniqueness: {
			url: root + '/verifyLocationUniqueness'
		}
	};

	function _ajax(controller, success, error) {
		var ajaxOptions = $.extend(true, controller, {
			success: success,
			error: error,
			type: 'POST',
			dataType: 'JSON'
		});
		$.ajax(ajaxOptions);
	}

	function _del(id, success, error){
		controllers.del.data.id = id;
		_ajax(controllers.del, success, error);
	}

	return {
		controllers:controllers,
		del: _del
	};
});