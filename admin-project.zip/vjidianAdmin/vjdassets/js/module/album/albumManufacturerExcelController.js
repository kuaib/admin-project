define(['jquery'], function ($) {
	'use strict';
	var root = 'https://admin.vjidian.com/8005/album';
	var controllers = {
		find: {
			url: root + '/find',
			data: {}
		},
		thumb: {
			url: root + '/thumb',
			data: {
				id: ''
			}
		},
		water: {
			url: root + '/water',
			data: {
				id: ''
			}
		},
		del: {
			url: root + '/deleteexcel',
			data: {
				id: ''
			}
		},
		upload: {
			url: root + '/uploadexcelManufacturer',
		},
		findThumbs: {
			url: root + '/findThumbs',
			data:{
				id: ''
			}
		},
		statistics: {
			url: root + '/statistics',
		},
		show: {
			url: root + '/show',
		}
	};

	function _ajax(controller, success, error) {
		var ajaxOptions = $.extend(true, controller, {
			success: success,
			error: error,
			type: 'POST',
			dataType: 'JSON'
		});
		$.ajax(ajaxOptions);
	}

	function _find(data, success, error) {
		controllers.find.data = data;
		_ajax(controllers.find, success, error);
	}

	function _thumb(id, success, error) {
		controllers.thumb.data.id = id;
		_ajax(controllers.thumb, success, error);
	}

	function _water(id, success, error) {
		controllers.water.data.id = id;
		_ajax(controllers.water, success, error);
	}

	function _delete(ids, success, error) {
		controllers.del.data.id = ids;
		_ajax(controllers.del, success, error);
	}

	function _findThumbs(id, success, error){
		controllers.findThumbs.data.id = id;
		_ajax(controllers.findThumbs, success, error);
	}

	function _statistics(success, error){
		_ajax(controllers.statistics, success, error);
	}
	return {
		controllers:controllers,
		/**
		 * @method find 查询图片
		 * @param data
		 * @param success
		 * @param error
		 */
		find: _find,
		/**
		 * @method thumb 生成缩略图
		 * @param id
		 * @param success
		 * @param error
		 */
		thumb: _thumb,
		/**
		 * @method water 生成水印
		 * @param id
		 * @param success
		 * @param error
		 */
		water: _water,
		/**
		 * @method delete 删除图片
		 * @param ids 可以传单个Id，也可以传一组
		 * @param success
		 * @param error
		 */
		del: _delete,
		/**
		 * @method findThumbs 获取图片所有缩略图
		 * @param id 图片Id 
		 * @param success
		 * @param error
		 */
		findThumbs: _findThumbs,
		/**
		 * @method statistics 获取图片相关的统计信息
		 * @param success
		 * @param error
		 */
		statistics: _statistics
	};
});