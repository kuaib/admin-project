define(['jquery'], function($) {
	'use strict';
	var root = 'https://admin.vjidian.com/4002/abnormalorder';
	var controllers = {
		show:{url:root+'/show'},
		find:{url:root+'/find'},
		viewDetail:{url:root+'/viewDetail/'},
		getOverview:{url:root+'/getOverview',data:{}},
		confirmCancel:{url:root+'/confirmCancel',data:{}},
		abortCancel:{url:root+'/abortCancel',data:{}}
	};

	function _ajax(controller, success, error) {
		var ajaxOptions = $.extend(true, controller, {
			type:'POST',
			dataType:'JSON',
			success:success,
			error:error
		});
		$.ajax(ajaxOptions);
	};
	function _getOverview(id, success, error) {
		controllers.getOverview.data.id = id;
		_ajax(controllers.getOverview, success, error);
	}
	function _confirmCancel(orderId, remark, success, error) {
		controllers.confirmCancel.data.orderId = orderId;
		controllers.confirmCancel.data.remark = remark;
		_ajax(controllers.confirmCancel, success, error);
	}
	function _abortCancel(orderId, success, error) {
		controllers.abortCancel.data.orderId = orderId;
		_ajax(controllers.abortCancel, success, error);
	}
	
	return {
		controllers: controllers,
		getOverview: _getOverview,
		confirmCancel: _confirmCancel,
		abortCancel: _abortCancel,
	};
});