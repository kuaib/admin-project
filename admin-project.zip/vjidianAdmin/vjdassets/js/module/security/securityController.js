/**
 * 权限管理
 */
define(['jquery'], function ($) {
	'use strict';
	var root = 'https://admin.vjidian.com/9102/security';
	//定义全部请求的Controller
	var controllers = {
		findMenuByRoleId: {
			url: root + '/findMenuByRoleId',
			data: {
				roleid: 0
			}
		},
		findMenuByPage: {
			url: root + '/findMenuByPage'
		},
		findRole: {
			url: root + '/findRole'
		},
		findUserByRoleId: {
			url: root + '/findUserByRoleId',
			data: {
				roleid: 0
			}
		},
		findUserByName: {
			url: root + '/findUserByName',
			data: {
				name: ''
			}
		},
		addRole: {
			url: root + '/addRole',
			data: {
				name: ''
			}
		},
		deleteRole: {
			url: root + '/deleteRole',
			data: {
				roleid: 0
			}
		},
		addRoleToUser: {
			url: root + '/addRoleToUser',
			data: {
				roleid: 0,
				userid: 0
			}
		},
		deleteRoleFromUser: {
			url: root + '/deleteRoleFromUser',
			data: {
				roleid: 0,
				userid: []
			}
		},
		updateMenuOfRole: {
			url: root + '/updateMenuOfRole',
			data: {
				roleid: 0,
				addedmenuid: [],
				deletedmenuid: []
			}

		},
		verifyRoleNameUniqueness: {
			url: root + '/verifyRoleNameUniqueness'
		}
	};

	function _ajax(controller, success, error) {
		var defaulterror = function(jqXHR){
			if(jqXHR.status == 403){
				$.Error(jqXHR.responseText);
			}
		}
		var ajaxOptions = $.extend(true, controller, {
			type: 'POST',
			dataType: 'JSON',
			success: success,
			error: defaulterror
		});
		$.ajax(ajaxOptions);
	}

	function _findRole(success, error) {
		_ajax(controllers.findRole, success, error);
	}

	function _findUserByRoleId(roleId, success, error) {
		controllers.findUserByRoleId.data.roleid = roleId;
		_ajax(controllers.findUserByRoleId, success, error);
	}

	function _findMenuByRoleId(roleId, success, error) {
		controllers.findMenuByRoleId.data.roleid = roleId;
		_ajax(controllers.findMenuByRoleId, success, error);
	}

	function _addRole(data, success, error) {
		controllers.addRole.data = data;
		_ajax(controllers.addRole, success, error);
	}

	function _deleteRole(roleId, success, error) {
		controllers.deleteRole.data.roleid = roleId;
		_ajax(controllers.deleteRole, success, error);
	}

	function _addRoleToUser(roleid, userid, success, error) {
		var data = {
			roleid: roleid,
			userid: userid
		};
		controllers.addRoleToUser.data = data;
		_ajax(controllers.addRoleToUser, success, error);
	}

	function _deleteRoleFromUser(roleid, userid, success, error) {
		var data = {
			roleid: roleid,
			userid: userid
		};
		controllers.deleteRoleFromUser.data = data;
		_ajax(controllers.deleteRoleFromUser, success, error);
	}

	function _updateMenuOfRole(data, success, error) {
		controllers.updateMenuOfRole.data = data;
		_ajax(controllers.updateMenuOfRole, success, error);
	}

	function _findUserByName(name, success, error){
		controllers.findUserByName.data.name = name;
		_ajax(controllers.findUserByName, success, error);
	}

	return {
		controllers: controllers,
		findRole:_findRole,
		findMenuByRoleId: _findMenuByRoleId,
		findUserByRoleId: _findUserByRoleId,
		addRole: _addRole,
		deleteRole: _deleteRole,
		addRoleToUser: _addRoleToUser,
		deleteRoleFromUser: _deleteRoleFromUser,
		findUserByName: _findUserByName,
		updateMenuOfRole:_updateMenuOfRole
	};
})