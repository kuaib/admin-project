define(['jquery'], function ($) {
	'use strict';
	var root = 'https://admin.vjidian.com/9101/securityUser';
	var controllers = {
		show: {url: root + '/show'},
		add: {url: root + '/add', data: {}},
		update: {url: root + '/update', data: {}},
		find: {url: root + '/find'},
		del: {url: root + '/delete', data: {id: ''}},
		editView: {url: root + '/editView/'},
		addView: {url: root + '/addView'},
		enable: {url: root + '/enable', data: {id: 0}},
		disable: {url: root + '/disable', data: {id: 0}},
		lock: {url: root + '/lock', data: {id: 0}},
		unlock: {url: root + '/unlock', data: {id: 0}},
		editPassword: {url: root + '/editPassword', data: {id: 0, password: ''}},
		editOwnPassword: {url: root + '/editOwnPassword',data: {}},
		getAvatar: {url: root + '/getAvatar', data: {avatar: 0}},
		findUserMenuByRoleId: {url: root + '/findUserMenuByRoleId', data: {roleid: 0}},
		findRoleByUserId: {url: root + '/findRoleByUserId',data: {userid: 0}},
		batchEnable: {url: root + '/batchEnable',data: {userid: []}},
		batchDisable: {url: root + '/batchDisable',data: {userid: []}},
		findSubsiteByUserId: {url: root + '/findSubsiteByUserId',data: {userid: []}},
		verifyLoginNameUniqueness: {url: root + '/verifyLoginNameUniqueness'}
	};

	function _ajax(controller, success, error) {
		var ajaxOptions = $.extend(true, controller, {
			type: 'POST',
			dataType: 'JSON',
			success: success,
			error: error
		});
		$.ajax(ajaxOptions);
	}

	function _add(data, success, error) {
		controllers.add.data = data;
		_ajax(controllers.add, success, error);
	}

	function _update(data, success, error) {
		controllers.update.data = data;
		_ajax(controllers.update, success, error);
	}

	function _find(data, success, error) {
		controllers.find.data = data;
		_ajax(controllers.find, success, error);
	}

	function _del(id, success, error) {
		controllers.del.data.id = id;
		_ajax(controllers.del, success, error);
	}

	function _enable(id, success, error) {
		controllers.enable.data.id = id;
		_ajax(controllers.enable, success, error);
	}

	function _disable(id, success, error) {
		controllers.disable.data.id = id;
		_ajax(controllers.disable, success, error);
	}

	function _lock(id, success, error) {
		controllers.lock.data.id = id;
		_ajax(controllers.lock, success, error);
	}

	function _unlock(id, success, error) {
		controllers.unlock.data.id = id;
		_ajax(controllers.unlock, success, error);
	}

	function _editPassword(data, success, error) {
		controllers.editPassword.data = data;
		_ajax(controllers.editPassword, success, error);
	}

	function _editOwnPassword(data, success, error) {
		controllers.editOwnPassword.data = data;
		_ajax(controllers.editOwnPassword, success, error);
	}

	function _getAvatar(avatar, success, error) {
		controllers.getAvatar.data.avatar = avatar;
		_ajax(controllers.getAvatar, success, error);
	}

	function _findUserMenuByRoleId(roleid, success, error) {
		controllers.findUserMenuByRoleId.data.roleid = roleid;
		_ajax(controllers.findUserMenuByRoleId, success, error);
	}

	function _findRoleByUserId(userid, success, error) {
		controllers.findRoleByUserId.data.userid = userid;
		_ajax(controllers.findRoleByUserId, success, error);
	}

	function _batchEnable(userid, success, error) {
		controllers.batchEnable.data.userid = userid;
		_ajax(controllers.batchEnable, success, error);
	}

	function _batchDisable(userid, success, error) {
		controllers.batchDisable.data.userid = userid;
		_ajax(controllers.batchDisable, success, error);
	}

	function _findSubsiteByUserId(userid, success, error) {
		controllers.findSubsiteByUserId.data.userid = userid;
		_ajax(controllers.findSubsiteByUserId, success, error);
	}

	return {
		controllers: controllers,
		add: _add,
		update: _update,
		find: _find,
		delete: _del,
		enable: _enable,
		disable: _disable,
		lock: _lock,
		unlock: _unlock,
		editPassword: _editPassword,
		editOwnPassword: _editOwnPassword,
		getAvatar: _getAvatar,
		findUserMenuByRoleId: _findUserMenuByRoleId,
		findRoleByUserId: _findRoleByUserId,
		batchEnable: _batchEnable,
		batchDisable: _batchDisable,
		findSubsiteByUserId: _findSubsiteByUserId
	};
});