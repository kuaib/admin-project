/**
 * 支付宝退款订单管理
 */
define(['jquery'], function($) {
	'use strict';
	var root = 'https://admin.vjidian.com/4007/refund';
	var orderroot='https://admin.vjidian.com/4001/order';
	var controllers = {
		show:{url:root+'/show'},
		find:{url:root+'/find'},
		viewDetail:{url:root+'/viewDetail/'},
		getOverview:{url:orderroot+'/getOverview',data:{}},
		updateRemark:{url:orderroot+'/remark',data:{}},
		updatePayableAmount:{url:orderroot+'/updatePayableAmount',data:{}},
		review:{url:orderroot+'/review',data:{}},
		updateAddress:{url:orderroot+'/updateAddress',data:{}},
		deliver:{url:orderroot+'/deliver',data:{}},
		updateInvocie:{url:orderroot+'/updateInvoice',data:{}},
		addBlackList:{url:orderroot+'/addBlackList',data:{}},
		batchDeliver:{url:orderroot+'/batchDeliver',data:{}},
		batchDeliverTest:{url:orderroot+'/batchDeliverTest',data:{}},
		showBatchDeliver:{url:orderroot+'/showBatchDeliver',data:{}},
		writeInvoice:{url:orderroot+'/writeInvoice',data:{}},
		cancel:{url:orderroot+'/cancel',data:{}},
		forcePay:{url:orderroot+'/forcePay',data:{}},
		bachDeleteProductList:{url:root+'/addRefundOrder'}
	};
	function _ajax(controller, success, error) {
		var ajaxOptions = $.extend(true, controller, {
			type: 'POST',
			dataType: 'JSON',
			success: success,
			error: error
		});
		$.ajax(ajaxOptions);
	}
	function _find(data, success, error) {
		controllers.find.data = data;
		_ajax(controllers.find, success, error);
	}
	function _getOverview(id, success, error) {
		controllers.getOverview.data.id = id;
		_ajax(controllers.getOverview, success, error);
	}
	function _updateRemark(id, remark,tag, success, error) {
		controllers.updateRemark.data.orderId = id;
		controllers.updateRemark.data.remark = remark;
		controllers.updateRemark.data.tag = tag;
		_ajax(controllers.updateRemark, success, error);
	}
	function _updatePayableAmount(id, tuningAmount, remark, success, error) {
		controllers.updatePayableAmount.data.id = id;
		controllers.updatePayableAmount.data.tuningAmount = tuningAmount;
		controllers.updatePayableAmount.data.remark = remark;
		_ajax(controllers.updatePayableAmount, success, error);
	}
	function _review(id, auditState, remark, success, error) {
		controllers.review.data.id = id;
		controllers.review.data.auditState = auditState;
		controllers.review.data.remark = remark;
		_ajax(controllers.review, success, error);
	}
	function _cancel(orderId, remark, success, error) {
		controllers.cancel.data = {orderId:orderId,remark:remark};
		_ajax(controllers.cancel, success, error);
	}
	function _forcePay(orderId, remark, success, error) {
		controllers.forcePay.data = {orderId:orderId,remark:remark};
		_ajax(controllers.forcePay, success, error);
	}
	function _updateAddress(orderDeliveryId, orderId, receiverName, mobile, phone, regionId, address, email,postcode, success, error) {
		controllers.updateAddress.data.orderDeliveryId = orderDeliveryId;
		controllers.updateAddress.data.orderId = orderId;
		controllers.updateAddress.data.receiverName = receiverName;
		controllers.updateAddress.data.mobile = mobile;
		controllers.updateAddress.data.phone = phone;
		controllers.updateAddress.data.regionId = regionId;
		controllers.updateAddress.data.address = address;
		controllers.updateAddress.data.email = email;
		controllers.updateAddress.data.postcode = postcode;
		
		_ajax(controllers.updateAddress, success, error);
	}
	function _deliver(id, expressCompanyId, expressNumber, success, error) {
		controllers.deliver.data.id = id;
		controllers.deliver.data.expressCompanyId = expressCompanyId;
		controllers.deliver.data.expressNumber = expressNumber;
		//controllers.deliver.data.remark = remark;
		_ajax(controllers.deliver, success, error);
	}
	function _updateInvocie(id,needInvoice,titleType,title,code,success, error) {
		controllers.updateInvocie.data.orderId = id;
		controllers.updateInvocie.data.needInvoice = needInvoice;
		controllers.updateInvocie.data.titleType = titleType;
		controllers.updateInvocie.data.title = title;
		controllers.updateInvocie.data.code = code;
//		controllers.updateInvocie.data.noteNum = noteNum;
//		controllers.updateInvocie.data.bank = bank;
//		controllers.updateInvocie.data.bank2 = bank2;
//		controllers.updateInvocie.data.address = address;
//		controllers.updateInvocie.data.address2 = address2;
		_ajax(controllers.updateInvocie, success, error);
	}
	function _batchDeliver(batchDeliver,success, error) {
		controllers.batchDeliver.data = batchDeliver;
		_ajax(controllers.batchDeliver, success, error);
	}
	function _batchDeliverTest(batchDeliver,success, error) {
		controllers.batchDeliverTest.data = batchDeliver;
		_ajax(controllers.batchDeliverTest, success, error);
	}
	

	
	return {
		controllers: controllers,
		getOverview: _getOverview,
		updateRemark: _updateRemark,
		updatePayableAmount: _updatePayableAmount,
		review: _review,
		updateAddress: _updateAddress,
		deliver: _deliver,
		updateInvocie:_updateInvocie,
		batchDeliver:_batchDeliver,
		batchDeliverTest:_batchDeliverTest,
		cancel:_cancel,
		forcePay:_forcePay,
	};
});
