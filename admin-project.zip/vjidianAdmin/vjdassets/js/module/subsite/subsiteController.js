/**
 * 网站基本信息
 */
define([ 'jquery' ], function($) {
	"use strict";
	var root="https://admin.vjidian.com/810/subsite";
	//定义全部请求的Controller
	var controllers = {
			show:{url:root+'/show'},
			getPage:{url:root+'/getPage',type:'POST',dataType:'JSON',data:{}},
			deleteSubsite:{url:root+'/deleteSubsite',type:'POST',dataType:'JSON',data:{id:''}},
			addSubsite:{url:root+'/addSubsite',type:'POST',dataType:'JSON',data:{}},
			updateSubsite:{url:root+'/updateSubsite',type:'POST',dataType:'JSON',data:{}},
			validateName:{url:root+'/validName',type:'POST',dataType:'JSON',data:{}},
			getRegionForTree:{url:root+'/getRegionForTree',type:'POST',dataType:'JSON',data:{}},
			getRegionForSelect:{url:root+'/getRegionForSelect',type:'POST',dataType:'JSON',data:{}},
			showSubsiteRegionEdit:{url:root+'/showSubsiteRegionEdit/',type:'POST',dataType:'JSON',data:{}},
			getRegionForSelectedTree:{url:root+'/getRegionForSelectedTree',type:'POST',dataType:'JSON',data:{}},
			editSubsiteRegion:{url:root+'/editSubsiteRegion',type:'POST',dataType:'JSON',data:{id:'',regionIds:''}},
			showEdit:{url:root+'/showEdit/',type:'POST',dataType:"JSON",data:{}},
			editSubsite:{url:root+'/editSubsite',type:'POST',dataType:'JSON',data:{}},
			changeSubsiteStatus:{url:root+'/changeSubsiteStatus',type:'POST',dataType:'JSON',data:{id:'',isEnabled:''}},
	};
	function _ajax(controller,success,error) {
		var ajaxOptions=$.extend(true,controller,{success:success,error:error});
		$.ajax(ajaxOptions);
	};
	function _getPage(data,success,error){
		controllers.getPage.data=data;
		_ajax(controllers.getPage,success,error);
	};
	function _addSubsite(data,success,error){
		controllers.addSubsite.data=data;
		_ajax(controllers.addSubsite,success,error);
	};
	function _updateWordFitler(data,success,error){
		controllers.updateWordFilter.data=data;
		_ajax(controllers.updateWordFilter,success,error);
	};
	
	function _deleteSubsite(data,success,error){
		controllers.deleteSubsite.data.id=data;
		_ajax(controllers.deleteSubsite,success,error);
	};
	
	function _validateName(data,success,error){
		controllers.validateName.data.id=data;
		_ajax(controllers.validateName,success,error);
	};
	
	function _getRegionForTree(data,success,error){
		controllers.getRegionForTree.data.id=data;
		_ajax(controllers.getRegionForTree,success,error);
	};
	
	function _getRegionForSelect(data,success,error){
		controllers.getRegionForSelect.data.id=data;
		_ajax(controllers.getRegionForSelect,success,error);
	};
	function _showSubsiteRegionEdit(data,success,error){
		controllers.showSubsiteRegionEdit.data=data;
		_ajax(controllers.showSubsiteRegionEdit,success,error);
	};
	function _getRegionForSelectedTree(data,success,error){
		controllers.getRegionForSelectedTree.data=data;
		_ajax(controllers.getRegionForSelectedTree,success,error);
	};
	function _showEdit(data,success,error){
		controllers.showEdit.data=data;
		_ajax(controllers.showEdit,success,error);
	};
	function _editSubsite(data,success,error){
		controllers.editSubsite.data=data;
		_ajax(controllers.editSubsite,success,error);
	};
	function _editSubsiteRegion(id,regionIds,success,error){
		controllers.editSubsiteRegion.data.id=id;
		controllers.editSubsiteRegion.data.regionIds=regionIds;
		_ajax(controllers.editSubsiteRegion,success,error);
	};
	function _changeSubsiteStatus(id,isEnabled,success,error){
		controllers.changeSubsiteStatus.data.id=id;
		controllers.changeSubsiteStatus.data.isEnabled=isEnabled;
		_ajax(controllers.changeSubsiteStatus,success,error);
	};
	return {
		controller:controllers,
		getPage:_getPage,
		deleteSubsite:_deleteSubsite,
		addSubsite:_addSubsite,
		updateWordFilter:_updateWordFitler,
		validateName:_validateName,
		getRegionForTree:_getRegionForTree,
		getRegionForSelect:_getRegionForSelect,
		showSubsiteRegionEdit:_showSubsiteRegionEdit,
		getRegionForSelectedTree:_getRegionForSelectedTree,
		editSubsiteRegion:_editSubsiteRegion,
		showEdit:_showEdit,
		editSubsite:_editSubsite,
		changeSubsiteStatus:_changeSubsiteStatus
	};
});