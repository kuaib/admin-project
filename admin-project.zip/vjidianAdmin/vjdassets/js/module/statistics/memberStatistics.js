define([ 'jquery' ], function($) {
	'use strict';
	var root='https://admin.vjidian.com/7013/memberStatistics';
	//定义全部请求的Controller
	var controllers = {
		show:{url:root+'/show'},
		showMembers:{url:root+'/showMembers'},
		pageMembers:{url:root+'/pageMembers',data:{}},
		search:{url:root+'/page',data:{}},
	};
	function _ajax(controller,success,error) {
		var ajaxOptions=$.extend(true,controller,{
			type:'POST',
			dataType:'JSON',
			success:success,
			error:error
		});
		$.ajax(ajaxOptions);
	}
	function _search(id,success,error){
		controllers.search.data.id=id;
		_ajax(controllers.search,success,error);
	}
	function _showMembers(data, success, error) {
		controllers.showMembers.data = data;
		_ajax(controllers.showMembers, success, error);
	}
	
	return {
		search:_search,
		showMembers:_showMembers,
		controllers:controllers
	};
});