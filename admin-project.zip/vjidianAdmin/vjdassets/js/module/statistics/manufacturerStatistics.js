define([ 'jquery' ], function($) {
	'use strict';
	var root='https://admin.vjidian.com/7014/manufacturerStatistics';
	//定义全部请求的Controller
	var controllers = {
		show:{url:root+'/show'},
		showManufacturers:{url:root+'/showManufacturers'},
		pagManufacturers:{url:root+'/pageManufacturers',data:{}},
		search:{url:root+'/page',data:{}},
	};
	function _ajax(controller,success,error) {
		var ajaxOptions=$.extend(true,controller,{
			type:'POST',
			dataType:'JSON',
			success:success,
			error:error
		});
		$.ajax(ajaxOptions);
	}
	function _search(id,success,error){
		controllers.search.data.id=id;
		_ajax(controllers.search,success,error);
	}
	function _showManufacturers(data, success, error) {
		controllers.showManufacturers.data = data;
		_ajax(controllers.showManufacturers, success, error);
	}
	
	return {
		search:_search,
		showManufacturers:_showManufacturers,
		controllers:controllers
	};
});