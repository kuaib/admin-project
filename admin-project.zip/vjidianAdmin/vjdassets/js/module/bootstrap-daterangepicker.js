//TODO 需要重构
define([ 'jquery', 'moment', 'daterangepicker' ], function($) {
	// 渲染控件
	require([ 'css!/vjdassets/plugins/daterangepicker/daterangepicker-bs3.css' ]);
	var init = function() {
		var ctl = $(".bootstrap-daterangepicker");
		if (ctl.size() > 0) {
			ctl.each(function() {
						ctl.show();
						var content = $("<span>");
						var calendarIcon = $("<i>", {
							"class" : "fa fa-calendar"
						});
						var angledownIcon = $("<i>", {
							"class" : "fa fa-angle-down"
						});
						var format = $(this).data("date-format") == null?"YYYY-MM-DD":$(this).data("date-format");
						var separator = $(this).data("date-separator")==null?"-":$(this).data("date-separator");
						var opens=$(this).data("opens")==null?"right":$(this).data("opens");
						var initDateRange = $(this).data("init-range");
						var initStartDate, initEndDate;
						initStartDate = moment().format(format);
						initEndDate = moment().format(format);
						if (initDateRange != null
								&& initDateRange.indexOf(':') != -1) {
							var tmpstr = initDateRange.split(':');
							if (tmpstr[0].toLowerCase() == 'last') {
								initStartDate = moment().subtract('days',
										tmpstr[1] - 1).format(format);
								initEndDate = moment().format(format);
							}
						}
						content.html(
								initStartDate + ' ' + separator + ' '
										+ initEndDate);
						//wrapper = $(this).wrap(wrapper).parent();
						$(this).append(calendarIcon);
						$(this).append(content);
						$(this).append(angledownIcon);

						$(this).daterangepicker({
							opens : 'left',
							startDate : initStartDate,
							endDate : initEndDate,
							minDate : '2000-01-01',
							maxDate : '2099-12-31',
							dateLimit : {
								days : 365
							},
							showDropdowns : false,
							showWeekNumbers : true,
							timePicker : false,
							timePickerIncrement : 1,
							timePicker12Hour : true,
							ranges : {
								'今日' : [ moment(), moment() ],
								'昨日' : [ moment().subtract('days', 1),
										moment().subtract('days', 1) ],
								'过去7天' : [ moment().subtract('days', 6),
										moment() ],
								'过去30天' : [ moment().subtract('days', 29),
										moment() ],
								'本月' : [ moment().startOf('month'),
										moment().endOf('month') ],
								'上月' : [
										moment().subtract('month', 1).startOf(
												'month'),
										moment().subtract('month', 1).endOf(
												'month') ]
							},
							buttonClasses : [ 'btn' ],
							applyClass : 'blue',
							cancelClass : 'default',
							format : format,
							separator : ' ' + separator + ' ',
							locale : {
								applyLabel : '确定',
								fromLabel : '从',
								toLabel : '到',
								customRangeLabel : '自定义范围',
								daysOfWeek : [ '日', '一', '二', '三', '四', '五',
										'六' ],
								monthNames : [ '一月', '二月', '三月', '四月', '五月',
										'六月', '七月', '八月', '九月', '十月', '十一月',
										'十二月' ],
								firstDay : 1
							}
						}, function(start, end) {
							// console.log("Callback has been called!");
							// console.log(ctl.html());
							content.html(start.format(format) + ' ' + separator
									+ ' ' + end.format(format));
						});
					});
		}
		;
	};
	init();
});
