define([ 'jquery' ], function($) {
	'use strict';
	var root='https://admin.vjidian.com/2105/manufacturerbrandregion';
	//定义全部请求的Controller
	var controllers = {
		update:{url:root+'/update',data:{}},
		page:{url:root+'/page',data:{}},
		editView:{url:root+'/editView'},
		getRegionsByBrandId:{url:root+'/getRegionsByBrandId',data:{}},
	};
	function _ajax(controller,success,error) {
		var ajaxOptions=$.extend(true,controller,{
			type:'POST',
			dataType:'JSON',
			success:success,
			error:error
		});
		$.ajax(ajaxOptions);
	}

	function _update(data,success,error){
		controllers.update.data.id=data.id;
		controllers.update.data.brandId=data.brandId;
		controllers.update.data.regionIds=data.regionIds;
		_ajax(controllers.update,success,error);
	}

	function _editView(id){
		return controllers.editView.url + '/' + id;
	}

	function _getRegionsByBrandId(id,brandId,success,error) {
		controllers.getRegionsByBrandId.data.id = id;
		controllers.getRegionsByBrandId.data.brandId = brandId;
		_ajax(controllers.getRegionsByBrandId, success, error);
	}

	return {
		update:_update,
		editView:_editView,
		getRegionsByBrandId:_getRegionsByBrandId,
		controllers:controllers
	};
});
