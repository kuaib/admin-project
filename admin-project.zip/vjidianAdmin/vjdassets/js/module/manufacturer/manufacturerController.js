define([ 'jquery' ], function($) {
	'use strict';
	var root='https://admin.vjidian.com/2101/manufacturer';
	//定义全部请求的Controller
	var controllers = {
		add:{url:root+'/add',data:{}},
		update:{url:root+'/update',data:{}},
		page:{url:root+'/page',data:{}},
		delete:{url:root+'/delete',data:{}},
		editView:{url:root+'/editView'},
		addView:{url:root+'/addView'},
		getBranchCrewList:{url:root+'/getBranchCrewList',data:{}},
		audit: {url: root + '/audit', data: {}},
		verifyLoginNameUniqueness: {url: root + '/verifyLoginNameUniqueness'},
		verifyEmailUniqueness: {url: root + '/verifyEmailUniqueness'},
		verifyMobileUniqueness: {url: root + '/verifyMobileUniqueness'},
		uploadexcelView:{url:root+'/uploadexcelView'},
		show:{url:root+'/show'},
	};
	function _ajax(controller,success,error) {
		var ajaxOptions=$.extend(true,controller,{
			type:'POST',
			dataType:'JSON',
			success:success,
			error:error
		});
		$.ajax(ajaxOptions);
	}
	function _add(data,success,error){
		controllers.add.data=data;
		_ajax(controllers.add,success,error);
	}
	function _update(data,success,error){
		controllers.update.data=data;
		_ajax(controllers.update,success,error);
	}
	function _page(data,success,error) {
		controllers.page.data=data;
		_ajax(controllers.page,success,error);
	}
	function _delete(id,success,error) {
		controllers.delete.data.id=id;
		_ajax(controllers.delete,success,error);
	}
	function _editView(id){
		return controllers.editView.url + '/' + id;
	}
	function _getBranchCrewList(branchId,success,error) {
		controllers.getBranchCrewList.data.branchId = branchId;
		_ajax(controllers.getBranchCrewList, success, error);
	}

	function _audit(data, success, error) {
		controllers.audit.data = data;
		_ajax(controllers.audit, success, error);
	}

	return {
		add:_add,
		update:_update,
		page:_page,
		delete:_delete,
		editView:_editView,
		getBranchCrewList:_getBranchCrewList,
		audit: _audit,
		controllers:controllers
	};
});
