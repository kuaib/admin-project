/**
 * 商品核心模块
 */
define(['js/module/manufacturer/manufacturerController',        
	'nice-validator-zh_CN',
	'ueditor',
	'js/module/pageControls'], function(manufacturerController) {
			
	var pictures=[];
	
	var productSpecObjs=[];
	
	var _initPicture=function(pics){
		//商品图片初始化
		require(['fileuploadingridviewmanufacturerexcel',
			'js/module/album/albumManufacturerExcelController'], 
			function(upload,albumController) {
			var delSuccess=function(data){
				if (data) {
					if (data.result) {
						$.Success(data.tip);
					} else {
						$.Error(data.tip);
					}
				}
			};
			function data_delete(data) {
				var pictureId = data.pictureid;
				//商品id
				var productId=$('#hid_productId').val();
				if (typeof(pics) != "undefined" && typeof(productId) != "undefined") {
					//编辑商品状态
					manufacturerController.deletePicture(productId,pictureId,delSuccess)
				}else{
					//新增商品状态
					albumController.del(pictureId,delSuccess);
				}
			}
			$('#btnAllDelete').on('click',function(){
				$('#tbl_pictures .delete').trigger('click');
			});
			var uploadRoot = '/vjdassets/upload/';
			var uploadUrl = albumController.controllers.upload.url;
			//alert(uploadUrl);
			upload.init($('#frm_picture'), uploadRoot,uploadUrl,data_delete,pics);	
		});
	}
		
	var _addProduct=function(e){
		e.preventDefault();				
		
		//图片
		if(pictures.length>0){
			productObj.pictures= pictures;
		}					
		
		window.setInterval(function(){     
			location.href =manufacturerController.controllers.show.url;
	    },2000);
	}
		
	var _addPicture=function(){
		pictures.length=0;
		$("p a[data-gallery='']",$('#frm_picture')).each(function() {
			if ($(this).attr('href')) {
				pictures.push($(this).data('id'));
			}
		});
	}
	
	var _updatePicture=function(e){
		e.preventDefault();	
		pictures.length=0;
		var submitSuccess=function(data){
			if(data.result){
				$.Success(data.tip);
				$('#btn_listproduct').trigger('click');
			}else{
				$.Warn(data.tip);
		 	}
		};
		$("p a[data-gallery='']",$('#frm_picture')).each(function() {
			if ($(this).attr('href')) {
				var item={
					id:$(this).data('id'),
				};
				pictures.push(item);
			}
		});
		var productObj={};
		//商品id
		productObj.id=$('#hid_productId').val();
		//图片
		if(pictures.length>0){
			productObj.pictureList= pictures;
		}
		manufacturerController.updatePicture(productObj,submitSuccess);
	}
	
    var _validatePictures=function(){
    	//图片
		if($("p a[data-gallery='']",$('#frm_picture')).size()>0){
			return true;
		}
		return false;
    } 
	
	return {
		initPicture:_initPicture,
		addProduct:_addProduct,
		addPicture:_addPicture,
		updatePicture:_updatePicture,
		validatePictures:_validatePictures,
    };
});
