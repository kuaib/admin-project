define([ 'jquery' ], function($) {
	'use strict';
	var root='https://admin.vjidian.com/2104/manufacturermaintain';
	//定义全部请求的Controller
	var controllers = {
		update:{url:root+'/update',data:{}},
	};
	function _ajax(controller,success,error) {
		var ajaxOptions=$.extend(true,controller,{
			type:'POST',
			dataType:'JSON',
			success:success,
			error:error
		});
		$.ajax(ajaxOptions);
	}

	function _update(data,success,error){
		controllers.update.data=data;
		_ajax(controllers.update,success,error);
	}

	return {
		update:_update,
		controllers:controllers
	};
});
