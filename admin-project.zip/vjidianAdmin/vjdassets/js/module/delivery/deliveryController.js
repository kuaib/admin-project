define([ 'jquery' ], function($) {
	'use strict';
	var root="https://admin.vjidian.com/5002/delivery";
	//定义全部请求的Controller
	var controllers = {
		getPage:{url:root+'/page',type:'POST',dataType:'JSON',data:{}},
		findAllRegion:{url:root+'/findAllRegion',type:'POST',dataType:'JSON',data:{}},
		findFreightRegion:{url:root+'/findFreightRegion',type:'POST',dataType:'JSON',data:{}},
		findDeliveryRegion:{url:root+'/findDeliveryRegion',type:'POST',dataType:'JSON',data:{}},
		addDelivery:{url:root+'/addDelivery',type:'POST',dataType:'JSON',data:{}},
		editDelivery:{url:root+'/editDelivery',type:'POST',dataType:'JSON',data:{}},
		edit:{url:root+'/operate/edit/'},
		show:{url:root+'/show'},
		
	};
	function _ajax(controller,success,error) {
		var ajaxOptions=$.extend(true,controller,{success:success,error:error});
		$.ajax(ajaxOptions);
	}
	
	function _addDelivery(subsiteId,deliveryModeId,deliveryRegionIds,freightObj,success,error){
		controllers.addDelivery.data.subsiteId=subsiteId;
		controllers.addDelivery.data.deliveryModeId=deliveryModeId;
		controllers.addDelivery.data.deliveryRegionIds=deliveryRegionIds;
		controllers.addDelivery.data.freightJosn=JSON.stringify(freightObj);
		_ajax(controllers.addDelivery,success,error);
	}
	
	function _editDelivery(subsiteId,deliveryModeId,addRegionIds,deletedRegionIds,freightObj,success,error){
		controllers.editDelivery.data.subsiteId=subsiteId;
		controllers.editDelivery.data.deliveryModeId=deliveryModeId;
		controllers.editDelivery.data.addRegionIds=addRegionIds;
		controllers.editDelivery.data.deletedRegionIds=deletedRegionIds;
		controllers.editDelivery.data.freightJosn=JSON.stringify(freightObj);
		_ajax(controllers.editDelivery,success,error);
	}
	
	
	
	function _findRegion(data,success,error) {
		controllers.findRegion.data=data;
		_ajax(controllers.findRegion,success,error);
	}
	
	function _findFreightRegion(subsiteId,deliveryModeId,deliveryFreightId,success,error) {
		controllers.findFreightRegion.data.subsiteId=subsiteId;
		controllers.findFreightRegion.data.deliveryModeId=deliveryModeId;
		controllers.findFreightRegion.data.deliveryFreightId=deliveryFreightId;
		_ajax(controllers.findFreightRegion,success,error);
	}
	
	function _findDeliveryRegion(subsiteId,deliveryModeId,success,error) {
		controllers.findDeliveryRegion.data.subsiteId=subsiteId;
		controllers.findDeliveryRegion.data.deliveryModeId=deliveryModeId;
		_ajax(controllers.findDeliveryRegion,success,error);
	}
	
	function _getPage(data,success,error) {
		controllers.getPage.data=data;
		_ajax(controllers.getPage,success,error);
	}
	
	return {
		addDelivery:_addDelivery,
		editDelivery:_editDelivery,
		findRegion:_findRegion,
		findFreightRegion:_findFreightRegion,
		findDeliveryRegion:_findDeliveryRegion,
		getPage:_getPage,
		controllers:controllers
	};
});