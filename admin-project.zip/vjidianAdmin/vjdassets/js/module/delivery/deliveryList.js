define(['js/module/delivery/deliveryController','data-grid-assemble','js/module/pageControls'], function(deliveryController,dataGrid) {
	
	//datatable配置
	var options={
		table:$('#tbl_freight'),
		deferRender: true,
		showChecked:false,
		dom:'t',
		//定义列
		columns:[ 
		    {title:"分站",data:"subsiteName",width:"10%",orderable : false,orderable:false},
		    {title:"配送方式名称",data:"deliveryModeName",width:"10%",orderable : false,orderable:false},
 			{title:"配送地区",data:"regionList",order: ["desc"],width:"20%",className:"text-left",orderable:false,render:function(data,type,row,meta){
 				var regionTitle="";
 				if(data.length>0){
 					var regionTitle='共'+data.length+'个地区：<a href="javascript:;" class="region_detail" data-toggle="modal" data-target="#treeModal">查看地区详情</a><br>';
 					for(var i=0;i<data.length;i++){
 						regionTitle+="["+data[i].name+"] ";
 						if((i+1)%4==0){
 							regionTitle+="<br>";
 						}
 						
 					}
 				}
 				return regionTitle;
 			}},
 			
 			{title:"价格区间",data:"freight",width:"20%",orderable : false,orderable:false,render:function(data,type,row,meta){
 				var rangeTitle="";
 				if(data.freightRangeList.length>0){
 					for(var i=0;i<data.freightRangeList.length;i++){
 						var minAmount=data.freightRangeList[i].minAmount;
 						var maxAmount=data.freightRangeList[i].maxAmount;
 						var fristFreight=data.freightRangeList[i].fristFreight;
 						var fristWeight=data.freightRangeList[i].fristWeight;
 						rangeTitle+="["+minAmount+"元及以上,"+maxAmount+"元以下,"+fristWeight+"克及以下,运费"+fristFreight+"元]<br>"
 					}
 				}
 				return rangeTitle;
 			}},
 			
 			{title:"阶梯运费",data:"freight",width:"20%",orderable : false,orderable:false,render:function(data,type,row,meta){
 				var ladderTitle="";
 				var ladderFirstAmount=data.ladderFirstAmount;
 				var ladderAmount=data.ladderAmount;
 				var ladderFirstWeight=data.ladderFirstWeight
 				var ladderWeight=data.ladderWeight;
 				ladderTitle+="满"+ladderFirstAmount+"元，重量<="+ladderFirstWeight+"克，免运费"+"<br>";
 				ladderTitle+="满"+(ladderFirstAmount+ladderAmount)+"元，重量<="+(ladderFirstWeight+ladderWeight)+"克，免运费"+"<br>";
 				ladderTitle+="以此类推";
 				return ladderTitle;
 			}},
 			
 			{title:"续费(元)",data:"freight",width:"10%",orderable : false,orderable:false,render:function(data,type,row,meta){
 				return data.additionalPrice;
 			}},
 			{title:"续重(克)",data:"freight",width:"10%",orderable : false,orderable:false,render:function(data,type,row,meta){
 				return data.additionalWeight;
 			}},
		],
		ajax:{
		 	url:deliveryController.controllers.getPage.url,
		 	data:function(d){
				var data = $.extend({}, d, {
	    			iDisplayLength: $('#hid_pageSize').val(),
	    			iDisplayStart: $('#hid_pageNum').val(),
				});
				var subsiteId=$('#sel_siteId').val();
				var deliveryModeId=$('#sel_deliveryMode').val();
				if(subsiteId){
					data.subsiteId=subsiteId;
				}
				if(deliveryModeId){
					data.deliveryModeId=deliveryModeId;
				}
				return data;
			}
		},
		//定义操作列
		actions:{
			edit:{
				className:null,
				tip:'',
				fn:edit
			},
			delete:{
				className:null,
				tip:'删除',
				fn:deleteDeliverymode
			},
		},
	};

	//编辑
	function edit(){
		var $this = $(this);
		var row = $this.parents('tr')[0];
		var deliveryDetail=jqTable.fnGetData(row);
		var url =deliveryController.controllers.edit.url;
		window.location.href=url+deliveryDetail.subsiteId+"/"+deliveryDetail.deliveryModeId+"/"+$(this).data('deliveryfreightid');
	}
	
	//初始化table
	var jqTable=dataGrid.init(options);
	
	function loadTree(e){
		var $this = $(this);
		var row = $this.parents('tr')[0];
		var deliveryDetail=jqTable.fnGetData(row);
		var treeObj = $.fn.zTree.getZTreeObj("pnl_tree");
		//全部收起
		treeObj.expandAll(false);
		//展开一级地区
		var rootNode = treeObj.getNodeByParam('id',0);
		treeObj.expandNode(rootNode, true, false);	
		//将树置未选中状态
		treeObj.checkAllNodes(false);
		//根据返回数据设置需要选中的节点
		$.each(deliveryDetail.regionList,function(index,region){
			var node = treeObj.getNodeByParam('id',region.id);
			if(node){
				//console.log(node);
				//node.checked=true;
				treeObj.checkNode(node,true,false);
			}
		});
	}
	
	
    //删除
    function deleteDeliverymode(e){
    	e.preventDefault();
    	/*var id=$(this).data("id");
    	require(['js/module/bootstrap-dialog'], function(dialog) {
 			dialog.confirm('删除配送规则','<i class="fa fa-exclamation-triangle"></i><span>确定要删除吗?</span>', function(result){
 				if(result) {
	            	var deleteSuccess=function(data){
	            		if(data.result){
	     					$.Success(data.tip);
	     					refreshTable();
	     				}else{
	     					$.Warn(data.tip);
	     			 	}
    				};
    				deliverymodeController.del(id,deleteSuccess);	    			
	            };
		    });
		});*/
    }

    function refreshTable(){
    	jqTable.fnDraw();
	}
    
    //搜索按钮
	function searchBtn(){
		refreshTable();
	}
	
	$('#btn_refresh').on('click',refreshTable);
	
	$('tbody',jqTable).on('click','a.region_detail',loadTree);
})