define([ 'jquery' ], function($) {
	'use strict';
	var root='https://admin.vjidian.com/5004/deliveryRegion';
	//定义全部请求的Controller
	var controllers = {
		findRegion:{url:root+'/findRegion',type:'POST',dataType:'JSON',data:{}},
		findDeliveryRegionBySubiteId:{url:root+'/findDeliveryRegionBySubiteId',type:'POST',dataType:'JSON',data:{}},
		updateDeliveryRegion:{url:root+'/updateDeliveryRegion',type:'POST',dataType:'JSON',data:{}},
		add:{url:root+'/add',type:'POST',dataType:'JSON',data:{}},
		update:{url:root+'/update',type:'POST',dataType:'JSON',data:{}},
		edit:{url:root+'/operate/edit/'},
		del:{url:root+'/delete',type:'POST',dataType:'JSON',data:{}},
		show:{url:root+'/show'},
		view:{url:root+'/view/'},
	};
	function _ajax(controller,success,error) {
		var ajaxOptions=$.extend(true,controller,{success:success,error:error});
		$.ajax(ajaxOptions);
	}
	
	function _add(data,success,error){
		controllers.add.data=data;
		_ajax(controllers.add,success,error);
	}
	function _update(data,success,error){
		controllers.update.data=data;
		_ajax(controllers.update,success,error);
	}
	
	function _findRegion(data,success,error) {
		controllers.findRegion.data=data;
		_ajax(controllers.findRegion,success,error);
	}
	
	function _findDeliveryRegionBySubiteId(subsiteId,success,error) {
		controllers.findDeliveryRegionBySubiteId.data.subsiteId=subsiteId;
		_ajax(controllers.findDeliveryRegionBySubiteId,success,error);
	}
	
	function _updateDeliveryRegion(data,success,error) {
		controllers.updateDeliveryRegion.data.subsiteId=data.subsiteId;
		controllers.updateDeliveryRegion.data.addedRegionId=data.addedRegionId;
		controllers.updateDeliveryRegion.data.deletedRegionId=data.deletedRegionId;
		_ajax(controllers.updateDeliveryRegion,success,error);
	}
	
	function _del(id,success,error) {
		controllers.del.data.id=id;
		_ajax(controllers.del,success,error);
	}
	
	return {
		add:_add,
		update:_update,
		findRegion:_findRegion,
		findDeliveryRegionBySubiteId:_findDeliveryRegionBySubiteId,
		updateDeliveryRegion:_updateDeliveryRegion,
		del:_del,
		controllers:controllers
	};
});