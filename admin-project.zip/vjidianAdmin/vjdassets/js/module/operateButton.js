 define(['jquery'], function($) {
	/***********************************jinzheshengmodify 2016/11/2*************************************/
	var websiteroot = 'https://admin.vjidian.com';
	var opcontrollers = {
		getUrl:{url:websiteroot}
	};
	/***********************************jinzheshengmodify 2016/11/2*************************************/
	
	var _getEditBtnEl=function(id){
 		var $editEl=$('<a>',{"class":'edit',title:"编辑",id:"edit_"+id,href:"operate/edit/"+id,target:'_blank'});
		var $editIcon=$('<i>',{"class":'fa fa-edit operationIcon'});
		$editEl.append($editIcon);
		return $editEl;
	}

 	var _getViewBtnEl=function(id){
 		var $viewEl=$('<a>',{"class":'view',title:"查看",id:"view_"+id,href:"http://10.90.0.67:8080/product/detail/"+id,target:'_blank'});
		var $viewIcon=$('<i>',{"class":'fa fa-eye operationIcon'});
		$viewEl.append($viewIcon);
		return $viewEl;
	}

 	var _getDelBtnEl=function(id){
 		var $delEl=$('<a>',{"class":'delete',title:"删除",id:"del_"+id,"data-id":id});
		var $delIcon=$('<i>',{"class":'fa fa-trash-o operationIcon'});
		$delEl.append($delIcon);
		return $delEl;
	}
	var _getShowBtnEl=function(id){
 		var $showEl=$('<a>',{"class":'showDetail',title:"展开",id:"show_"+id,"data-id":id});
		var $showIcon=$('<i>',{"class":'fa fa-angle-down operationIcon'});
		$showEl.append($showIcon);
		return $showEl;
	}
	
	var _getUpdateBtnEl=function(data){
		var $updateEl=$('<a>',(typeof(data) == "undefined")?{"class":'update',title:"更新"}:data);	
	    var $updateIcon=$('<i>',{"class":'fa fa-check',style:"color:green;font-size:20px;"});
	    $updateEl.append($updateIcon)
		return $updateEl;
	}
	var _getCancelBtnEl=function(data){
		var $cancelEl=$('<a>',(typeof(data) == "undefined")?{"class":'cancel',title:"取消"} : data);	
	    var $cancelIcon=$('<i>',{"class":'fa fa-times',style:"color:red;font-size:20px;"});
	    $cancelEl.append($cancelIcon);
	    return $cancelEl;
	}
	
	var _getPencilEditBtnEl=function(id,title){
 		var $pencilEditEl=$('<a>',{"class":'pencilEdit',title:title,id:"pencilEdit_"+id});
		var $pencilEditIcon=$('<i>',{"class":'fa fa-pencil'});
		$pencilEditEl.append($pencilEditIcon);
		return $pencilEditEl;
	}
	
	var _getCleartBtnEl=function(data){
		var $clearEl=$('<a>',(typeof(data) == "undefined")?{"class":'clear',title:"清除"}:data);	
		var $clearIcon=$('<i>',{"class":'fa fa-eraser'});
		$clearEl.append($clearIcon);
		return $clearEl;
	}
	var _returnurl=function(){
		return opcontrollers.getUrl.url;
	}
	
	return {
		/***********************************jinzheshengmodify 2016/11/2*************************************/
		opcontrollers: opcontrollers,
		returnurl:_returnurl,
		/***********************************jinzheshengmodify 2016/11/2*************************************/
		getEditBtnEl:_getEditBtnEl,
		getViewBtnEl:_getViewBtnEl,
		getDelBtnEl:_getDelBtnEl,
		getUpdateBtnEl: _getUpdateBtnEl,
		getCancelBtnEl:_getCancelBtnEl,
		getPencilEditBtnEl:_getPencilEditBtnEl,
		getCleartBtnEl:_getCleartBtnEl,
		getPencilEditBtnEl:_getPencilEditBtnEl,
		getShowBtnEl:_getShowBtnEl
    };
});



