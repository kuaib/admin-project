define([ 'jquery' ], function($) {
	'use strict';
	var root='https://admin.vjidian.com/8002/virtualCategory';
	//定义全部请求的Controller
	var controllers = {
		addCategory:{url:root+'/add',type:'POST',dataType:'JSON',data:{}},
		updateCategory:{url:root+'/update',type:'POST',dataType:'JSON',data:{}},
		getPage:{url:root+'/page',type:'POST',dataType:'JSON',data:{}},
		deleteCategory:{url:root+'/delete',type:'POST',dataType:'JSON',data:{id:''}},
		getCategorySeo:{url:root+'/getCategorySeo',type:'POST',dataType:'JSON',data:{id:''}},
		updateCategorySeo:{ url:root+'/updateCategorySeo',type:'POST',dataType:'JSON',data:{}},
		exportCategory:{url:root+'/export',type:'POST',dataType:'JSON',data:{}},
		deleteExportFile:{url:root+'/deleteExportFile',type:"POST",dataType:'JSON',data:{}}
	};
	function _ajax(controller,success,error) {
		var ajaxOptions=$.extend(true,controller,{success:success,error:error});
		$.ajax(ajaxOptions);
	}
	function _addCategory(data,success,error){
		controllers.addCategory.data=data;
		_ajax(controllers.addCategory,success,error);
	}
	function _updateCategory(data,success,error){
		controllers.updateCategory.data=data;
		_ajax(controllers.updateCategory,success,error);
	}
	function _getPage(data,success,error) {
		controllers.getPage.data=data;
		_ajax(controllers.getPage,success,error);
	}
	function _deleteCategory(id,success,error) {
		controllers.deleteCategory.data.id=id;
		_ajax(controllers.deleteCategory,success,error);
	}
	function _updateCategorySearchable(id,searchable,success,error){
		controllers.updateCategorySearchable.data.id=id;
		controllers.updateCategorySearchable.data.searchable=searchable;
		_ajax(controllers.updateCategorySearchable,success,error);
	}
	function _updateCategoryShowable(id,showable,success,error){
		controllers.updateCategoryShowable.data.id=id;
		controllers.updateCategoryShowable.data.showable=showable;
		_ajax(controllers.updateCategoryShowable,success,error);
	}
	function _updateCategorySeo( data,success,error ){
		controllers.updateCategorySeo.data = 'data='+JSON.stringify(data);
		_ajax(controllers.updateCategorySeo,success,error);
	}
	function _getCategorySeo(id,success,error) {
		controllers.getCategorySeo.data.id=id;
		_ajax(controllers.getCategorySeo,success,error);
	}
	function _exportCategory( data,success,error ){
		controllers.exportCategory.data = data;
		_ajax(controllers.exportCategory,success,error);
	}
	
	function _deleteExportFile(data,success,error){
		controllers.deleteExportFile.data = data;
		_ajax(controllers.deleteExportFile,success,error);
	}
	return {
		addCategory:_addCategory,
		updateCategory:_updateCategory,
		getPage:_getPage,
		deleteCategory:_deleteCategory,
		updateCategorySearchable:_updateCategorySearchable,
		updateCategoryShowable:_updateCategoryShowable,
		getCategorySeo:_getCategorySeo,
		updateCategorySeo:_updateCategorySeo,
		exportCategory:_exportCategory,
		deleteExportFile:_deleteExportFile
	};
});