/**
 * 商品分类领域对象
 */
define([ 'jquery' ], function($) {
	"use strict";
	var root="https://admin.vjidian.com/305/category";
	
	//定义全部请求的Controller
	var controllers = {
		addCategory:{url:root+'/add',type:'POST',dataType:'JSON',data:{}},
		updateCategory:{url:root+'/update',type:'POST',dataType:'JSON',data:{}},
		getPage:{url:root+'/page',type:'POST',dataType:'JSON',data:{}},
		getCategorySeo:{url:root+'/getCategorySeo',type:'POST',dataType:'JSON',data:{id:''}},
		deleteCategory:{url:root+'/delete',type:'POST',dataType:'JSON',data:{id:''}},
		updateCategorySearchable:{url:root+'/updateCategorySearchable',type:'POST',dataType:'JSON',data:{id:'',searchable:''}},
		updateCategoryShowable:{url:root+'/updateCategoryShowable',type:'POST',dataType:'JSON',data:{id:'',showable:''}},
		getPriceRange:{url:root+'/getPriceRange',type:'POST',dataType:'JSON',data:{}},
		updatePriceRange:{url:root+'/updatePriceRange',type:'POST',dataType:'JSON',data:{}},
		updateCategorySeo:{ url:root+'/updateCategorySeo',type:'POST',dataType:'JSON',data:{}},
		exportCategory:{url:root+'/export',type:'POST',dataType:'JSON',data:{}},
		deleteExportFile:{url:root+'/deleteExportFile',type:"POST",dataType:'JSON',data:{}},
		getCategorySpec:{url:root+'/deleteExportFile',type:"POST",dataType:'JSON',data:{}}
	};
	function _ajax(controller,success,error) {
		var ajaxOptions=$.extend(true,controller,{success:success,error:error});
		$.ajax(ajaxOptions);
	}
	function _addCategory(data,success,error){
		controllers.addCategory.data=data;
		_ajax(controllers.addCategory,success,error);
	}
	function _updateCategory(data,success,error){
		controllers.updateCategory.data=data;
		_ajax(controllers.updateCategory,success,error);
	}
	function _getPage(data,success,error) {
		controllers.getPage.data=data;
		_ajax(controllers.getPage,success,error);
	}
	function _updateCategorySeo( data,success,error ){
		controllers.updateCategorySeo.data = 'data='+JSON.stringify(data);
		_ajax(controllers.updateCategorySeo,success,error);
	}
	function _getCategorySeo(id,success,error) {
		controllers.getCategorySeo.data.id=id;
		_ajax(controllers.getCategorySeo,success,error);
	}
	function _deleteCategory(id,success,error) {
		controllers.deleteCategory.data.id=id;
		_ajax(controllers.deleteCategory,success,error);
	}
	function _updateCategorySearchable(id,searchable,success,error){
		controllers.updateCategorySearchable.data.id=id;
		controllers.updateCategorySearchable.data.searchable=searchable;
		_ajax(controllers.updateCategorySearchable,success,error);
	}
	function _updateCategoryShowable(id,showable,success,error){
		controllers.updateCategoryShowable.data.id=id;
		controllers.updateCategoryShowable.data.showable=showable;
		_ajax(controllers.updateCategoryShowable,success,error);
	}
	function _getPriceRange(id,success,error){
		controllers.getPriceRange.data.id=id;
		_ajax(controllers.getPriceRange,success,error);
	}
	function _updatePriceRange(categoryId,priceRangeStr,success,error){
		controllers.updatePriceRange.data.categoryId=categoryId;
		controllers.updatePriceRange.data.priceRangeStr=priceRangeStr;
		_ajax(controllers.updatePriceRange,success,error);
	}
	function _exportCategory( data,success,error ){
		controllers.exportCategory.data = data;
		_ajax(controllers.exportCategory,success,error);
	}
	
	function _deleteExportFile(data,success,error){
		controllers.deleteExportFile.data = data;
		_ajax(controllers.deleteExportFile,success,error);
	}
	return {
		addCategory:_addCategory,
		updateCategory:_updateCategory,
		getPage:_getPage,
		getCategorySeo:_getCategorySeo,
		deleteCategory:_deleteCategory,
		updateCategorySearchable:_updateCategorySearchable,
		updateCategoryShowable:_updateCategoryShowable,
		getPriceRange:_getPriceRange,
		updatePriceRange:_updatePriceRange,
		updateCategorySeo:_updateCategorySeo,
		exportCategory:_exportCategory,
		deleteExportFile:_deleteExportFile
	};
});