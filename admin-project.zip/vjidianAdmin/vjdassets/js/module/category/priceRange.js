/**
 * 
 */
define(['js/module/category/categoryController','js/module/operateButton','nice-validator-zh_CN'], function(categoryController,operateButton) {

	
	
	var _addPriceRange=function(e){
		e.preventDefault();
		//如果多个字段name相同，并且要分别显示验证消息，就要为他们设置不同的id
		var id=Math.round(Math.random() * 1000000);
		var $tr=$('<tr>');
		var $td_minPrice=$('<td>').append($('<input>',{"class":"form-control input-sm",id:'minPrice_new_'+id,type:'text','style':'width:150px',name:'minPrice',"data-rule":"required;"}));
		var $td_maxPrice=$('<td>').append($('<input>',{"class":"form-control input-sm",id:'maxPrice_new_'+id,type:'text','style':'width:150px',name:'maxPrice',"data-rule":"required;"}));
		var $td_op=$('<td>',{"class":"text-center"}).append(operateButton.getDelBtnEl());
		$tr.append($td_minPrice).append($td_maxPrice).append($td_op);
		$('tbody',$("#tbl_priceRange")).append($tr);
	}
	
	var _update=function(){
		//赋值goods对象
		var priceRanges=[];
		$('tbody>tr',$('#tbl_priceRange')).each(function(index){
			var $tr=$(this);
			var minPrice=$tr.find('[name=minPrice]').val();
			var maxPrice=$tr.find('[name=maxPrice]').val();
			if(minPrice!="" && maxPrice!=""){
				var item={
					minPrice:minPrice,
					maxPrice:maxPrice
				};
				priceRanges.push(item)
			}
		})
		var submitSuccess=function(data){
			var tip=data.tip;
			if(data.result){
				$.Success(tip);
				window.setInterval(function(){
					location.href=categoryController.controllers.show.url;
			    },2000);
			}
			else{
				$.Warn(tip);
			}
		};
		
		var categoryid=$("#hid_category").val();
		
		if(priceRanges.length>0){
			categoryController.updatePriceRange(categoryid,priceRanges,submitSuccess)
		}
		else{
			$.Warn("请先填写价格区间");
		}		
	}
	
	return {
		addPriceRange:_addPriceRange,
		update:_update,
	}
})