define([ 'jquery','app' ], function($) {
	'use strict';
	//var root='https://admin.vjidian.com/8001/category';
	var root=website_address;
	//定义全部请求的Controller
	var controllers = {
		//根据父亲Id查询子分类
		//getChilden:{url:root+'/getChildren',data:{}},
		getChilden:{url:root+'vjidian-category/categoryMenu/listPageByParentId',data:{}},
		add:{url:root+'add',data:{}},
		addView:{url:root+'addView/'},
		editView:{url:root+'editView/'},
		update:{url:root+'update',data:{}},
		getPage:{url:root+'page',data:{}},
		getPageMoveTree:{url:root+'pageMoveTree',data:{}},
		show:{url:root+'show'},
		showTree:{url:root+'showTree/'},
		del:{url:root+'delete',data:{id:''}},
		updatePriceRange:{url:root+'updatePriceRange',data:{}},
		getPriceRange:{url:root+'getPriceRange/',data:{}},
		getCategorySeo:{url:root+'getCategorySeo',data:{id:''}},
		updateCategorySearchable:{url:root+'updateCategorySearchable',data:{id:'',searchable:''}},
		updateCategoryShowable:{url:root+'updateCategoryShowable',data:{id:'',showable:''}},
		updateCategorySeo:{ url:root+'updateCategorySeo',data:{}},
		exportCategory:{url:root+'export',data:{}},
		deleteExportFile:{url:root+'deleteExportFile',data:{}},
		getCategorySpec:{url:root+'deleteExportFile',data:{}},
		//批量更新序列
		batchUpdateSequence:{url:root+'batchUpdateSequence',data:{}},
		//批量更新序列
		calculateBrands:{url:root+'calculateBrands',data:{}},
	};
	function _ajax(controller,success,error) {
		var ajaxOptions=$.extend(true,controller,{
			success:success,
			error:error,
			type: 'POST',
			dataType: 'JSON'
		});
		$.ajax(ajaxOptions);
	}
	
	function _getChilden(data,success,error){
		controllers.getChilden.data=data;
		_ajax(controllers.getChilden,success,error);
	}
	
	function _add(data,success,error){
		controllers.add.data=data;
		_ajax(controllers.add,success,error);
	}
	function _update(data,success,error){
		controllers.update.data=data;
		_ajax(controllers.update,success,error);
	}
	function _getPage(data,success,error) {
		controllers.getPage.data=data;
		_ajax(controllers.getPage,success,error);
	}
	function _getPageMoveTree(data,success,error) {
		controllers.getPageMoveTree.data=data;
		_ajax(controllers.getPageMoveTree,success,error);
	}
	function _updateCategorySeo( data,success,error ){
		controllers.updateCategorySeo.data = 'data='+JSON.stringify(data);
		_ajax(controllers.updateCategorySeo,success,error);
	}
	function _getCategorySeo(id,success,error) {
		controllers.getCategorySeo.data.id=id;
		_ajax(controllers.getCategorySeo,success,error);
	}
	function _del(id,success,error) {
		controllers.del.data.id=id;
		_ajax(controllers.del,success,error);
	}
	function _updateCategorySearchable(id,searchable,success,error){
		controllers.updateCategorySearchable.data.id=id;
		controllers.updateCategorySearchable.data.searchable=searchable;
		_ajax(controllers.updateCategorySearchable,success,error);
	}
	function _updateCategoryShowable(id,showable,success,error){
		controllers.updateCategoryShowable.data.id=id;
		controllers.updateCategoryShowable.data.showable=showable;
		_ajax(controllers.updateCategoryShowable,success,error);
	}
	function _getPriceRange(id,success,error){
		controllers.getPriceRange.data.id=id;
		_ajax(controllers.getPriceRange,success,error);
	}
	
	function _updatePriceRange(categoryId,data,success,error){
		controllers.updatePriceRange.data.categoryId=categoryId;
		controllers.updatePriceRange.data.priceRangeJSON=JSON.stringify(data);
		_ajax(controllers.updatePriceRange,success,error);
	};
	
	
	function _exportCategory( data,success,error ){
		controllers.exportCategory.data = data;
		_ajax(controllers.exportCategory,success,error);
	}
	
	function _deleteExportFile(data,success,error){
		controllers.deleteExportFile.data = data;
		_ajax(controllers.deleteExportFile,success,error);
	}
	function _batchUpdateSequence(data,success,error){
		controllers.batchUpdateSequence.data.sequences = data;
		_ajax(controllers.batchUpdateSequence,success,error);
	}
	function _calculateBrands(data,success,error){
		controllers.calculateBrands.data = data;
		_ajax(controllers.calculateBrands,success,error);
	}
	
	return {
		controllers:controllers,
		getChilden:_getChilden,
		add:_add,
		update:_update,
		getPage:_getPage,
		getPageMoveTree:_getPageMoveTree,
		del:_del,
		updatePriceRange:_updatePriceRange,
		
		getCategorySeo:_getCategorySeo,
		updateCategorySearchable:_updateCategorySearchable,
		updateCategoryShowable:_updateCategoryShowable,
		getPriceRange:_getPriceRange,
		updateCategorySeo:_updateCategorySeo,
		exportCategory:_exportCategory,
		deleteExportFile:_deleteExportFile,
		batchUpdateSequence:_batchUpdateSequence,
		calculateBrands:_calculateBrands,
	};
});