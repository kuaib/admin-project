/**
 * 分类模板
 */
define(['jquery'], function($) {
	'use strict';
	var root='https://admin.vjidian.com/8001/categorySchema';
	var controllers = {
		show:{url:root+'/show/'},
		addExtendedAttributeToSchema:{url:root+'/addExtendedAttributeToSchema',data:{}},
		deleteExtendedAttributeFromSchema:{url:root+'/deleteExtendedAttributeFromSchema',data:{categoryid:'',attributeid:''}},
		addSpecificationToSchema:{url:root+'/addSpecificationToSchema',data:{}},
		chooseSpecificationToSchema:{url:root+'/chooseSpecificationToSchema',data:{}},
		deleteSpecificationFromSchema:{url:root+'/deleteSpecificationFromSchema',data:{categoryid:'',specificationid:''}},
		addParameterGroupToSchema:{url:root+'/addParameterGroupToSchema',data:{}},
		deleteParameterGroupFromSchema:{url:root+'/deleteParameterGroupFromSchema',data:{categoryid:'',groupid:''}},
		deleteParameterFromSchema:{url:root+'/deleteParameterFromSchema',data:{categoryid:'',specificationid:''}},
		deleteOptionFromExtendedAttribute:{url:root+'/deleteOptionFromExtendedAttribute',data:{optionid:''}},
		updateOptionInExtendedAttribute:{url:root+'/updateOptionInExtendedAttribute',data:{optionid:'',option:'',optionEN:''}}
	};
	function _ajax(controller,success,error) {
		var ajaxOptions=$.extend(true,controller,{success:success,error:error,type:'POST',dataType:'JSON'});
		$.ajax(ajaxOptions);
	}
	function _addExtendedAttributeToSchema(data,success,error){
		controllers.addExtendedAttributeToSchema.data=data;
		_ajax(controllers.addExtendedAttributeToSchema,success,error);
	}
	function _deleteExtendedAttributeFromSchema(categoryid,attributeid,success,error){
		var data={categoryid:categoryid,attributeid:attributeid};
		controllers.deleteExtendedAttributeFromSchema.data=data;
		_ajax(controllers.deleteExtendedAttributeFromSchema,success,error);
	}
	function _addSpecificationToSchema(data,success,error){
		controllers.addSpecificationToSchema.data=data;
		_ajax(controllers.addSpecificationToSchema,success,error);
	}
	function _chooseSpecificationToSchema(data,success,error){
		controllers.chooseSpecificationToSchema.data=data;
		_ajax(controllers.chooseSpecificationToSchema,success,error);
	}
	function _deleteSpecificationFromSchema(categoryid,specificationid,success,error){
		var data={categoryid:categoryid,specificationid:specificationid};
		controllers.deleteSpecificationFromSchema.data=data;
		_ajax(controllers.deleteSpecificationFromSchema,success,error);
	}
	function _addParameterGroupToSchema(data,success,error){
		controllers.addParameterGroupToSchema.data=data;
		_ajax(controllers.addParameterGroupToSchema,success,error);
	}
	function _deleteParameterGroupFromSchema(categoryid,groupid,success,error){
		var data={categoryid:categoryid,groupid:groupid};
		controllers.deleteParameterGroupFromSchema.data=data;
		_ajax(controllers.deleteParameterGroupFromSchema,success,error);
	}
	function _deleteParameterFromSchema(categoryid,parameterid,success,error){
		var data={categoryid:categoryid,parameterid:parameterid};
		controllers.deleteParameterFromSchema.data=data;
		_ajax(controllers.deleteParameterFromSchema,success,error);
	}
	function _deleteOptionFromExtendedAttribute(optionid,success,error){
		controllers.deleteOptionFromExtendedAttribute.data.optionid=optionid;
		_ajax(controllers.deleteOptionFromExtendedAttribute,success,error);
	}
	function _updateOptionInExtendedAttribute(data,success,error){
		controllers.updateOptionInExtendedAttribute.data=data;
		_ajax(controllers.updateOptionInExtendedAttribute,success,error);
	}
	function _show(categoryId){
		return controllers.show.url + categoryId;
	}
	return {
		controllers:controllers,
		show:_show,
		addExtendedAttributeToSchema:_addExtendedAttributeToSchema,
		deleteExtendedAttributeFromSchema:_deleteExtendedAttributeFromSchema,
		addSpecificationToSchema:_addSpecificationToSchema,
		chooseSpecificationToSchema:_chooseSpecificationToSchema,		
		deleteSpecificationFromSchema:_deleteSpecificationFromSchema,
		addParameterGroupToSchema:_addParameterGroupToSchema,
		deleteParameterGroupFromSchema:_deleteParameterGroupFromSchema,
		deleteParameterFromSchema:_deleteParameterFromSchema,
		deleteOptionFromExtendedAttribute:_deleteOptionFromExtendedAttribute,
		updateOptionInExtendedAttribute:_updateOptionInExtendedAttribute
	};
});