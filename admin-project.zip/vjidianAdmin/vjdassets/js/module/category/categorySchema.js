require(['jquery',
		'js/module/category/categorySchemaController',
		'js/module/product/specification',
		'js/module/bootstrap-dialog',
		'multi-select',
		'nice-validator-zh_CN'], 
		function($, schema, specificationController, dialog){

		function ui_reload(){
			location.reload(true);
		}

		//扩展属性
		var eRowId = 10000;		
		function ui_addERow(e){
			e.preventDefault();
			var row = $('<tr>',{class:'eItem'});
			var backendLabelCell = $('<td>',{class:'col-md-2 form-inline'});
			backendLabelCell.append($('<input>',{type:'hidden',name:'attributeId',val:0}));
			backendLabelCell.append($('<input>',{type:'text',name:'backendLabel',id:'txt_'+eRowId,class:'form-control','data-rule':'required','data-msg-required':'请输入属性名称',placeholder:'请输入属性名称'}));
			backendLabelCell.append($('<input>',{type:'hidden',name:'attributeId',val:0}));
			var messageBox = $('<label>',{class:'control-label'});
			messageBox.attr('for','txt_'+eRowId);
			messageBox.append($('<span>',{class:'msg-box'}));
			backendLabelCell.append(messageBox);
			row.append(backendLabelCell);

			var frontLabelCell = $('<td>',{class:'col-md-2'});
			frontLabelCell.append($('<input>',{type:'text',name:'frontLabel',class:'form-control',placeholder:'默认同属性名称'}));
			row.append(frontLabelCell);

			var englishLabelCell = $('<td>',{class:'col-md-2'});
			englishLabelCell.append($('<input>',{type:'text',name:'englishLabel',class:'form-control',placeholder:''}));
			row.append(englishLabelCell);

			var attributeTypeCell = $('<td>',{class:'col-md-2 form-inline'});
			var selector = $('<select>',{name:'attributeType',class:'form-control attribute-type'});
			var option = $('<option>',{val:'',text:'请选择'});
			selector.append(option);
//			<!--#set(Map<Integer,String> attributeType)-->
//			<!--#for(entry : attributeType)-->
			option = $('<option>',{val:'1',text:'文本'});	
			selector.append(option);
			option = $('<option>',{val:'2',text:'日期'});
			selector.append(option);
			option = $('<option>',{val:'3',text:'金额'});
			selector.append(option);
			option = $('<option>',{val:'4',text:'整数'});
			selector.append(option);
			option = $('<option>',{val:'5',text:'HTML文本'});
			selector.append(option);
			option = $('<option>',{val:'6',text:'多项选择'});
			selector.append(option);
//			<!--#end-->
			attributeTypeCell.append(selector);			
			var hiddenSelector = $('<select>',{name:'optionList',style:'display:none'});
			attributeTypeCell.append(hiddenSelector);
			var hiddenENSelector = $('<select>',{name:'optionENList',style:'display:none'});
			attributeTypeCell.append(hiddenENSelector);
			var editButton = ui_assembleFAbutton('btn green control-label editOption none','编辑选择项','fa fa-plus','编辑选择项');
			editButton.hide();
			attributeTypeCell.append(editButton);
			row.append(attributeTypeCell);

			var defaultValueCell = $('<td>',{class:'col-md-1'});
			defaultValueCell.append($('<input>',{type:'text',name:'defaultValue',class:'form-control',val:''}));
			row.append(defaultValueCell);

			var searchableCell = $('<td>',{class:'col-md-1'});
			searchableCell.append($('<input>',{type:'checkbox',name:'searchable'}));
			row.append(searchableCell);

			var requiredCell = $('<td>',{class:'col-md-1'});
			requiredCell.append($('<input>',{type:'checkbox',name:'required'}));
			row.append(requiredCell);

			var frontDisplayCell = $('<td>',{class:'col-md-1'});
			frontDisplayCell.append($('<input>',{type:'checkbox',name:'frontDisplay',checked:'checked'}));
			row.append(frontDisplayCell);

			var operationCell = $('<td>',{class:'col-md-1'});
			var shiftUpButton = ui_assembleFAbutton('shiftup','上移一位','fa fa-arrow-up fa-ex-arrow','');
			operationCell.append(shiftUpButton);
			operationCell.append('&nbsp;');
			var shiftDownButton = ui_assembleFAbutton('shiftdown','下移一位','fa fa-arrow-down fa-ex-arrow','');
			operationCell.append(shiftDownButton);
			operationCell.append('&nbsp;');
			var deleteButton = ui_assembleFAbutton('delete','删除','fa fa-times fa-ex-times','');
			operationCell.append(deleteButton);
			row.append(operationCell);
			row.appendTo('#tbl_extendedAttribute tbody');
			eRowId++;
		}

		function ui_eaSubmit(){

			//当前登录系统用户id
			var longinUserIdValue = $('#currentLonginUserId').val();
			//当前登录系统用户角色id
			var longinUserRoleIdValue = $('#currentLonginUserRoleId').val();
			//要操作数据创建人id
			var createrUserIdValue = $('#iseditcreatvalue').val();
			//要操作数据创建人角色id
			var createrUserRoleIdValue = $('#iseditrolevalue').val();
			
			//当前数据是否被操作
			var iseditvalue = $('#iseditvalue').val();
			
			if(iseditvalue ==1){
				alert("厂家角色只能操作自己的数据！");
				return;
			}else{
			
				// 如果没有扩展属性
				if($('#form_extendedAttribute .eItem').length==0){
					return;
				}
				var validateSelect = true;
				$('#form_extendedAttribute select').each(function(){
					var that = $(this);
					if(that.val()==''){
						$.Error('请选择属性类型');
						validateSelect = false;
					}
				});

				if(!validateSelect){
					return false;
				}

				var data = {categoryid:0,attributeid:[],backendlabel:[],frontlabel:[],englishlabel:[],attributetype:[],searchable:[],required:[],frontdisplay:[],sort:[],option:[],optionEN:[],optionid:[],defaultvalue:[]};
				data.categoryid = $('#hid_categoryid').val();
				var index = 0;
				$('#form_extendedAttribute .eItem').each(function(){
					var me = $(this);
					data.attributeid[index]=me.find('input[name=attributeId]').val();
					data.backendlabel[index]=me.find('input[name=backendLabel]').val();
					data.defaultvalue[index]=me.find('input[name=defaultValue]').val();
					data.frontlabel[index]=me.find('input[name=frontLabel]').val();
					data.englishlabel[index]=me.find('input[name=englishLabel]').val();
					data.attributetype[index]=me.find('select[name=attributeType]').val();
					data.searchable[index]=me.find('input[name=searchable]').is(':checked');
					data.required[index]=me.find('input[name=required]').is(':checked');
					data.frontdisplay[index]=me.find('input[name=frontDisplay]').is(':checked');
					if(data.frontlabel[index] == ''){
						data.frontlabel[index] = data.backendlabel[index];
					}
					var option = '';
					var optionEN = '';
					var optionid = '';
					var attributetype = data.attributetype[index];
					if(attributetype == 6){
						var optionList = me.find('select[name=optionList]');
						var optionENList = me.find('select[name=optionENList]').find('option');		
						var optionIndex = 0;
						optionList.find('option').each(function(index, item){
							var optionItem = $(this);
							if(optionIndex == 0){
								optionEN = $(optionENList[index]).text();
								option = optionItem.text();
								optionid = optionItem.val();
							}else{
								optionEN = option + '|' + $(optionENList[index]).text();
								option = option + '|' + optionItem.text();
								optionid = optionid + '|' + optionItem.val();
							}
							optionIndex = optionIndex + 1;
						});
					}
					data.optionEN[index] = optionEN;
					data.option[index] = option;
					data.optionid[index] = optionid;
					index=index+1;
				});

				schema.addExtendedAttributeToSchema(data,success);
				function success(data){
					if(data){
						if(data.result){
							setTimeout(ui_reload,2500);
							$.Success(data.tip);
						}else{
							$.Error(data.tip);
						}
					}
				}
			
			}
				

			
		}

		function ui_deleteERow(e){
			e.preventDefault();
									
			//当前登录系统用户id
			var longinUserIdValue = $('#currentLonginUserId').val();
			//当前登录系统用户角色id
			var longinUserRoleIdValue = $('#currentLonginUserRoleId').val();
			//要操作数据创建人id
			var createrUserIdValue = $('#currentLonginCreaterUserValue').val();
			//要操作数据创建人角色id
			var createrUserRoleIdValue = $('#currentLonginCreaterUserRoleValue').val();
						
			//当前登录系统用户角色厂家:4
			if(longinUserRoleIdValue == 4){
				//当然操作数据角色是否和登录系统用户角色相同
				if(longinUserRoleIdValue == createrUserRoleIdValue){
					//alert("当前登录系统用户角色："+longinUserRoleIdValue+"当前登录系统用户id："+longinUserIdValue+"当前操作数据用户角色id："+createrUserRoleIdValue+"当前操作数据用户id："+createrUserIdValue);
					//当然操作数据创建人id是否和登录系统用户id相同
					if(longinUserIdValue != createrUserIdValue){
						alert("厂家角色只能操作自己的数据！");
						return;
					}
				}else{
					alert("厂家角色只能操作自己的数据！");
					return;
				}
			}			
			
			var eItem = $(this).parents('.eItem');
			var attributeid = eItem.find('input[name=attributeId]').val();
			if(attributeid == 0){
				eItem.remove();
			}else{
				var categoryid = $('#hid_categoryid').val();
				function success(data){
					if(data){
						if(data.result){
							eItem.remove();										
							$.Success(data.tip);							
						}else{
							$.Error(data.tip);
						}
					}
				}
			schema.deleteExtendedAttributeFromSchema(categoryid,attributeid,success);
			}
		}

		function ui_shiftUpERow(e){
			e.preventDefault();
			var currentRow = $(this).parents('.eItem');
			var prevRow = currentRow.prev();
			if(prevRow){
				currentRow.insertBefore(prevRow);
			}
		}

		function ui_shiftDownERow(e){
			e.preventDefault();
			var currentRow = $(this).parents('.eItem');
			var nextRow = currentRow.next();
			if(nextRow){
				currentRow.insertAfter(nextRow);
			}			
		}

		

		function ui_editOptionERow(e){
			e.preventDefault();
							
			var that = $(this);			
			var optionList = that.parent().find('select[name=optionList]');			
			var optionENList = that.parent().find('select[name=optionENList]');
			var optionENArray = optionENList.find('option');
			optionList.find('option').each(function(index,item){
				var me = $(this);
				var row = $('<tr>',{class:'optionItem'});
				row.append($('<td>',{class:'option',text:me.text()}));
				row.append($('<td>',{class:'optionEN',text:$(optionENArray[index]).text()}));
				var operationCell = $('<td>');
				operationCell.append($('<input>',{type:'hidden',name:'optionId',val:me.val()}));
				var deleteButton = $('<a>',{class:'delete',href:'javascript:;',title:'删除','data-optionid':me.val()});
				deleteButton.append($('<i>',{class:'fa fa-times fa-ex-times'}));
				operationCell.append(deleteButton);
				row.append(operationCell);
				row.appendTo('#tbl_optionHolder tbody');
			});
			dialog.alert({
				title: '编辑选择项',
				message: $('#sec_eaSelect'),
	            closable: true,
	            buttonLabel: '确定',
	            callback: function (result, dialogObj) {
            		optionList.html('');
            		optionENList.html('');
            		$('#tbl_optionHolder .optionItem').each(function(){
            			var row = $(this);
            			var option = row.find('.option').text();          			
            			var optionid = row.find('input[name=optionId]').val();
            			var optionItem = $('<option>',{val:optionid,text:option});
            			optionList.append(optionItem);
            			var optionEN = row.find('.optionEN').text();
            			var optionENItem = $('<option>',{val:optionid,text:optionEN});
            			optionENList.append(optionENItem);
            		});
            		$('#txt_addOption').val('');
            		$('#txt_addOptionEN').val('');
            		$('#tbl_optionHolder tbody').html('');
            		$('#sec_eaSelect').appendTo('#pnl_eaEditOption');
				}
			});
		}

		function ui_updateOptionERow(e){
			e.preventDefault();
			var that = $(this);
			var optionid = that.data('optionid');
			if(optionid==0){
				that.parent().parent().remove();
			}else{
				function success(data){
					if(data){
						if(data.result){
							that.parent().parent().remove();
						}else{
							$.Error('选择项删除不成功');
						}
					}
				}
				schema.deleteOptionFromExtendedAttribute(optionid, success);
			}			
		}

		function ui_deleteOptionERow(e){
			e.preventDefault();
			var that = $(this);
			var optionid = that.data('optionid');
			if(optionid==0){
				that.parent().parent().remove();
			}else{
				function success(data){
					if(data){
						if(data.result){
							that.parent().parent().remove();
							$.Success(data.tip);
						}else{
							//$.Error('选择项删除不成功');
							$.Error(data.tip);
						}
					}
				}
				schema.deleteOptionFromExtendedAttribute(optionid, success);
			}			
		}

		function ui_selectValidate(){
			var that = $(this);
			var attributeType = that.val();			
			if(attributeType==''){
				$.Error('请选择属性类型');
			}
		}

		function ui_toggleEditButton(){
			var that = $(this);
			var attributeType = that.val();
			
			//下拉列表选项值
			$('#attributetypeselectvalue').val(attributeType);
			
			//下拉列表默认值
			var selectdefaule = $('#attributetypeselectvaluedefaule').val();

			
			//当前登录系统用户id
			var longinUserIdValue = $('#currentLonginUserId').val();
			//当前登录系统用户角色id
			var longinUserRoleIdValue = $('#currentLonginUserRoleId').val();
			//要操作数据创建人id
			var createrUserIdValue = $('#iseditcreatvalue').val();
			//要操作数据创建人角色id
			var createrUserRoleIdValue = $('#iseditrolevalue').val();
			
			if(createrUserIdValue.length != 0 && createrUserRoleIdValue.length != 0){
				
				//当前登录系统用户角色厂家:4
				if(longinUserRoleIdValue == 4){
					//当然操作数据角色是否和登录系统用户角色相同
					if(longinUserRoleIdValue == createrUserRoleIdValue){
						//当然操作数据创建人id是否和登录系统用户id相同
						if(longinUserIdValue == createrUserIdValue){					
							if($('#iseditvalue').val() == 0){
								$('#iseditvalue').val('0');
							   }				
						}else{
							if(attributeType != selectdefaule){  
							   $('#iseditvalue').val('1');
							}else{
							   if($('#iseditvalue').val() == 0){
								$('#iseditvalue').val('0');
							   }
							}  
						}
					}else{
						
						if(attributeType != selectdefaule){   
							   $('#iseditvalue').val('1');
						}else{
							   
							$('#iseditvalue').val('0');
							   
						} 
					}
				}

			}


			var editButton = that.parent().find('.editOption');
			if(attributeType == 6){
				editButton.show();
			}else{
				editButton.hide();
			}			
		}

		function ui_addOptionToEA(){
			var option = $('#txt_addOption');
			var optionEN = $('#txt_addOptionEN');
			var text = option.val();
			if(text == ''){
				$.Warn('请输入值');
			}else{
				var textEN = optionEN.val()
				if(textEN == ''){
					textEN = text;
				}
				var row = $('<tr>',{class:'optionItem'});
				row.append($('<td>',{class:'option',text:text}));
				row.append($('<td>',{class:'optionEN',text:textEN}));
				var operationCell = $('<td>');
				operationCell.append($('<input>',{type:'hidden',name:'optionId',val:0}));
				var deleteButton = $('<a>',{class:'delete',href:'javascript:;',title:'删除','data-optionid':0});
				deleteButton.append($('<i>',{class:'fa fa-times fa-ex-times'}));
				operationCell.append(deleteButton);
				row.append(operationCell);
				row.appendTo('#tbl_optionHolder tbody');

				option.val('');
				optionEN.val('');
			}
		}

		//规格
		$('#sel_specification').multiSelect({
			keepOrder:true,
			selectableHeader:'待选规格',
			selectionHeader:'已选规格'
		});

		var savedOptionId = [];
//		<!--#if(categorySpecification)-->
//			<!--#set(List<Attribute> categorySpecification)-->
//			<!--#for(specification:categorySpecification)-->
//			savedOptionId.push(${specification.id});
//			<!--#end-->			
//		<!--#end-->		
		function ui_addSRow(e){
			e.preventDefault();
			dialog.alert({
				title: '选择规格',
				message: $('#sec_specSelect'),
	            closable: true,
	            buttonLabel: '确定',
	            callback: function (result, dialogObj) {
	            	if(result){
	            		var optionIdList = $('#sel_specification').val();
			    		var optionList = $('#sel_specification option:selected');
			    		var optionFrontLabelMap = data_optionListToMap($('#sel_specificationFrontLabel option'));
			    		var optionEnglishLabelMap = data_optionListToMap($('#sel_specificationEnglishLabel option'));
			    		if(optionIdList){
			    			var needSave = 0;
			    			for (var i = 0; i < optionIdList.length; i++) {
			    				var optionId = Number(optionIdList[i]);
			    				if($.inArray(optionId,savedOptionId) == -1){
			    					var backendLabel = $(optionList[i]).text();
			    					var frontLabel = optionFrontLabelMap[optionId];
			    					var englishLabel = optionEnglishLabelMap[optionId];
			    					ui_assembleSRow(optionId, backendLabel, frontLabel, englishLabel);
			    					savedOptionId.push(optionId);
			    					needSave++;
			    				}

			    			}
			    			if(needSave > 0){
			    				$('#lbl_saveSpecification').text('('+needSave+'种规格待保存)');
			    			}
			    		}	            		
	            	}
	            	$('#sec_specSelect').appendTo('#pnl_specSelect');
				}
			});			
		}

		function data_optionListToMap(optionList){
			var map = [];
			$.each(optionList, function(index, option){
				$option = $(option);
				map[$option.val()] = $option.text();
			});
			return map;
		}

		function ui_assembleSRow(optionId, backendLabel, frontLabel, englishLabel){
			var row = $('<tr>',{class:'sItem'});
			var backendLabelCell = $('<td>',{class:'col-md-3'});
			backendLabelCell.append($('<input>',{type:'hidden',name:'isAdded',val:1}));
			backendLabelCell.append($('<input>',{type:'hidden',name:'specificationId',val:optionId}));
			backendLabelCell.append(backendLabel);
			row.append(backendLabelCell);

			var frontLabelCell = $('<td>',{class:'col-md-3'});
			frontLabelCell.append(frontLabel);
			row.append(frontLabelCell);

			var englishLabelCell = $('<td>',{class:'col-md-3'});
			englishLabelCell.append(englishLabel);
			row.append(englishLabelCell);

			var operationCell = $('<td>',{class:'col-md-3'});
			var shiftUpButton = ui_assembleFAbutton('shiftup','上移一位','fa fa-arrow-up fa-ex-arrow','');
			operationCell.append(shiftUpButton);
			operationCell.append('&nbsp;');
			var shiftDownButton = ui_assembleFAbutton('shiftdown','下移一位','fa fa-arrow-down fa-ex-arrow','');
			operationCell.append(shiftDownButton);
			operationCell.append('&nbsp;');
			var editButton = ui_assembleFAbutton('edit','编辑','fa fa-edit','');
			operationCell.append(editButton);
			operationCell.append('&nbsp;');
			var deleteButton = ui_assembleFAbutton('delete','删除','fa fa-times fa-ex-times','');
			operationCell.append(deleteButton);
			row.append(operationCell);
			row.appendTo('#tbl_specification tbody');					
		}

		function ui_deleteSRow(e){
			e.preventDefault();
			
			//当前登录系统用户id
			var longinUserIdValue = $('#currentLonginUserId').val();
			//当前登录系统用户角色id
			var longinUserRoleIdValue = $('#currentLonginUserRoleId').val();
			//要操作规格数据创建人id
			var createrGuigeUserIdValue = $('#currentLonginCreaterGuigeUserValue').val();
			//要操作规格数据创建人角色id
			var createrGuigeUserRoleIdValue = $('#currentLonginCreaterGuigeUserRoleValue').val();
						
			//当前登录系统用户角色厂家:4
			if(longinUserRoleIdValue == 4){
				//当然操作数据角色是否和登录系统用户角色相同
				if(longinUserRoleIdValue == createrGuigeUserRoleIdValue){
					//alert("当前登录系统用户角色："+longinUserRoleIdValue+"当前登录系统用户id："+longinUserIdValue+"当前操作数据用户角色id："+createrGuigeUserRoleIdValue+"当前操作数据用户id："+createrGuigeUserIdValue);
					//当然操作数据创建人id是否和登录系统用户id相同
					if(longinUserIdValue != createrGuigeUserIdValue){
						alert("厂家角色只能操作自己的数据！");
						return;
					}
				}else{
					alert("厂家角色只能操作自己的数据！");
					return;
				}
			}
			
			var sItem = $(this).parents('.sItem');
			var specificationId = sItem.find('input[name=specificationId]').val();
			var isAdded = sItem.find('input[name=isAdded]').val();
			if(isAdded == 1){
				sItem.remove();
			}else{
				savedOptionId.splice($.inArray(specificationId,savedOptionId),1);
				var categoryid = $('#hid_categoryid').val();
				
				function success(data){
					if(data){
						if(data.result){
							sItem.remove();
							$.Success(data.tip);							
						}else{
							$.Error(data.tip);
						}
					}
				}
				schema.deleteSpecificationFromSchema(categoryid,specificationId,success);
			}			
		}

		function ui_editSRow(e){
			e.preventDefault();
			var sItem = $(this).parents('.sItem');
			var specificationId = sItem.find('input[name=specificationId]').val();
			ui_update(specificationId);
		}

		function ui_sSubmit(){
			if($('#tbl_specification .sItem').length==0){
				return;
			}
			var data = {categoryid:0,specificationid:[]};
			data.categoryid = $('#hid_categoryid').val();
			var formdata = $('#form_specification').serializeObject();
			if($.isArray(formdata.specificationId)){
				data.specificationid = formdata.specificationId;
			}else{
				data.specificationid[0] = formdata.specificationId;
			}
			schema.chooseSpecificationToSchema(data,success);
			function success(data){
				if(data){
					if(data.result){
						setTimeout(ui_reload,2500);
						$.Success(data.tip);
					}else{
						$.Error(data.tip);
					}
				}
			}
		}

		function ui_shiftUpSRow(e){
			e.preventDefault();
			var currentRow = $(this).parents('.sItem');
			var prevRow = currentRow.prev();
			if(prevRow){
				currentRow.insertBefore(prevRow);
			}
		}

		function ui_shiftDownSRow(e){
			e.preventDefault();
			var currentRow = $(this).parents('.sItem');
			var nextRow = currentRow.next();
			if(nextRow){
				currentRow.insertAfter(nextRow);
			}			
		}

		function ui_formReset(){
			$('#tbl_spec_popup tbody').html('');
		    $('#hid_id').val(0);
			$('#txt_frontlabel').val('');
			$('#txt_backendlabel').val('');
			$('#txt_englishlabel').val('');
			$('#frm_spec').appendTo('#pnl_form');
		}

		function ui_addSpecification(){
			dialog.alert({
				title: '新增规格',
				message: $('#frm_spec'),
	            closable: true,
	            buttonLabel: '保存',
	            callback: function (result, dialogObj) {
	            	if(result){
	            		function success(data){
							if(data){
								if(data.result){
									$.Success(data.tip);
									var spec = $('#frm_spec').serializeObject();
									ui_assembleSRow(data.id, spec.backendlabel, spec.frontlabel, spec.englishlabel);
			    					savedOptionId.push(Number(data.id));
								}else{
									$.Error(data.tip);
								}
							}
							ui_formReset();				
						}
	            		var data = $('#frm_spec').serializeObject();
	            		if(data.backendlabel!=''){
		            		data = data_assembleSData(data);
		            		data.categoryid = $('#hid_categoryid').val();
		        			schema.addSpecificationToSchema(data,success);
	        			}else{
	        				ui_formReset();
	        			}
	            	}else{
	            		ui_formReset();
	            	}	            	
				}
			});
		}

		function data_assembleSData(data){
			if(!$.isArray(data.option)){
				data.option = [data.option];
			}
			if(!$.isArray(data.englishoption)){
				data.englishoption = [data.englishoption];
			}
			if(!$.isArray(data.optionid)){
				data.optionid = [data.optionid];
			}
			return data;
		}

		function ui_addSOptionRow(e){
			e.preventDefault();
			var row = ui_assembleSOptionRow(0,'','');
			row.appendTo('#tbl_spec_popup tbody');
		}

		function ui_deleteSOptionRow(e){
			e.preventDefault();
			$(this).parents('.sItem').remove();						
		}

		function ui_assembleSOptionRow(optionId,optionValue,englishoptionValue){
			var row = $('<tr>',{class:'sItem'});

			var textCell = $('<td>');
			var hidden = $('<input>',{type:'hidden',name:'optionid',val:optionId});
			textCell.append(hidden);
			var text = $('<input>',{type:'text',name:'option',val:optionValue});			
			textCell.append(text);
			row.append(textCell);

			var englishText = $('<input>',{type:'text',name:'englishoption',val:englishoptionValue});
			var englishTextCell = $('<td>');
			englishTextCell.append(englishText);
			row.append(englishTextCell);

			var operationCell = $('<td>');
			var deleteButton = $('<a>',{class:'delete',href:'javascript:;',title:'删除'});
			deleteButton.append($('<i>',{class:'fa fa-times fa-lg',style:'color:#f00;'}));
			operationCell.append(deleteButton);
			row.append(operationCell);
			return row;
		}

		function ui_update(attributeid){
			function success(data){
				if(data){
					$('#hid_id').val(attributeid);
					$('#txt_frontlabel').val(data.frontlabel);
					$('#txt_backendlabel').val(data.backendlabel);
					$('#txt_englishlabel').val(data.englishlabel);
					if(data.optionid){
						for (var i = 0; i < data.optionid.length; i++) {
							var optionid = data.optionid[i];
							var optionvalue = data.optionvalue[i];
							var englishoptionvalue = data.englishoptionvalue[i];
							var row = ui_assembleOptionRow(optionid,optionvalue, englishoptionvalue);
							row.appendTo('#tbl_spec_popup tbody');
						};
					}
					dialog.alert({
						title: '编辑规格',
						message: $('#frm_spec'),
			            closable: true,
			            buttonLabel: '保存',
			            callback: function (result, dialogObj) {
			            	if(result){
			            		function success(data){
			            			ui_formReset();
									if(data){
										if(data.result){
											$.Success('修改成功');
										}else{
											$.Error('修改失败');
										}
									}
									ui_reload();								
								}
			            		var data = $('#frm_spec').serializeObject();
			            		data = data_assembleData(data,false);
	        					specificationController.update(data,success);
			            	}else{
			            		ui_formReset();
			            	}
						}
					});					
				}
			}
			specificationController.get(attributeid, success);		
		}

		function ui_addRow(e){
			e.preventDefault();
			var row = ui_assembleOptionRow(0,'');
			row.appendTo('#tbl_spec_popup tbody');
		}

		function ui_assembleOptionRow(optionId,optionValue,englishoptionValue){
			var row = $('<tr>',{class:'sItem'});

			var textCell = $('<td>');
			var hidden = $('<input>',{type:'hidden',name:'optionid',val:optionId});
			textCell.append(hidden);
			var text = $('<input>',{type:'text',name:'option',val:optionValue});			
			textCell.append(text);
			row.append(textCell);

			var englishText = $('<input>',{type:'text',name:'englishoption',val:englishoptionValue});
			var englishTextCell = $('<td>');
			englishTextCell.append(englishText);
			row.append(englishTextCell);

			var operationCell = $('<td>');
			var deleteButton;
			if(optionId>0){
				deleteButton = $('<a>',{class:'delete',href:'javascript:;',title:'删除','data-id':optionId});
			}else{
				deleteButton = $('<a>',{class:'delete',href:'javascript:;',title:'删除'});
			}
			deleteButton.append($('<i>',{class:'fa fa-times fa-lg',style:'color:#f00;'}));
			operationCell.append(deleteButton);
			row.append(operationCell);
			return row;
		}

		function ui_deleteRow(e){
			e.preventDefault();
			var that = $(this);
			var optionid = that.data('id');
			if(optionid){		
				dialog.alert({
					title: '删除规格选项',
					message: '删除此行将不可恢复',
		            closable: true,
		            buttonLabel: '确定',
		            callback: function (result, dialogObj) {
		            	if(result){	            		
							function success(data){
								if(data){
									that.parents('.sItem').remove();
									if(data.result){
										//$.Success('删除成功');
										$.Success(data.tip);
									}else{
										//$.Error('删除失败');
										$.Error(data.tip);
									}
								}
							}
			    			specificationController.deleteOption(optionid, success);
		            	}
					}
				});
			}else{
				that.parents('.sItem').remove();
			}			
		}

		function ui_del(attributeid){
			dialog.alert({
				title: '删除规格',
				message: '删除此规格将不可恢复',
	            closable: true,
	            buttonLabel: '确定',
	            callback: function (result, dialogObj) {
	            	if(result){	            		
						function success(data){
							if(data){
								dataTable.fnDraw();
							}
						}
						specificationController.del(attributeid, success);
	            	}
				}
			});			
		}

		function data_assembleData(data,isAdd){
			if(!$.isArray(data.option)){
				data.option = [data.option];
			}
			if(!$.isArray(data.englishoption)){
				data.englishoption = [data.englishoption];
			}
			if(!isAdd){
				if(!$.isArray(data.optionid)){
					data.optionid = [data.optionid];
				}
			}
			return data;
		}

		$('#btn_addOption').click(ui_addRow);

		$('#frm_spec').on('click','.delete', ui_deleteRow);

		//参数
		var pGroupId = 1000;
		function ui_addPGroup(e){
			e.preventDefault();
			var group = $('<div>',{class:'pgroup container'});
			var buttonGroup = $('<div>',{class:'row form-inline'});
			var buttonGroupId = 'txt_group'+pGroupId;
			buttonGroup.append($('<label>',{'for':'groupname',class:'control-label',text:'参数组名称'}));
			buttonGroup.append($('<input>',{type:'hidden',name:'groupId',val:0}));
			buttonGroup.append($('<input>',{type:'text',name:'groupName',class:'form-control input-sm','data-rule':'required','data-msg-required':'请输入参数组名称',placeholder:'请输入参数组名称',id:buttonGroupId}));			
			var messageBox = $('<label>',{class:'control-label'});
			messageBox.attr('for',buttonGroupId);
			messageBox.append($('<span>',{class:'msg-box'}));
			buttonGroup.append(messageBox);
			buttonGroup.append($('<span>',{style:'width:200px;display:inline-block;'}));
			buttonGroup.append('&nbsp;');

			var buttonGroupENId = 'txt_groupen'+pGroupId;
			buttonGroup.append($('<label>',{'for':'groupnameen',class:'control-label',text:'参数组英文名称'}));
			buttonGroup.append($('<input>',{type:'text',name:'groupNameEN',class:'form-control input-sm','data-rule':'required','data-msg-required':'请输入参数组英文名称',placeholder:'请输入参数组英文名称',id:buttonGroupENId}));
			var messageBoxEN = $('<label>',{class:'control-label'});
			messageBoxEN.attr('for',buttonGroupENId);
			messageBoxEN.append($('<span>',{class:'msg-box'}));
			buttonGroup.append(messageBoxEN);
			buttonGroup.append($('<span>',{style:'width:200px;display:inline-block;'}));
			buttonGroup.append('&nbsp;');

			var addButton = ui_assembleFAbutton('btn green addParameter','新增参数','fa fa-plus','新增参数');
			buttonGroup.append(addButton);
			buttonGroup.append('&nbsp;');
			var deleteButton = ui_assembleFAbutton('btn red deleteParameterGroup','删除参数组','fa fa-trash-o','删除参数组');
			buttonGroup.append(deleteButton);
			group.append(buttonGroup);
			var tableRow = $('<div>',{class:'row'});
			var table = $('<table>',{class:'table table-striped table-bordered table-hover margin-top-10'});
			table.append($('<tbody>'));
			tableRow.append(table);
			group.append(tableRow);
			group.find('tbody').append(ui_assemblePRow);
			group.appendTo('#tbl_parameter');
			pGroupId++;
		}

		function ui_assembleFAbutton(buttonClass,title,faclass,text){
			var button = $('<a>',{role:'button',class:buttonClass,title:title,href:'javascript:;'});
			button.append($('<i>',{class:faclass}));
			button.append(text);
			return button;
		}

		var pRowId = 10000;
		function ui_assemblePRow(){
			var row = $('<tr>',{class:'pItem'});
			var nameCell = $('<td>',{class:'form-inline'});
			nameCell.append($('<label>',{class:'control-label',text:'参数名称'}));
			nameCell.attr('for','frontLabel');
			nameCell.append($('<input>',{type:'hidden',name:'parameterId',val:0}));
			var inputId = 'txt_parameter' + pRowId;
			nameCell.append($('<input>',{type:'text',name:'frontLabel',val:'',class:'form-control','data-rule':'required','data-msg-required':'请输入参数名称',placeholder:'请输入参数名称',id:inputId}));
			var messageBox = $('<label>',{class:'control-label'});
			messageBox.attr('for',inputId);
			messageBox.append($('<span>',{class:'msg-box'}));
			nameCell.append(messageBox);
			row.append(nameCell);

			var englishNameCell = $('<td>',{class:'form-inline'});
			englishNameCell.append($('<label>',{class:'control-label',text:'参数英文名称'}));
			messageBox.attr('for','englishLabel');
			var inputENId = 'txt_parameteren' + pRowId;
			englishNameCell.append($('<input>',{type:'text',name:'englishLabel',val:'',class:'form-control','data-rule':'required','data-msg-required':'请输入参数英文名称',placeholder:'请输入参数英文名称',id:inputENId}));
			var messageBoxEN = $('<label>',{class:'control-label'});
			messageBoxEN.attr('for',inputENId);
			messageBoxEN.append($('<span>',{class:'msg-box'}));
			englishNameCell.append(messageBoxEN);
			row.append(englishNameCell);

			var defaultValueCell = $('<td>',{class:'form-inline'});
			defaultValueCell.append($('<label>',{class:'control-label',text:'参数默认值'}));
			defaultValueCell.attr('for','defaultValue');
			defaultValueCell.append($('<input>',{type:'text',name:'defaultValue',val:'',class:'form-control'}));
			row.append(defaultValueCell);

			var operationCell = $('<td>');
			var deleteButton = $('<a>',{class:'deleteParameter',href:'javascript:;',title:'删除'});
			deleteButton.append($('<i>',{class:'fa fa-times fa-ex-times'}));
			operationCell.append(deleteButton);
			row.append(operationCell);
			pRowId++;
			return row;
		}

		function ui_addPRow(e){
			e.preventDefault();
			var row = ui_assemblePRow();
			row.appendTo($(this).parents('.pgroup').find('tbody'));			
		}

		function ui_deletePRow(e){
			e.preventDefault();
			var pitem = $(this).parents('.pItem');
			var parameterid = pitem.find('input[name=parameterId]').val();
			if(parameterid == 0){
				pitem.remove();
			}else{
				var categoryid = $('#hid_categoryid').val();
				
				function success(data){
					if(data){
						if(data.result){
							pitem.remove();
							$.Success(data.tip);							
						}else{
							$.Error(data.tip);
						}
					}
				}
				schema.deleteParameterFromSchema(categoryid,parameterid,success);
			}
		}

		function ui_deletePGroup(e){
			e.preventDefault();
			var pgroup = $(this).parents('.pgroup');
			var groupid = pgroup.find('input[name=groupId]').val();

			if(groupid == 0){
				pgroup.remove();
			}else{
				var categoryid = $('#hid_categoryid').val();
				
				function success(data){
					if(data){
						if(data.result){
							pgroup.remove();
							$.Success(data.tip);							
						}else{
							$.Error(data.tip);
						}
					}
				}
				schema.deleteParameterGroupFromSchema(categoryid,groupid,success);
			}
		}

		function ui_pSubmit(){

			if($('#tbl_parameter .pgroup').length==0){
				return;
			}
			var data = {categoryid:'',groupid:[],groupname:[],groupnameen:[],parameterid:[],frontLabel:[],englishLabel:[],defaultValue:[]};
			data.categoryid = $('#hid_categoryid').val();

			var index = 0;
			$('#tbl_parameter .pgroup').each(function(){
				var that = $(this);
				var groupid = that.find('input[name=groupId]').val();
				var groupname = that.find('input[name=groupName]').val();
				var groupnameen = that.find('input[name=groupNameEN]').val();

				that.find('.pItem').each(function(){
					data.groupid[index] = groupid;
					data.groupname[index] = groupname;
					data.groupnameen[index] = groupnameen;

					var me = $(this);
					data.parameterid[index] = me.find('input[name=parameterId]').val();
					data.frontLabel[index] = me.find('input[name=frontLabel]').val();
					data.englishLabel[index] = me.find('input[name=englishLabel]').val();
					data.defaultValue[index] = me.find('input[name=defaultValue]').val();
					index = index + 1;
				});
			});

			schema.addParameterGroupToSchema(data, success);

			function success(data){
				if(data){
					if(data.result){
						setTimeout(ui_reload,2500);
						$.Success(data.tip);
					}else{
						$.Error(data.tip);
					}
				}
			}
		}

		//通用
		function ui_validateFailure(e, form, errors){
			for(var index in errors){
				$.Warn(errors[index]);
			}
			return false;
		}

		//扩展属性
		$('#btn_addExtendedAttribute').click(ui_addERow);
		$('#tbl_extendedAttribute').on('blur','.attribute-type',ui_selectValidate);
		$('#tbl_extendedAttribute').on('change','.attribute-type',ui_toggleEditButton);
		$('#tbl_extendedAttribute').on('click','.delete',ui_deleteERow);
		$('#tbl_extendedAttribute').on('click','.shiftup',ui_shiftUpERow);
		$('#tbl_extendedAttribute').on('click','.shiftdown',ui_shiftDownERow);
		$('#tbl_extendedAttribute').on('click','.editOption',ui_editOptionERow);
		$('#tbl_optionHolder').on('click','.delete',ui_deleteOptionERow);
		$('#btn_addOption').click(ui_addOptionToEA);
		$('#form_extendedAttribute').validator()
		.on('valid.form', ui_eaSubmit)
		.on('invalid.form', ui_validateFailure);
		//规格
		$('#btn_chooseSpecification').click(ui_addSRow);
		$('#btn_addSpecification').click(ui_addSpecification);
		$('#btn_addSOption').click(ui_addSOptionRow);
		$('#frm_spec').on('click','.delete', ui_deleteSOptionRow);
		$('#tbl_specification').on('click','.edit',ui_editSRow);
		$('#tbl_specification').on('click','.delete',ui_deleteSRow);
		$('#tbl_specification').on('click','.shiftup',ui_shiftUpSRow);
		$('#tbl_specification').on('click','.shiftdown',ui_shiftDownSRow);
		$('#form_specification').validator()
		.on('valid.form', ui_sSubmit)
		.on('invalid.form', ui_validateFailure);
		//参数
		$('#btn_addParameterGroup').click(ui_addPGroup);
		$('#pnl_parameter').on('click','.addParameter',ui_addPRow);
		$('#pnl_parameter').on('click','.deleteParameterGroup', ui_deletePGroup);
		$('#pnl_parameter').on('click','.deleteParameter', ui_deletePRow);
		$('#form_parameter').validator()
		.on('valid.form', ui_pSubmit)
		.on('invalid.form', ui_validateFailure);
	});


//扩展属性
function extendAttribute(creatuserid,roleid){	
		//要操作数据创建人id
		$('#currentLonginCreaterUserValue').val(creatuserid);
		//要操作数据创建人角色id
		$('#currentLonginCreaterUserRoleValue').val(roleid);
}
//规格
function specificationAttribute(creatuserid,roleid){	
		//要操作数据创建人id
		$('#currentLonginCreaterGuigeUserValue').val(creatuserid);
		//要操作数据创建人角色id
		$('#currentLonginCreaterGuigeUserRoleValue').val(roleid);	
}

//文本框判断是否改变属性值
function isChangeProperty (obj){		 

	 //当前登录系统用户id
	var longinUserIdValue = $('#currentLonginUserId').val();
	//当前登录系统用户角色id
	var longinUserRoleIdValue = $('#currentLonginUserRoleId').val();
	//要操作数据创建人id
	var createrUserIdValue = $('#iseditcreatvalue').val();
	//要操作数据创建人角色id
	var createrUserRoleIdValue = $('#iseditrolevalue').val();

		
	//当前登录系统用户角色厂家:4
	if(longinUserRoleIdValue == 4){
		//当然操作数据角色是否和登录系统用户角色相同
		if(longinUserRoleIdValue == createrUserRoleIdValue){
			//当然操作数据创建人id是否和登录系统用户id相同
			if(longinUserIdValue == createrUserIdValue){					
				if($('#iseditvalue').val() == 0){
					$('#iseditvalue').val('0');
				   }				
			}else{
				if(obj.value != obj.defaultValue){  
				   $('#iseditvalue').val('1');
				}else{
				   if($('#iseditvalue').val() == 0){
					$('#iseditvalue').val('0');
				   }
				}  
			}
		}else{
			
			if(obj.value != obj.defaultValue){  
				   $('#iseditvalue').val('1');
			}else{
				   
				$('#iseditvalue').val('0');
				   
			} 
		}
	}	
}

//判断下拉列表是否改变属性值
function isChangeProperty2 (obj,create,role){	
	$('#attributetypeselectvaluedefaule').val(obj);
	$('#iseditcreatvalue').val(create);
	$('#iseditrolevalue').val(role);
}

//判断下拉列表是否改变属性值
function isChangeProperty3 (obj){
	//alert("check默认值："+obj);
	
	var isCheck;
	if(obj){		   
	   isCheck = "1";//选中
	}else{
	   isCheck = "0";//没选中
	}

	//当前是否选中chekbox值
	var defaulte =  $('#attributetypecheckboxvalue').val();
	//alert("check值："+defaulte);
	
	
	//当前登录系统用户id
	var longinUserIdValue = $('#currentLonginUserId').val();
	//当前登录系统用户角色id
	var longinUserRoleIdValue = $('#currentLonginUserRoleId').val();
	//要操作数据创建人id
	var createrUserIdValue = $('#iseditcreatvalue').val();
	//要操作数据创建人角色id
	var createrUserRoleIdValue = $('#iseditrolevalue').val();

		
	//当前登录系统用户角色厂家:4
	if(longinUserRoleIdValue == 4){
		//当然操作数据角色是否和登录系统用户角色相同
		if(longinUserRoleIdValue == createrUserRoleIdValue){
			//当然操作数据创建人id是否和登录系统用户id相同
			if(longinUserIdValue == createrUserIdValue){					
				if($('#iseditvalue').val() == 0){
					$('#iseditvalue').val('0');
				   }				
			}else{
				if(isCheck != defaulte){  
				   $('#iseditvalue').val('1');
				}else{
				   if($('#iseditvalue').val() == 0){
					$('#iseditvalue').val('0');
				   }
				}  
			}
		}else{
			
			if(isCheck != defaulte){   
				   $('#iseditvalue').val('1');
			}else{
				   
				$('#iseditvalue').val('0');
				   
			} 
			
		}
	}
}

//给checkbox赋默认值
function isChangeProperty4 (obj){
	if($(obj).is(':checked')) {
	  //默认值
	  $('#attributetypecheckboxvalue').val('1');//选中
	  //alert("选中");
	}else{
	  //默认值
	  $('#attributetypecheckboxvalue').val('0');//没选中
          //alert("没选中");
	}		
}

function iseditvalueRecode(create,role){
	$('#iseditcreatvalue').val(create);
	$('#iseditrolevalue').val(role);			
}