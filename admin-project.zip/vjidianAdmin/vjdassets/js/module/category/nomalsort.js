var cateporyTree = function(){
	
	var ajaxTreeSample = function() {

        $('#tree_1').jstree({
            'core' : {
                'themes' : {
                    'responsive': false
                }, 
                'data' : {
                    'url' : function (node) {
                      return 'demo/jstree_ajax_data.php';
                    },
                    'data' : function (node) {
                      return { 'parent' : node.id };
                    }
                }
            },
            'types' : {
                'default' : {
                    'icon' : 'fa fa-folder icon-warning icon-lg'
                },
                'file' : {
                    'icon' : 'fa fa-file icon-warning icon-lg'
                }
            },
            'state' : { 'key' : 'demo3' },
            'plugins' : [ 'dnd', 'state', 'types' ]
        });
    
    }
	
	return {
		init: function(){
			ajaxTreeSample();
		}
	}
}();