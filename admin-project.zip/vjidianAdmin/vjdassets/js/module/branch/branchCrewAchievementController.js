/**
   ��ҳ��
   create:jinzhesheng
   createtime:2016/11/2
 */
define(['jquery'], function ($) {
    'use strict';
    var root = 'https://admin.vjidian.com/2003/branchCrewAchievement';
    var controllers = {
		//������־
        url: {url: root + '/page'},
    };
    return {
        controllers: controllers,
    };
});