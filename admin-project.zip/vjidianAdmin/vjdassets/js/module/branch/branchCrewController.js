define([ 'jquery' ], function($) {
	'use strict';
	var root='https://admin.vjidian.com/2002/branchcrew';
	//定义全部请求的Controller
	var controllers = {
		add:{url:root+'/add',type:'POST',dataType:'JSON',data:{}},
		update:{url:root+'/update',type:'POST',dataType:'JSON',data:{}},
		page:{url:root+'/page',type:'POST',dataType:'JSON',data:{}},
		delete:{url:root+'/delete',type:'POST',dataType:'JSON',data:{}},
		editView:{url:root+'/editView'},
		addView:{url:root+'/addView'},
		getListByBranchId:{url:root+'/getListByBranchId',type:'POST',dataType:'JSON',data:{}}
	};
	function _ajax(controller,success,error) {
		var ajaxOptions=$.extend(true,controller,{success:success,error:error});
		$.ajax(ajaxOptions);
	}
	function _add(data,success,error){
		controllers.add.data=data;
		_ajax(controllers.add,success,error);
	}
	function _update(data,success,error){
		controllers.update.data=data;
		_ajax(controllers.update,success,error);
	}
	function _page(data,success,error) {
		controllers.page.data=data;
		_ajax(controllers.page,success,error);
	}
	function _delete(id,success,error) {
		controllers.delete.data.id=id;
		_ajax(controllers.delete,success,error);
	}
	function _editView(id){
		return controllers.editView.url + '/' + id;
	}
	function _getListByBranchId(branchId,success,error) {
		controllers.getListByBranchId.data.branchId=branchId;
		_ajax(controllers.getListByBranchId,success,error);
	}
	
	return {
		add:_add,
		update:_update,
		page:_page,
		delete:_delete,
		editView:_editView,
		getListByBranchId:_getListByBranchId,
		controllers:controllers
	};
});