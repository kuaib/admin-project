
define(['jquery','uniform'], function( $ ) {
	//渲染控件
	var init=function(){
		if (!$().uniform) {
            return;
        }
        var ctl = $("input[type=checkbox]:not(.toggle, .switch-button), input[type=radio]:not(.toggle, .star, .switch-button)");
        if (ctl.size() > 0) {
        	ctl.each(function () {
                if ($(this).parents(".checker").size() == 0) {
                    $(this).show();
                    $(this).uniform();   
                }
            });
        }
	};
	
	return {
		init:init,
		
    };
});



