/******************
�������ּ�¼
***/
define(['jquery'], function($) {
	'use strict';
	var root='https://admin.vjidian.com/2103/manufacturerwithdrawdetail';
	var websiteroot='https://admin.vjidian.com';
	var controllers = {
		showWithdrawDetail:{url:root+'/showWithdrawDetail'},
		pageWithdrawDetail:{url:root+'/pageWithdrawDetail',data:{}},
		/***********************************jinzheshengmodify 2016/11/2*************************************/
		//������˱���ַ
		financeRecReportUrl: {url:websiteroot+'/7001/financeRecReport/pageWithdrawDetail'},
		/***********************************jinzheshengmodify 2016/11/2*************************************/
		

	};
	function _ajax(controller,success,error) {
		var ajaxOptions=$.extend(true,controller,{
			type:'POST',
			dataType:'JSON',
			success:success,
			error:error
		});
		$.ajax(ajaxOptions);
	}
	function _withdraw(data,success,error){
		controllers.withdraw.data=data;
		_ajax(controllers.withdraw,success,error);
	}
	function _bindCard(data,success,error){
		controllers.bindCard.data=data;
		_ajax(controllers.bindCard,success,error);
	}
	function _sendBindCardCaptcha(data,success,error){
		controllers.sendBindCardCaptcha.data=data;
		_ajax(controllers.sendBindCardCaptcha,success,error);
	}
	function _unbindCard(data,success,error){
		controllers.unbindCard.data=data;
		_ajax(controllers.unbindCard,success,error);
	}
	return {
		withdraw:_withdraw,
		bindCard:_bindCard,
		sendBindCardCaptcha:_sendBindCardCaptcha,
		unbindCard:_unbindCard,
		controllers:controllers
	};
});
