/******************
�����ʽ����
***/
define(['jquery'], function($) {
	'use strict';
	var root='https://admin.vjidian.com/2102/manufacturerfund';
	var controllers = {
		show:{url:root+'/show'},    //���̹���
		showWithdrawDetail:{url:root+'/showWithdrawDetail'},
		page:{url:root+'/page',data:{}},
		pageWithdrawDetail:{url:root+'/pageWithdrawDetail',data:{}},
		showWithdraw:{url:root+'/showWithdraw',data:{}},
		withdraw:{url:root+'/withdraw',data:{}},
		showBindCard:{url:root+'/showBindCard',data:{}},
		bindCardByMoney:{url:root+'/bindCardByMoney',data:{}},
		bindCardByCaptcha:{url:root+'/bindCardByCaptcha',data:{}},
		sendBindCardMoneyValidate:{url:root+'/sendBindCardMoneyValidate',data:{}},
		sendBindCardCaptchaValidate:{url:root+'/sendBindCardCaptchaValidate',data:{}},
		sendMobileVerifyCode:{url:root+'/sendMobileVerifyCode'},  //�����ֻ���֤��
		unbindCard:{url:root+'/unbindCard',data:{}}   //������
	};
	function _ajax(controller,success,error) {
		var ajaxOptions=$.extend(true,controller,{
			type:'POST',
			dataType:'JSON',
			success:success,
			error:error
		});
		$.ajax(ajaxOptions);
	}
	function _withdraw(data,success,error){
		controllers.withdraw.data=data;
		_ajax(controllers.withdraw,success,error);
	}
	function _bindCardByMoney(data,success,error){
		controllers.bindCardByMoney.data=data;
		_ajax(controllers.bindCardByMoney,success,error);
	}
	function _bindCardByCaptcha(data,success,error){
		controllers.bindCardByCaptcha.data=data;
		_ajax(controllers.bindCardByCaptcha,success,error);
	}
	function _sendBindCardMoneyValidate(data,success,error){
		controllers.sendBindCardMoneyValidate.data=data;
		_ajax(controllers.sendBindCardMoneyValidate,success,error);
	}
	function _sendBindCardCaptchaValidate(data,success,error){
		controllers.sendBindCardCaptchaValidate.data=data;
		_ajax(controllers.sendBindCardCaptchaValidate,success,error);
	}
	function _unbindCard(data,success,error){
		controllers.unbindCard.data=data;
		_ajax(controllers.unbindCard,success,error);
	}
	return {
		withdraw:_withdraw,
		bindCardByMoney:_bindCardByMoney,
		bindCardByCaptcha:_bindCardByCaptcha,
		sendBindCardMoneyValidate:_sendBindCardMoneyValidate,
		sendBindCardCaptchaValidate:_sendBindCardCaptchaValidate,
		unbindCard:_unbindCard,
		controllers:controllers
	};
});
