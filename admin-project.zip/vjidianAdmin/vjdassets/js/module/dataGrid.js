define(['jquery', 
	'datatables', 
	'data-grid-bootstrap', 
	'datatables-colreorder',
	'css!/vjidianAdmin/vjdassets/plugins/data-grid/css/table'], 
	function($) {
	'use strict';
	var table = $();
	/*默认配置*/
	var defaultOptions = {
		/** 是否允许排序 */
		ordering: true,
		/**是否显示分页信息 */
		info: true,
		/** 是否搜索 */
		searching: true,
		/** 是否自动设置宽度 */
		autoWidth: true,
		/** 是否显示数据加载进度条 */
		processing: true,
		/** 是否数据来自于服务端 */
		serverSide: true,
		/** 默认容器 */ 
		table: null,
		/** 列集合 */
		columns: [],
		/** 排序集合 */
		order: [],
		/** 记录被选中的行 */
		checkedRow:[],
		/** AJAX返回JSON数据默认对象属性 */
		ajax: {
			data:function(request){
			 	var data = $.extend({}, request, {
			 		searchKey: $('#sel_searchType a.curr').data('search'),
        			searchContent: $('#txt_searchContent').val(),
        			iDisplayLength: $('#hid_pageSize').val(),
        			iDisplayStart: $('#hid_pageNum').val(),
        			aCheckedRow: table.checkedRow
      			});
      			$('.shadow').show();
      			return data;
			 },
			dataSrc:function(json){
			 	$('.shadow').hide();		 	
			 	if(!json.result){
			 		json.result=[];
			 		json.totalNum = 0;
			 		json.pageSize = 10;
			 		json.pageNum = 1;
			 	}
			 	_query(json);
			 	return json.result;
			 }
		},
		/** 语言包 */
		language: lang_zh,
		/** 渲染样式 */
		renderer: 'bootstrap',
		deferRender: true,
		/** TODO pagingType:'bootstrap', */
		/** 是否显示行序号，当前页 */
		showIndex: false,
		showFlag:false,
		/** 是否显示复选框 */
		showChecked: false,
		/** 冻结列属性 */
		/*requireFixedColumn: false,
		fixedColumn: {
			iLeftColumns: 1,
			iRightColumns: 0,
			fnDrawCallback: null,
			sHeightMatch: 'semiauto'
		},*/
		scrollY: false,
		scrollX: true,
		scrollCollapse: false,
		/** 是否显示分页 */
		paging: true,
		paginationType: 'simple_numbers',
		pageSize:[10,20,30,40,50],
		/** 冻结头部 */
		requireFixedHeader: false,
		/** 数据提交方式 */
		sServerMethod: 'post',
		/** 显示列选择参数 */
		requireColVis: true,
		colVis: {
			/** selector */
			buttonContainer: '.colvis',
			buttonText: '选择列',
			sAlign: 'right',
			aiExclude: [],
			bRestore: true,
			sRestore: '恢复默认',
			bShowAll: true,
			sShowAll: '显示全部列',
			fnLabel: function(index, title, th) {
				return title;
			}
		},
		requireScroller: false,
		scroller: {
			trace: false,
			rowHeight: 'auto',
			serverWait: 200,
			displayBuffer: 9,
			boundaryScale: 0.5,
			loadingIndicator: false
		},
		requireColReorder: false,
		colReorder: {
			order: null,
			fixedColumns: 0,
			fixedColumnsRight: 0,
			reorderCallback: null
		},
		actionKey: null,
		actions: null,
		drawCallback:function(settings){
			var tableWrapper = $('#'+settings.sTableId+'_wrapper');
			if(table.checkAll){
				$('input[type=checkbox]',tableWrapper).prop('checked',true);
				table.checkedRow=[];
				$('.selectRow', table).each(function() {
					table.checkedRow.push($(this).attr('val'));
				});
			}else{
				$('input[type=checkbox]',tableWrapper).prop('checked',false);
				table.checkedRow=[];
			}
		},
		fnServerData:null,
		stateSave: false,
		stateLoadCallback: function() {

		},
		stateSaveCallback: function() {

		}
	};
	/*初始化*/
	var options;
	function _init(config){

		defaultOptions.columns = config.columns;
		defaultOptions.aoColumns = config.columns;

		options = $.extend(true, defaultOptions, config);
		/*初始化HTML中设定的数据列到datatable参数中*/
		_initColumns(options);
		table = options.table.dataTable(options);
		table.on('draw.dt',table,_onDraw);
		if (options.requireColReorder) {
			require(['jquery', 'datatables-colreorder'], function($) {
				new $.fn.DataTable.ColReorder(table, options.colReorder);
			}); 
		};

		if (options.requireFixedColumn) {
			require(['jquery', 'datatables-fixedcolumns'], function($) {
				new $.fn.dataTable.FixedColumns(table, options.fixedColumn);
			});
		};

		if (options.requireColVis) {
			require(['jquery', 'datatables-colvis'], function($) {
				var covis = new $.fn.DataTable.ColVis(table, options.colVis);
				$(covis.button()).appendTo(options.colVis.buttonContainer);
			});
		};

		if (options.requireScroller) {
			require(['jquery', 'datatables-scroller'], function($) {
				new $.fn.DataTable.Scroller(table.fnSettings(), options.scroller);
			});
		};
		
		return table;
	};
	/*美化复选框*/
	function _onDraw(e) {
		var table = e.data;
		var settings = table.fnSettings();
		var tableWrapper = $('#'+settings.sTableId+'_wrapper');
		$('input[type=checkbox]',tableWrapper).each(function() {
			if ($(this).hasClass('checkAll')) {
				$(this).off('click', _allCheckToggle);
				$(this).on('click',tableWrapper, _allCheckToggle);
			}
			/*美化复选框列中复选框样式*/
			$(this).uniform();
		});
		
		table.fnAdjustColumnSizing(false);
	};
	/*选择每页显示数量*/
	function _pageSize(){
		$('#hid_pageSize').val(this.value);
		var pageSize = $('#hid_pageSize').val();
		sessionStorage.setItem("pageSize",pageSize);
		table.fnDraw();
	}
	/*输入显示第几页*/
	function _pageNum(e) {
		var settings = table.fnSettings();
		if (e.keyCode == 13 || $(e.target).is('#btn_skipPage')) {
			e.preventDefault();
			var $that = $('#are_paging input[type=text]');
			var pageNum = $that.val();
			var regex = /^\d+$/;
			var totalPage = parseInt($('#totalPage').html());
			if (regex.test(pageNum) && pageNum<=totalPage) {
				var totalPages = Math.ceil(settings._iRecordsTotal/settings._iDisplayLength);
				if(pageNum>totalPages){
				 	pageNum = totalPages;
				}
				sessionStorage.setItem("pageNum", pageNum); 
				$('#hid_pageNum').val(pageNum);
				table.fnDraw();
				return false;
			} else {
				$that.val($('#hid_pageNum').val());
			}
		}
	}
	/*复选框列列头全全选*/
	function _allCheckToggle(e) {
		var checked = $(this).prop('checked');
		var tmpArr=[];
		$('.selectRow', e.data).each(function() {
			$(this).prop('checked', checked);
			/*必须，否则Div模拟的checkbox的选中状态不一致*/
			tmpArr.push($(this).val());
			$(this).uniform();
		});
		if(checked){
			table.checkedRow=tmpArr;
		}else{
			table.checkedRow=[];
		}
		$(this).uniform();
	}
	/*初始化列*/
	function _initColumns(options) {
		var index = 0;
		options.table.checkedRow=[];
		options.table.checkAll = false;
		if (options.actions) {
			options.columns.unshift({
				title: '操作',
				orderable: false,
				width:'80px',
				className: 'text-center nowrap',
				name: 'DToperate',
				render: function(cell, type, row, meta) {
					var html = '';
					var div = $('<div>');
					var wrapper = $('<div>',{"class":'text-center'});

					$.each(options.actions, function(name, value){
						if(value.visible){
							if(!value.visible(cell,type,row,meta)){
								return;
							}
						}
						
						/* 后台的权限 */
						var notPermit=(function(){						
							var key = options.actionKey;
							if (key) {
								var i = 0;
								var length = row[key].length;
								for (; i < length;i++) {
									if (row[key][i].code == name) {
										/*break;*/
										return false;
									}
								}
								if (i == length) {   
									return true;
								}
							}
						})();
						/*console.log(notPermit);*/

						var Cls;
						var title;
						if (name == 'view') {
							Cls = value.className ? value.className : 'fa fa-eye operationIcon';
							title = '查看';
						} else if (name == 'delete') {
							Cls = value.className ? value.className : 'fa fa-trash-o operationIcon';
							title = '删除';
						} else if (name == 'edit') {
							Cls = value.className ? value.className : 'fa fa-edit operationIcon';
							title = '编辑';
						} else if (name == 'show'){
							Cls = value.className ? value.className : 'fa fa-chevron-down operationIcon';
							title ='展开';
						} else {
							Cls = value.className ? value.className : 'fa fa-cogs operationIcon';
							title = value.tip;
						}
						if(!notPermit){
							var a = $('<a>',{"class":'btn-link DT-'+ name,title:title});
						}else{
							var a = $('<a>',{"class":'disabled btn-link',title:title});
						}
						a.append($('<i>').addClass(Cls));
						$.each(row, function(name, value) {
							a.attr('data-' + name, value);
						});
						wrapper.append(a);	

						//获取当前系统时间
						var dateNow=new Date(); 
						//获取当前毫秒数
						var mydateTime = dateNow.getTime();
						//三天前的秒数
						var threeDayTime = (mydateTime - 24*60*60*1000*3);
						//获取到表格中时间
						for(var i = 0; i<$("#tbl_product").find('tbody input[type="checkbox"]').length;i++){
							var tableTime = $("#tbl_product").find(' tbody input[type="checkbox"]').eq(i).data("lastmodifytime");
							if(tableTime > threeDayTime){
								$("#tbl_product").find('tbody input[type="checkbox"]').eq(i).parents("tr").css("color","#1d943b");
							}
						}

					});
					
					// 更多操作
					var oMore = null;
					if(options.moreActions){
						oMore = $('<div>',{class:'btn-group btn-group-xs btn-group-solid',style:'position:absolute'});
						var oBtn = $('<button>',{class:'btn btn-default dropdown-toggle',type:'button',"data-toggle":'dropdown'});
						oBtn.html('更多');
						oMore.append(oBtn);
						var oUl = $('<ul>',{class:'dropdown-menu'});
						var hasLi = false;
						$.each(options.moreActions,function(name,value){
							var liText = value.tip ? value.tip : '';
							var oLi = $('<li>',{class:'DT-'+name,"data-id":row.id,style:'cursor:pointer;border-bottom:1px solid #ccc;padding:4px 0'}).html(liText);
							if(value.visible){
								if(!value.visible(cell,type,row,meta)){
									oLi.hide();
								}else{
									hasLi = true;
								}
							}else{
								hasLi = true;
							}
							oUl.append(oLi);
						});
						
						if(!hasLi){
							oBtn.css('visibility','hidden');
						}
						var oPlaceholder = oMore.clone();
						oPlaceholder.css({position:'relative',visibility:'hidden'});
						oMore.append(oUl);
						wrapper.append(oMore);
						wrapper.append(oPlaceholder);
					}
					div.append(wrapper);
					html = html + div.html();
					return html;
				}
			});
				
			$.each(options.actions, function(name, value) {
				if (value.fn) {
					options.table.on('click', '.DT-' + name, value.fn);
				}
			});
			if(options.moreActions){
				$.each(options.moreActions, function(name, value) {
					if (value.fn) {
						options.table.on('click', '.DT-' + name, value.fn);
					}
				});
			}
			index++;
		}
		
		
		/*显示行索引*/
		if (options.showIndex) {
			options.columns.unshift({
				title: '序号',
				name: 'DTrownum',
				width: '40px',
				contentPadding: 'iiii',
				orderable: false,
				className: 'text-center',
				render: function(data, type, row, meta) {
					return meta.settings._iDisplayStart + meta.row + 1;
				}
			});
			index++;
		}

		/*显示标记*/
		if (options.showFlag) {
			options.columns.unshift({
				title: options.showFlag.title ? options.showFlag.title : '',
				orderable: false,
				contentPadding: 'iiii',
				width: '40px',
				className: 'text-center',
				name: 'DTflag',
				render: function(data, type, row, meta) {
					var div = $('<div></div>');
					var a = $('<a class="btn-link DT-flag" title="标记"><i class="fa fa-star-o fa-lg"></i></a>');
					$.each(row, function(name, value) {
						a.attr('data-' + name, value);
					});
					div.append(a);
					return div.html();
				}
			});
			options.table.on('click', '.DT-flag', function() {
				$(this).find('i').toggleClass('fa-star-o');
				$(this).find('i').toggleClass('fa-star');
				/*if(flagFn){
					flagFn($(this).data());
				}*/
			});
			index++;
		}

		/*显示行复选*/
		if (options.showChecked) {
			options.columns.unshift({
				title: '<input type="checkbox" class="checkAll" />',
				orderable: false,
				contentPadding: 'iiii',
				width: '40px',
				className: 'text-center',
				render: function(data, type, row, meta) {
					// var div = $('<div></div>');
					// var checkbox = $('<input type="checkbox" class="selectRow" val='+row.id+'>');
					var $checkbox = $('<input>',{
						type:'checkbox',
						class:'selectRow',
						style:'width:40px',
						val:row.id
					});
					$.each(row, function(name, value) {
						$checkbox.attr('data-' + name, value);
					});
					// div.append(checkbox);
					// return div.html();
					return $checkbox.prop('outerHTML');
				}
			});
			options.table.on('click', 'input[type=checkbox]', function() {
				$(this).uniform();
				if($(this).prop('checked')){
					options.table.checkedRow.push($(this).val());
					//options.table.checkedRow.push($(this).attr('val'));
				}else if(!$(this).prop('checked')){
					var n = $.inArray($(this).val(),options.table.checkedRow);
					//var n = $.inArray($(this).attr('val'),options.table.checkedRow);
					options.table.checkedRow.splice(n,1);
				}
				/*console.log(options.table.checkedRow);*/
			});
			index++;
		}

		if (options.requireColVis) {
			for (var i = 0; i < index; i++) {
				defaultOptions.colVis.aiExclude.push(i);
			}
		}
	}
	//搜索
	function search(e){		
		$('#hid_treeSelected').val('-10');//-10为搜索框标识
		if(e.keyCode == 13 || e.type == 'click'){
			e.preventDefault();
			var productNameVal = $("#productName").val();  //搜索的产品名称值
			var manufacturerNameVal = $("#manufacturerName").val();   //搜索的厂家名称的值
			var brandNameVal = $("#brandName").val();    //搜索的品牌名称的值
			var brandCatogory = $("#brandCatogory").val();   //搜索的产品分类的值

 			sessionStorage.setItem("searchContent1",productNameVal);
 			sessionStorage.setItem("searchContent2",manufacturerNameVal);
 			sessionStorage.setItem("searchContent3",brandNameVal);
 			sessionStorage.setItem("searchContent4",brandCatogory);
			$('#hid_pageNum').val(1);	
			sessionStorage.setItem("pageNum",1);
			table.fnDraw(); 
		}
	}
	//选择搜索类型
 	function selectType(){
 		var sText=$(this).find('a').text();
 		$(this).parent().siblings('button').find('span').text(sText);
 		$('#txt_searchContent').attr('placeholder','输入'+$.trim(sText)+'查询');
 		$(this).parent().find('a').removeClass('curr');
 		$(this).find('a').addClass('curr');
 	}
 	//重绘表格
 	function reDraw(e){
 		e.preventDefault();
		
		var searchContent1 = sessionStorage.getItem("searchContent1");
		var searchContent2 = sessionStorage.getItem("searchContent2");
		var searchContent3 = sessionStorage.getItem("searchContent3");
		var searchContent4 = sessionStorage.getItem("searchContent4");
		var pageSize = sessionStorage.getItem("pageSize");
		var pageNum = sessionStorage.getItem("pageNum");
		/********12/14 kuaibing 新增 避免出现undefined*********/
		searchContent1 = (searchContent1 == undefined ? "" : searchContent1);
		searchContent2 = (searchContent2 == undefined ? "" : searchContent2);
		searchContent3 = (searchContent3 == undefined ? "" : searchContent3);
		searchContent4 = (searchContent4 == undefined ? "" : searchContent4);
		pageSize = (pageSize == undefined ? "10" : pageSize);
		pageNum = (pageNum == undefined ? "1" : pageNum);
		/********12/14 kuaibing 新增 避免出现undefined*********/

		$("#productName").val(searchContent1);
		$("#manufacturerName").val(searchContent2);
		$("#brandName").val(searchContent3);
		$("#brandCatogory").val(searchContent4);

		$('#hid_pageSize').val(pageSize);                    //每页显示条数
		$('#hid_pageNum').val(pageNum);	             //当前页数
 		table.fnDraw();
 	}
 	
 	//重绘表格2
 	function reDraw2(e){
 		$('#hid_treeSelected').val('-10');
 		reDraw(e);
 	}
	/*分页控件*/
	function _query(data){
		require(['js/module/jquery-paging'],function(pagination){
			pagination.getPaging('#are_paging',data.totalNum,data.pageSize,data.pageNum,options.pageSize,
				function (pageNum) {
					sessionStorage.setItem("pageNum", pageNum); 
					$('#hid_pageNum').val(pageNum);
					table.fnDraw();
				}
			);
		});	
	}
	/*重新计算列宽*/
	function _resize() {
		if(table.length!=0){
			table.fnAdjustColumnSizing(false);
		}
	}
	/*选择每页显示数量事件绑定*/
	$('#are_paging').on('change','#sel_pageSize',_pageSize);
	/*输入显示第几页事件绑定*/
	$('#are_paging').on('keydown', 'input',_pageNum);
	$('#are_paging').on('click', '#btn_skipPage',_pageNum);
	//选择搜索项
	$('#sel_searchType').on('click','li',selectType);
	//按回车搜索
	$('#txt_searchContent').bind("keydown",search);
	//点击按钮搜索
	$('#btn_search').on('click',search);
	//刷新数据
	$('#btn_refresh').on('click',reDraw);
	//改变窗口大小列宽自适应
	$(window).bind('resize',_resize);
	$(window).bind('load',function(){
		_resize();
		setTimeout(_resize,1500);
	});

	/*返回*/
	return {
		init: _init,
		resize:_resize,
		reDraw2:reDraw2
	};
	
});