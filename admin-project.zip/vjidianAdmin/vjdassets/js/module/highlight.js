define([ 'jquery', "app", '/vjdassets/plugins/highlight/highlight.pack.js' ],
		function($) {
			require([ 'css!/vjdassets/plugins/highlight/styles/github.css' ]);
			;(function($) {
				"use strict";
				$.fn.extend ({
					viewcode : function(language, code) {
						$(this).html(hljs.highlight(language, code).value);
					}
				});
			})($);
		});
