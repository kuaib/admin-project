define(['jquery','app'],function(){
    var hisPriceFlag = true;  // 标记是否是第一条历史价格记录
    /**
     * url: 请求的后台接口
     * data: 请求的参数
     * tag：渲染分页的标签
     * beforeSendCallback: 请求前的操作
     * successCallback：接口请求成功的回调函数
     * pageRender: 渲染分页
     * renderData: 分页数据渲染回调函数
     * errorCallback: 接口请求失败的回调函数
     * */

    // 弹窗公用ajax请求
    function ajaxRequest(url,data,beforeSendCallback,successCallback,tag,pageRender){
        $.ajax({
            url : url,
            type: "post",
            data : data,
            dataType : "json",
            beforeSend: function(){
                if(beforeSendCallback){
                    beforeSendCallback();
                }
            },
            success : function(resultList){
                if(resultList.success){
                    successCallback(resultList.result);
                    // 分页
                    if(pageRender){
                        pageRender(resultList,tag,url,successCallback,data);
                    }
                }else{
                    alert(resultList.msg);
                }

            },
            error:function(){
               // tag.hide();
            }
        })
    }

    // 公用分页渲染
    function pageRender(data,tag,url,renderCallback,dataPage){
        require(['jquery','plugins/pagination/js/pagination'], function($,pagination) {
            var options={
                alias: {
                    pageNumber: 'pageNum',
                    pageSize: 'pageSize',
                },
                dataSource:url,
                ajax:{
                    data:dataPage // 分页要传递的参数
                },
                totalNumber:data.totalNum,
                pageSize:10,  // 每页条数
                pageRange: 3, // 控制显示的分页数
                showGoInput:false, // 显示跳转到指定页数的输入框
                showGoButton:false, // 显示跳转到指定页数的确定按钮
                showNavigator:true,  // 显示导航器
                className: 'paginationjs-theme-yellow',
                locator:"result",       // 服务端返回的json对象的属性名称--->属性值是数组
                triggerPagingOnInit:false, //是否出发默认分页初始化
                callback: function (response, pagination) {
                    renderCallback(response,pagination); // response 就是那个json对象中的数据，即result的属性值
                },
                //// 暂时不知道对不对
                //onChangePage:function(event,data){
                //    console.log(data.currentPage);
                //    console.log(data.rowsPerPage);
                //},
                //// 第二种
                //onSelectPage:function(pageNumber, pageSize){
                //    console.log(pageNumber);
                //    console.log(pageSize);
                //}
            }
            // 分页初始化
            tag.pagination(options);
            //pagination.getPaging(tag,data.totalNum,function(per){
            //    console.log(per);},function(per){
            //    console.log(per);})
        });

    }

    // 历史价格查询成功的回调函数
    function getHisPriceSuc(data){
        $(".hisContent .listDetail").empty();//分页需要清空
        if(data && data.length > 0){
            $(".hisPrice .noData").hide();
            renderHisPrice(data);
        }else{
            $("#coverChild1").hide();      //隐藏loading
            $("#wrapper-hisPrice").hide(); //隐藏分页
            $(".hisPrice .noData").show(); //显示未查询到数据提示
        }
    }

    // 渲染历史价格函数
    function renderHisPrice(res)    {
        var html = "",rate = "";
        $.each(res,function(i,v){
            if(v.slidingScales > 0){
                rate =  "↑" + ((Math.abs(v.slidingScales)) * 100).toFixed(2) + "%";
            }else if(v.slidingScales < 0){
                rate =  "↓" + ((Math.abs(v.slidingScales)) * 100).toFixed(2) + "%";
            }else{
                rate = 0;
            }
            html += '<div class="listItem clearfix">' +
                '<ul>' +
                    '<li style="width: 115px">' + v.newPrice + '</li>' +
                    '<li style="width: 125px">' + rate + '</li>' +
                    '<li style="width: 125px">' + v.modifyUser + '</li>' +
                    '<li style="width: 203px">' + v.modifyTime + '</li>' +
                '</ul>' +
                '</div>';
        });
        $(".hisPrice .hisContent .listDetail").append(html);
        $("#wrapper-hisPrice").show();
        $("#coverChild1").hide();
    }

    // 等级价 已设置时 查询成功的回调函数
    function getLevPriceSuc(data){
        data = data.channelTypeList;
        if(data && data.length > 0){
            $(".levelPrice .noData").hide();
            renderLevPrice(data);
        }else{
            $("#coverChild2").hide();       //隐藏loading
            $(".levelContent .tip").hide(); //隐藏自动计算订货价
            $(".levelPrice .noData").show();//显示未查询到数据提示
        }
    }

    // 渲染等级价函数
    function renderLevPrice(data){
        var html = "";
        $.each(data,function(i,v){
            if(!v.classPrice){v.classPrice = ""}
            html += '<div class="listItem clearfix">' +
                        '<ul>' +
                            '<li style="width: 185px" class="agentName" data-classPriceId="'+ v.classPriceId+'"  data-id="'+ v.id+'">' + v.name + '</li>' +
                            '<li style="width: 185px" class="gradeDiscount">' + ((v.gradeDiscount) * 100).toFixed(0) + '%</li>' +
                            '<li style="width: 198px"><input type="text" class="iptAgent" value="' + v.classPrice + '" style="width: 90px;height: 30px;text-align: center;"></li>' +
                        '</ul>' +
                    '</div>';
        });
        $(".levelContent .listDetail").append(html);
        $("#coverChild2").hide();
    }

    // 指定价已设置时查询成功的回调函数
    function getDesPriceSuc(data){
        if(data && data.length > 0){
            renderDesPrice(data);
        }else{
            $("#coverChild3").hide();        //隐藏loading
            $(".designPrice .noData").show();//显示未查询到数据提示
        }
    }

    // 渲染指定价函数
    function renderDesPrice(data){
        $(".designContent .listDetail").empty();
        $(".designContent .noData").hide();
        var html = "";
        $.each(data,function(i,v){
            if(!v.assignPrice){
                v.assignPrice = "";
            }
            html += '<div class="listItem clearfix">' +
                '<ul>' +
                '<li style="width: 300px;height:auto;white-space: normal;" class="desPriLi">' + v.name + '</li>' +
                '<li style="width: 100px;" class="clientCode">' + v.code + '</li>' +
                '<li style="width: 100px;">' + v.clientType + '</li>' +
                '<li style="width: 100px;">' + v.area + '</li>' +
                '<li style="width: 100px;"><input type="text" value="' + v.assignPrice + '" class="resPrice" style="width: 90px;height: 30px;text-align: center;"></li>' +
                '<li data-id="' + v.assignPriceId + '" data-channelId="'+ v.channelId +'" class="delClient" style="width: 58px;cursor: pointer">删除</li>' +
                '</ul>' +
                '</div>';
        });
        $(".designPrice .designContent .listDetail").append(html);
        var liHeight = $(".designContent .desPriLi").height();
        $(".designContent .listDetail li").css("height",liHeight + "px"); //使li高度一致
        $("#wrapper-desPrice").show();
        $("#coverChild3").hide();
    }

    // 选择客户弹层查询成功的回调函数
    function selClientSuc(data){
        if(data  && data.length > 0){
            renderSelClient(data);
        }else{
            $("#coverChild4").hide();       //隐藏loading
            $("#wrapper-selClient").hide(); //隐藏分页
            $(".selContent .listDetail").empty();//清空原查询到的数据
            $(".selContent .noData").show();//显示未查询到数据提示
            $(".selContent .listTitle span").removeClass("checked");
        }
    }

    // 渲染选择客户函数
    function renderSelClient(data){
        $(".selContent .listDetail").empty();//分页需要清空
        $(".selContent span").removeClass("checked");
        var html = "";
        $.each(data,function(i,v){
            v.isSet = v.isSet == 1 ? "已指定" : "未指定";
            if(v.isSet == "已指定"){
                html += '<div class="listItem clearfix">' +
                    '<ul>' +
                    '<li style="width: 30px;"><input type="checkbox" checked disabled data-id="'+ v.id+'"></li>' +
                    '<li style="width: 300px;height:auto;white-space: normal;" class="clientName">' + v.name + '</li>' +
                    '<li style="width: 140px;" class="code">' + v.code + '</li>' +
                    '<li style="width: 138px;" class="clientType">' + v.clientType + '</li>' +
                    '<li style="width: 150px;" class="area">' + v.area + '</li>' +
                    '<li style="width: 100px;color:red;">已指定</li>' +
                    '</ul>' +
                    '</div>';
            }else{
                html += '<div class="listItem clearfix">' +
                    '<ul>' +
                    '<li style="width: 30px;"><input type="checkbox" class="checkIpt" data-id="'+ v.id+'"></li>' +
                    '<li style="width: 300px;height:auto;white-space: normal;" class="clientName">' + v.name + '</li>' +
                    '<li style="width: 140px;" class="code">' + v.code + '</li>' +
                    '<li style="width: 138px;" class="clientType">' + v.clientType + '</li>' +
                    '<li style="width: 150px;" class="area">' + v.area + '</li>' +
                    '<li style="width: 100px;">未指定</li>' +
                    '</ul>' +
                    '</div>';
            }
        })
        $(".selClient .selContent .listDetail").append(html);
        var liHeight = $(".selContent .clientName").height();
        $(".selContent .listDetail li").css("height",liHeight + "px"); //使li高度一致
        $("#wrapper-selClient").show(); // 渲染成功之后才出现分页
        $("#coverChild4").hide();
    }

    /****************渠道库存情况***************/
    // 渠道库存查询成功的回调函数
    function getChannelSuc(data){
        if(data && data.length > 0){
            renderChannel(data);
        }else{
            $("#coverChild").hide();            // 隐藏loading
            $("#wrapper-channelPrice").hide();  // 隐藏分页
            $(".channelContent .listDetail").empty();//清空原查询到的数据
            $(".channelPrice .noData").show();  // 显示未查询到数据提示
        }
    }
    // 渲染渠道库存情况
    function renderChannel(data){
        $(".channelContent .listDetail").empty();//分页的时候清空
        var html = "";
        $.each(data,function(i,v){
            html += '<div class="listItem clearfix">' +
                '<ul>' +
                    '<li style="width: 150px;white-space: normal;"  class="firLi">' + v.name + '</li>' +
                    '<li style="width: 100px">' + v.code + '</li>' +
                    '<li style="width: 100px">' + v.clientType + '</li>' +
                    '<li style="width: 100px">' + v.area + '</li>' +
                    '<li style="width: 118px">' + v.channelStock + '</li>' +
                '</ul>' +
                '</div>';
        });
        $(".channelContent .listDetail").append(html);
        var liHeight = $(".firLi").height();
        $(".listDetail li").css("height",liHeight + "px"); //使li高度一致
        $("#wrapper-channelPrice").show(); // 成功之后展示分页
        $("#coverChild").hide();           // 成功之后隐藏loading
    }
    return {
        ajaxRequest:ajaxRequest,
        pageRender:pageRender,
        getHisPriceSuc:getHisPriceSuc,
        getLevPriceSuc:getLevPriceSuc,
        getDesPriceSuc:getDesPriceSuc,
        selClientSuc:selClientSuc,
        getChannelSuc:getChannelSuc,
        renderDesPrice:renderDesPrice,
        hisPriceFlag:hisPriceFlag
    }
})