define(['js/module/goods/goodsController',
	'nice-validator-zh_CN'], 
	function(goodsController) {
	var _updateGoods=function(){
		//赋值attributeValues对象
		var goodslist=[];
		$('tbody tr',$('#tbl_goods')).each(function(index,item){
			var $tr = $(this);
			var checked=$tr.find('td:first input[type=checkbox]').parent().hasClass('checked');
			if(checked){
				//商品的当前上下架状态
				var oldshelfStatus=$tr.find("input[name=shelfStatus]").val();
				var item={
					id:$tr.data("goodsid"),
					//httl赋值
					//shelfStatus:$tr.find("input[name=shelfStatus]").parent().hasClass('checked')?1:(oldshelfStatus==1?0:oldshelfStatus),
					shelfStatus:$tr.find("input[name=shelfStatus]").parent().hasClass('checked')?-2:(oldshelfStatus==1?0:oldshelfStatus),
					stock:$tr.find("input[name=actualStock]").val(),
					limitStock:$tr.find("input[name=limitStock]").val(),
					//salesPrice:$tr.find("input[name=salesPrice]").val(),
					costPrice:$tr.find("input[name=costPrice]").val(),
					marketPrice:$tr.find("input[name=marketPrice]").val(),
					deliveryTime:$tr.find("input[name=deliveryTime]").val(),
					leadTime:$tr.find("input[name=leadTime]").val(),
					initSalesVolume:$tr.find("input[name=initSalesVolume]").val(),
					isDefault:$tr.find("input[name=isDefault]").parent().hasClass('checked'),
				};
				goodslist.push(item);
			}
		});
		function success(data){
			var tip=data.tip;
			if(data.result){
				$.Success(tip);
				window.setInterval(function(){
					location.href=goodsController.controllers.show.url;
				},2000);
			}
			else{
				$.Warn(tip);
			}
		}
		
		if(goodslist.length>0){
			goodsController.update(goodslist,success);
		}else{
			$.Warn("请先选择货品");
		}
	}
	return {
		updateGoods:_updateGoods,
	};
});