define([ 'jquery' ], function($) {
	'use strict';
	var root='https://admin.vjidian.com/3002/goods';
	
	//定义全部请求的Controller
	var controllers = {
		chooseSiteView:{url:root+'/chooseSite'},
		getPage:{url:root+'/page',data:{}},
		show:{url:root+'/show'},
		editView:{url:root+'/operate/edit/'},
		del:{url:root+'/delete',data:{id:''}},
		update:{url:root+'/update',async:false,data:{}},
	};
	function _ajax(controller,success,error) {
		var ajaxOptions=$.extend(true,controller,{
			type:'POST',
			dataType:'JSON',
			success:success,
			error:error
		});
		$.ajax(ajaxOptions);
	}
	
	function _update(data,success,error){
		controllers.update.data.goodsJSON=JSON.stringify(data);
		_ajax(controllers.update,success,error);
	};
	

	function _getPage(data,success,error) {
		controllers.getPage.data=data;
		_ajax(controllers.getPage,success,error);
	}
	
	function _del(id,success,error) {
		controllers.del.data.id=id;
		_ajax(controllers.del,success,error);
	}

	return {
		controllers:controllers,
		update:_update,
		getPage:_getPage,
		del:_del,
	};
});