/**
 * 网站结构
 */
define(['jquery'], function($) {
	'use strict';
	var root = 'https://admin.vjidian.com/9003/surfaceSection';
	//定义全部请求的Controller
	var controllers = {
		show: {
			url: root + '/show'
		},
		find: {
			url: root + '/find',
			data: {}
		},
		getChildren: {
			url: root + '/getChildren',
			data: {}
		},
		showAdd: {
			url: root + '/showAdd/'
		},
		getAdvertis: {
			url: root + '/getAdvertis'
		},
		getArticle: {
			url: root + '/getArticle'
		},
		getBrand: {
			url: root + '/getBrand'
		},
		getProduct: {
			url: root + '/getProduct'
		},
		getRootCategory: {
			url: root + '/getRootCategory'
		},
		add: {
			url: root + '/add',
			data: {}
		},
		edit:{
			url: root + '/update',
			data: {}
		},
		editView:{
			url: root + '/editView/',
			data: {}
		},
		del:{
			url: root + '/delete',  
			data: {}
		},
		enable:{
			url: root + '/enable',
			data: {}
		},
		disable:{
			url: root + '/disable',
			data: {}
		},

		preview:{url: root + '/preview',data: {} },

		showPreview:{url: root + '/showPreview',data: {} },
	};

	function _ajax(controller, success, error) {
		var ajaxOptions = $.extend(true, controller, {
			type: 'POST',
			dataType: 'JSON',
			async:false,  
			success: success,
			error: error
		});
		$.ajax(ajaxOptions);
	}

	function _find(data, success, error) {
		controllers.find.data = data;
		_ajax(controllers.find, success, error);
	};

	function _getChildren(id, success, error) {
		controllers.getChildren.data.id = id;
		_ajax(controllers.getChildren, success, error);
	};

	function _add(data, success, error) {
		controllers.add.data = data;
		_ajax(controllers.add, success, error);
	};
	function _edit(data, success, error) {
		controllers.edit.data = data;
		_ajax(controllers.edit, success, error);
	};
	function _editView(data, success, error) {
		controllers.editView.data = data;
		_ajax(controllers.editView, success, error);
	};
	function _enable(data, success, error) {
		controllers.enable.data.id = data;
		_ajax(controllers.enable, success, error);
	};
	function _disable(data, success, error) {
		controllers.disable.data.id = data;
		_ajax(controllers.disable, success, error);
	};
	function _del(data, success, error) {
		controllers.del.data.id = data;
		_ajax(controllers.del, success, error);
	};

	function _preview(data, success, error) {
		controllers.preview.data = data;
		_ajax(controllers.preview, success, error);
	};

	function _showPreview(data, success, error) {
		controllers.showPreview.data = data;
		_ajax(controllers.showPreview, success, error);
	};

	return {
		controller: controllers,
		find: _find,
		getChildren: _getChildren,
		add: _add,
		edit: _edit,
		editVew:_editView,
		enable:_enable,
		disable:_disable,
		del:_del,
		preview:_preview,
		showPreview:_showPreview,
	};
});