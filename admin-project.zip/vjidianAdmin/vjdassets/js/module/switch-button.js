define(['jquery','plugins/bootstrap-switch/js/bootstrap-switch'], function( $ ) {
	//渲染控件
	require([ 'css!/vjdassets/plugins/bootstrap-switch/css/bootstrap3/bootstrap-switch.css' ]);
	var init=function(){
		if (!$().bootstrapSwitch) {
            return;
        }
		$('input:checkbox.switch-button').each(function(){
			$(this).bootstrapSwitch({
				onSwitchChange:function(event, state) {
					//控制input属性，方便form提交
					$(this).attr("checked",state);
					//事件回调
					//callback(event, state);
				}
			});
			
			//设置状态
			var state=true;
			if($(this).attr("checked")){
				state=$(this).attr("checked");
				$(this).bootstrapSwitch('state', state);
			}
		});
    };
	init();//默认初始化
	var getValue=function(ctl){
		return ctl.is(":checked");
	};
	
	var setValue=function(ctl,state){
		ctl.bootstrapSwitch('state', state);
		if(!state){
			ctl.attr("checked", state);
		}
	};
	
	return {
		init:init,
		getValue:getValue,
        setValue: setValue
    };
});



